#include "xium_entrypoint.h"
#include "xium_wnd.h"

int main( int argc, char** argv )
{
	//Fl::args( argc, argv );
	XiumMainWindow *win = new XiumMainWindow;
    win->show( argc, argv );
    return Fl::run();
}
