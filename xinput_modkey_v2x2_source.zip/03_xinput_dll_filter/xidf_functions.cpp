#include "xidf_functions.h"
#include <assert.h>
#include <algorithm>
//#include "detours.h"
#include <process.h>    //_getpid()

XidfGlobals* XidfData = 0;

//DWORD WINAPI xidf_XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke )
//{
//	assert(0);
//	return 00;
//}

const std::vector<std::pair<int,int> > xidf_ButtonBits = {
	{ Xidf_Act_A, XINPUT_GAMEPAD_A,},
	{ Xidf_Act_B, XINPUT_GAMEPAD_B,},
	{ Xidf_Act_X, XINPUT_GAMEPAD_X,},
	{ Xidf_Act_Y, XINPUT_GAMEPAD_Y,},
	{ Xidf_Act_UP, XINPUT_GAMEPAD_DPAD_UP,},
	{ Xidf_Act_DOWN, XINPUT_GAMEPAD_DPAD_DOWN,},
	{ Xidf_Act_LEFT, XINPUT_GAMEPAD_DPAD_LEFT,},
	{ Xidf_Act_RIGHT, XINPUT_GAMEPAD_DPAD_RIGHT,},
	{ Xidf_Act_START, XINPUT_GAMEPAD_START,},
	{ Xidf_Act_BACK, XINPUT_GAMEPAD_BACK,},
	{ Xidf_Act_LS, XINPUT_GAMEPAD_LEFT_SHOULDER,},
	{ Xidf_Act_RS, XINPUT_GAMEPAD_RIGHT_SHOULDER,},
	{ Xidf_Act_LT, XINPUT_GAMEPAD_LEFT_THUMB,},
	{ Xidf_Act_RT, XINPUT_GAMEPAD_RIGHT_THUMB,},
};
const std::vector<int> xidf_ActionIsStick = {
	Xidf_Act_LSXAdd, Xidf_Act_LSXSub,
	Xidf_Act_LSYAdd, Xidf_Act_LSYSub,
	Xidf_Act_RSXAdd, Xidf_Act_RSXSub,
};
const std::vector<int> xidf_ActionIsTrigger = {
	Xidf_Act_LTr, Xidf_Act_RTr,
};
const std::vector<std::pair<int,std::string> > xidf_ActNames = {
	{ Xidf_Act_A, "A", },
	{ Xidf_Act_B, "B", },
	{ Xidf_Act_X, "X", },
	{ Xidf_Act_Y, "Y", },
	{ Xidf_Act_LT, "LTh", },  // Left Thumbstick.
	{ Xidf_Act_RT, "RTh", },
	{ Xidf_Act_START, "START", },
	{ Xidf_Act_BACK, "BACK", },
	{ Xidf_Act_UP, "UP", },
	{ Xidf_Act_DOWN, "DOWN", },
	{ Xidf_Act_LEFT, "LEFT", },
	{ Xidf_Act_RIGHT, "RIGHT", },
	{ Xidf_Act_LS, "LSh", },
	{ Xidf_Act_RS, "RSh", },
	{ Xidf_Act_LTr, "LTr", },  // Left Trigger.
	{ Xidf_Act_RTr, "RTr", },
	{ Xidf_Act_LSXAdd, "LSXPlus", },
	{ Xidf_Act_LSXSub, "LSXMinus", },
	{ Xidf_Act_LSYAdd, "LSYPlus", },
	{ Xidf_Act_LSYSub, "LSYMinus", },
	{ Xidf_Act_RSXAdd, "RSXPlus", },
	{ Xidf_Act_RSXSub, "RSXMinus", },
	{ Xidf_Act_RSYAdd, "RSYPlus", },
	{ Xidf_Act_RSYSub, "RSYMinus", },
};
/// Mouse button flags used by Winapi SendInput(), MOUSEINPUT and INPUT.
const std::vector< std::pair< int, std::pair<int,int> > >  xidf_MButtonBits = {
	{ 1, { MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP,},},
	{ 2, { MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP,},},
	{ 3, { MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP,},},
	//MOUSEEVENTF_WHEEL
};
const std::vector<std::pair<int,std::string> > xidf_TINames = {
	{ Xidf_TI_MouseMove, "eMouseMotion", },
	{ Xidf_TI_KbdArrows, "eKbdArrows", }, //WIP.
};
const std::vector<std::pair<int, std::vector<std::string> > > xidf_KeyNames = {
	{ VK_BACK, {"backspace","bs","back",}, },
	{ VK_TAB, {"tab",}, },
	{ VK_CLEAR, {"CLEAR",}, },
	{ VK_RETURN, {"RETURN","ENTER",}, },
	{ VK_SHIFT, {"SHIFT",}, },
	{ VK_CAPITAL, {"Capital","CapsLock",}, },
	{ VK_ESCAPE, {"Escape","Esc",}, },
	{ VK_PRIOR, {"PRIOR","PageUp","PgUp",}, },
	{ VK_NEXT, {"NEXT","PageDown","PgDn",}, },

	{ VK_LEFT, {"LEFT","LeftArrow","LArrow",}, },
	{ VK_UP, {"UP","UpArrow","UArrow",}, },
	{ VK_RIGHT, {"RIGHT","RightArrow","RArrow",}, },
	{ VK_DOWN, {"DOWN","DownArrow","DArrow",}, },

	{ VK_SNAPSHOT, {"SNAPSHOT","PrintScreen","PrntScr"}, },
	{ VK_LWIN, {"LWIN","WIN",}, },
	{ VK_RWIN, {"RWIN",}, },
	{ VK_APPS, {"APPS","Applications",}, },
	{ VK_MULTIPLY, {"MULTIPLY","Mul",}, },
	{ VK_NUMLOCK, {"NumLock",}, },
	{ VK_SCROLL, {"SCROLL","ScrollLock",}, },
	{ VK_CONTROL, {"CONTROL","Ctrl",}, },
	{ VK_MENU, {"MENU","ALT",}, },
	{ VK_PAUSE, {"Pause",}, },
	{ VK_SPACE, {"Space",}, },
	{ VK_END, {"END",}, },
	{ VK_HOME, {"HOME",}, },
	{ VK_SELECT, {"SELECT",}, },
	{ VK_EXECUTE, {"EXECUTE",}, },
	{ VK_INSERT, {"INSERT",}, },
	{ VK_DELETE, {"DELETE",}, },
	{ VK_HELP, {"HELP",}, },
	{ VK_ADD, {"ADD",}, },
	{ VK_SEPARATOR, {"SEPARATOR",}, },
	{ VK_SUBTRACT, {"SUBTRACT","Sub",}, },
	{ VK_DECIMAL, {"DECIMAL",}, },
	{ VK_DIVIDE, {"DIVIDE","Div",}, },
	{ VK_ATTN, {"ATTN",}, },
	{ VK_CRSEL, {"CRSEL",}, },
	{ VK_EXSEL, {"EXSEL",}, },
	{ VK_EREOF, {"EREOF",}, },
	{ VK_PLAY, {"PLAY",}, },
	{ VK_ZOOM, {"ZOOM",}, },
};

int xidf_StrToTrInputMode( const char* inp )
{
	for( const auto& a : xidf_TINames ){
		if( a.second == inp )
			return a.first;  //eg. Xidf_TI_MouseMove
	}
	return 0;
}
void xidf_MsgBoxIf( HWND hwnd, const char* msg, const char* flags2 )
{
	assert( XidfData );
	if( XidfData->bCLIOnly )
		return;
	bool bErr = !strchr( flags2, 'k' );
	MessageBox( hwnd, msg, "XIDF", (bErr?MB_ICONERROR:0) );
}
void xidf_EnforceAPIDeadZones( XINPUT_GAMEPAD& gp2, bool bReinterpolate )
{
	const int deadzoneLStk = XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE; //7849
	const int deadzoneRStk = XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE; //8689
	const int deadzoneTrg  = XINPUT_GAMEPAD_TRIGGER_THRESHOLD; //30
	const bool bRi = bReinterpolate;
	gp2.bLeftTrigger  = xidf_ApplyDeadZoneIfNeeded( gp2.bLeftTrigger, deadzoneTrg, (bRi ? Xidf_MaxTriggerPos : 0) );
	gp2.bRightTrigger = xidf_ApplyDeadZoneIfNeeded( gp2.bRightTrigger, deadzoneTrg, (bRi ? Xidf_MaxTriggerPos : 0) );
	//float magnitude2 = sqrt( pow( gp2.sThumbLX, 2 ) + pow( gp2.sThumbLY, 2 ) );
	gp2.sThumbLX = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbLX, deadzoneLStk, (bRi ? Xidf_MaxStickPos : 0) );
	gp2.sThumbLY = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbLY, deadzoneLStk, (bRi ? Xidf_MaxStickPos : 0) );
	gp2.sThumbRX = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbRX, deadzoneRStk, (bRi ? Xidf_MaxStickPos : 0) );
	gp2.sThumbRY = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbRY, deadzoneRStk, (bRi ? Xidf_MaxStickPos : 0) );
}
int xidf_StrToGamepadAction( const char* inp )
{
	int outp = 0;
	std::find_if( xidf_ActNames.begin(), xidf_ActNames.end(),
			[&]( const std::pair<int,std::string>& a ){
					if( a.second == inp ){
						outp = a.first;
						return 1;
					}
					return 0;
			}
	);
	return outp;
}
bool xidf_ParseRoutines( const hxdw_IniData2& ini3, std::vector<Xidf_Routine>& actionsOu, std::string* err2 )
{
	char bfr[512]; bool bSucc = 1;
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srSecNameBgn = hxdw_TrimStr("s_routine:0", ":0", "R", -1 );
	ini3.eachSection( [&]( const hxdw_IniSection& sec2 ){
			std::string secname = sec2.first;
			if( secname.size() > srSecNameBgn.size() )
				secname = secname.substr( 0, srSecNameBgn.size() );
			if( secname == srSecNameBgn ){
				std::string srHotk = ini3.getValue( sec2.first.c_str(), "szHotkey" );
				if( srHotk.empty() ){
					sprintf_s( bfr, sizeof(bfr),
							"No trigger specified for action [%s]",
							sec2.first.c_str() );
					err3 = bfr;
					bSucc = 0;
					return 0;
				}
				Xidf_Trigger trgr;
				if( !xidf_ParseTriggerSequence( srHotk.c_str(), trgr, &err3, "" ) ){
					sprintf_s( bfr, sizeof(bfr),
							"Failed parsing trigger for action [%s].szHotkey [%s]",
							sec2.first.c_str(), err3.c_str() );
					err3 = bfr;
					bSucc = 0;
					return 0;
				}
				std::string vSprss = ini3.getValue( sec2.first.c_str(), "szSuppress" );
				std::string vHold = ini3.getValue( sec2.first.c_str(), "szHold" );
				std::string vSndk = ini3.getValue( sec2.first.c_str(), "szSemdKeys" );
				Xidf_Routine rtne3;
				rtne3.trigger2 = trgr;
				xidf_ActionsToArray( vSprss.c_str(), ',', rtne3.aSuppress, &err3 );
				if( !vHold.empty() ){
					if( !xidf_StrToInputList( vHold.c_str(), ',', rtne3.aHold2, &err3 ) ){
						sprintf_s( bfr, sizeof(bfr),
								"Error at [%s].szHold [%s]",
								sec2.first.c_str(), err3.c_str() );
						err3 = bfr;
						bSucc = 0;
						return 0;
					}
				}
				rtne3.bHExclusive = !!atoi( ini3.getValue( sec2.first.c_str(), "bHExclusive" ).c_str() );
				{
					std::vector<std::string> vcodes2;
					hxdw_StrExplode( vSndk.c_str(), vcodes2, {',',}, -1, "\x20\t" );
					for( const auto& srVk : vcodes2 ){
						if( !srVk.empty() && srVk[0] == 'm' ){ // eg. "m1", "m2", "m3", etc.
							Xidf_SendKey sn2( 0, ++XidfData->nLastSendkId );
							sn2.nMouseBtn = atoi( srVk.substr(1).c_str() );
							rtne3.aSendVk.push_back( sn2 );
						}else{
							rtne3.aSendVk.push_back( Xidf_SendKey(
									atoi( srVk.c_str() ), ++XidfData->nLastSendkId ) );
						}
					}
				}
				actionsOu.push_back( rtne3 );
			}
			return 1;
	});
	return bSucc;
}

bool
xidf_ParseTriggerSequence( const char* inp, Xidf_Trigger& outp, std::string* err2, const char* flags2 )
{
	//flags2
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btnsOrMdk;
	hxdw_StrExplode( inp, btnsOrMdk, {'+',}, -1, "\x20\t" );
	if( btnsOrMdk.empty() || btnsOrMdk[0].empty() ){
		err3 = "No modkey name.";
		return 0;
	}
	for( const auto& a : btnsOrMdk ){
		int id2;
		if( (id2 = xidf_FindModkeyByName( a.c_str(), XidfData->modkeys3 )) ){
			outp.modkeyIds.push_back( id2 );
		}else if( (id2 = xidf_StrToGamepadAction( a.c_str() )) ){
			outp.buttons2.push_back( id2 );
		}else{
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr),
					"Trigger item '%s' not recognizaed. "
					"It must be either modkey name or button name.",
					a.c_str() );
			err3 = bfr;
			return 0;
		}
	}
	outp.ident4 = ++XidfData->nLastTriggerId;
	return 1;
}
bool xidf_ActionsToArray( const char* szBtnNames, char glue2, std::vector<int>& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btns;
	hxdw_StrExplode( szBtnNames, btns, {glue2,}, -1, "\x20\t" );
	for( const auto& a : btns ){
		int id2;
		if( !(id2 = xidf_StrToGamepadAction( a.c_str() )) ){
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr),
					"Unrecognizaed action name '%s'.", a.c_str() );
			err3 = bfr;
			return 0;
		}
		outp.push_back(id2);
	}
	return 1;
}
bool xidf_ParseModkeys2( const hxdw_IniData2& ini3, std::vector<Xidf_Modkey>& modkeysOu, std::string* err2 )
{
	char bfr[512];
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srSecNameBgn2 = hxdw_TrimStr("s_modkey:0", ":0", "R", -1 );
	std::vector<std::string> secnames;
	//ini3.getSectionsByNamePrefix()
	ini3.eachSection( [&]( const hxdw_IniSection& sec ){
			std::string secnme( sec.first );
			if( secnme.size() > srSecNameBgn2.size() )
				secnme = secnme.substr( 0, srSecNameBgn2.size() );
			if( secnme == srSecNameBgn2 )
				secnames.push_back( sec.first );
			return 1;
	});
	int nNr = 0;
	std::vector<std::string>::const_iterator a;
	for( a = secnames.begin(); a != secnames.end(); ++a, nNr++ ){
		std::string sname = *a;
		Xidf_Modkey mdk0;
		std::string srBtn    = ini3.getValue( sname.c_str(), "szButton" );
		std::string srThrsh  = ini3.getValue( sname.c_str(), "nFloor" );
		std::string srLimit  = ini3.getValue( sname.c_str(), "nCeil" );
		std::string srRename = ini3.getValue( sname.c_str(), "szName" );
		if( srBtn.empty() ){
			sprintf_s( bfr, sizeof(bfr), "Empty button name, [%s].szButton", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		mdk0.btnActivator = xidf_StrToGamepadAction( srBtn.c_str() );
		if( !mdk0.btnActivator ){
			sprintf_s( bfr, sizeof(bfr), "Unknown button name, [%s].szButton", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		mdk0.threshold2 = ( srThrsh.empty() ? -1 : xidf_StrToLimit( srThrsh.c_str(), mdk0.btnActivator ) );
		mdk0.limit2 = ( srLimit.empty() ? -1 : xidf_StrToLimit( srLimit.c_str(), mdk0.btnActivator ) );
		mdk0.limit2 = ( !mdk0.limit2 ? -1 : mdk0.limit2 );

		if( !srRename.empty() ){
			mdk0.rename2 = srRename;
		}else{
			sprintf_s( bfr, sizeof(bfr), "Mod%d", nNr );
			mdk0.rename2 = bfr;
		}
		mdk0.bSuppress = !!atoi( ini3.getValue( sname.c_str(), "bSuppress" ).c_str() );
		mdk0.ident3    = ++XidfData->nLastModkId;

		modkeysOu.push_back( mdk0 );
	}
	return 1;
}
bool xidf_IsStickAction( int eAction )
{
	for( const auto& a : xidf_ActionIsStick ){
		if( a == eAction )
			return 1;
	}
	return 0;
}
bool xidf_IsTriggerAction( int eAction )
{
	for( const auto& a : xidf_ActionIsTrigger ){
		if( a == eAction )
			return 1;
	}
	return 0;
}

/// If found, returns nonzero value epresenting mask|bit of the digital
/// gamepad button.
int xidf_ActionToBitIfAny( int eBtn )
{
	for( const auto& a : xidf_ButtonBits ){
		if( a.first == eBtn )
			return a.second;
	}
	return 0;
}
std::pair<int,float>
xidf_GetInputValueForAction( int eAction, const XINPUT_GAMEPAD& gpd )
{
	int mask2 = xidf_ActionToBitIfAny( eAction );
	if( mask2 ){
		return ( gpd.wButtons & mask2 ? std::make_pair(1,1.f) : std::make_pair(0,0.f) );
	}
	if( 0 ){
	}else if( eAction == Xidf_Act_LTr ){
		return { gpd.bLeftTrigger, ( float(gpd.bLeftTrigger) / Xidf_MaxTriggerPos ), };
	}else if( eAction == Xidf_Act_RTr ){
		return { gpd.bRightTrigger, ( float(gpd.bRightTrigger) / Xidf_MaxTriggerPos ), };

	}else if( eAction == Xidf_Act_LSXAdd && gpd.sThumbLX >= 0 ){
		return { gpd.sThumbLX, ( float(gpd.sThumbLX) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_LSXSub && gpd.sThumbLX < 0 ){
		int val = std::abs( gpd.sThumbLX );
		return { val, ( float(val) / Xidf_MaxStickPos ), };

	}else if( eAction == Xidf_Act_LSYAdd && gpd.sThumbLY >= 0 ){
		return { gpd.sThumbLY, ( float(gpd.sThumbLY) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_LSYSub && gpd.sThumbLY < 0 ){
		int val = std::abs( gpd.sThumbLY );
		return { val, ( float(val) / Xidf_MaxStickPos ), };

	}else if( eAction == Xidf_Act_RSXAdd && gpd.sThumbRX >= 0 ){
		return { gpd.sThumbRX, ( float(gpd.sThumbRX) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_RSXSub && gpd.sThumbRX < 0 ){
		int val = std::abs( gpd.sThumbRX );
		return { val, ( float(val) / Xidf_MaxStickPos ), };

	}else if( eAction == Xidf_Act_RSYAdd && gpd.sThumbRY >= 0 ){
		return { gpd.sThumbRY, ( float(gpd.sThumbRY) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_RSYSub && gpd.sThumbRY < 0 ){
		int val = std::abs( gpd.sThumbRY );
		return { val, ( float(val) / Xidf_MaxStickPos ), };
	}
	return {0,0.0f,};
}
bool xidf_TestActionDown( int eBtn2, std::pair<int,int> aRangeFloorCeil, const XINPUT_GAMEPAD& gpd )
{
	const int threshold3 = aRangeFloorCeil.first;
	const int ceil2      = aRangeFloorCeil.second;
	const int poss       = xidf_GetInputValueForAction( eBtn2, gpd ).first;
	if( poss && poss >= threshold3 ){
		if( ceil2 == -1 || poss < ceil2 )
			return 1;
	}
	return 0;
}
Xidf_ModkeyDown* Xidf_ModkeyDown::findModkey( int ident, Xidf_ModkeyDown* inp, size_t num )
{
	for( int i=0; i<num; i++ ){
		if( inp[i].mod2->ident3 == ident )
			return &inp[i];
	}
	return 0;
}
bool xidf_IsActionDown( int eBtn, const XINPUT_GAMEPAD& gpd, std::pair<int,int> aRange )
{
	if( xidf_IsStickAction( eBtn ) || xidf_IsTriggerAction( eBtn ) ){
		return xidf_TestActionDown( eBtn, aRange, gpd );
	}else{
		int flg = xidf_ActionToBitIfAny( eBtn );
		if( flg & gpd.wButtons )
			return 1;
	}
	return 0;
}
int xidf_GetThresholdForActionIfAny( int eBtn )
{
	const auto a = std::find( xidf_ActionIsStick.begin(), xidf_ActionIsStick.end(), eBtn );
	if( a != xidf_ActionIsStick.end() ){
		//XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE
		return XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE;
	}
	const auto b = std::find( xidf_ActionIsTrigger.begin(), xidf_ActionIsTrigger.end(), eBtn );
	if( b != xidf_ActionIsTrigger.end() ){
		return XINPUT_GAMEPAD_TRIGGER_THRESHOLD;
	}
	return -1;
}
bool xidf_PerformModkeys( Xidf_Perform& inp )
{
	if( XidfData->bInited && inp.dwUserIndex2 == XidfData->nGamepadIndex ){
		const XINPUT_GAMEPAD  gpd  = inp.xistate.Gamepad;
		XINPUT_GAMEPAD        gpd2 = inp.xistate.Gamepad;
		for( const int a : XidfData->aGlobSuppr ){
			xidf_SetGamepadValue( a, 0, gpd, gpd2 );
		}
		for( auto& a : XidfData->aModsDown ){ // Xidf_ModkeyDown, Xidf_Modkey
			bool bDown3 = xidf_IsActionDown( a.mod2->btnActivator, gpd, { a.mod2->threshold2, a.mod2->limit2,} );
			if( a.bDown2 && !bDown3 ){
				a.bDown2 = 0; //printf("--- modk up!\n");
			}else if( !a.bDown2 && bDown3 ){
				a.bDown2 = 1; //printf("--- modk down!\n");
			}
			if( a.mod2->bSuppress ){
				xidf_SetGamepadValue( a.mod2->btnActivator, 0, gpd, gpd2 );
			}
		}
		for( auto& a : XidfData->aRoutinesLive ){
			std::vector<int> aBtnsDownPerActn;
			bool bLive2 = xidf_IsTriggerDown( a.routine2->trigger2, gpd, &aBtnsDownPerActn );
			if( a.routine2->bHExclusive ){
				for( const auto& b : xidf_ActNames ){
					const auto c = std::find( aBtnsDownPerActn.begin(), aBtnsDownPerActn.end(), b.first );
					if( c == aBtnsDownPerActn.end() ){
						if( xidf_IsActionDown( b.first, gpd, {0,-1,} ) ){
							bLive2 = 0;
							break;
						}
					}
				}
			}
			if( !a.bLive && bLive2 ){
				a.bLive = 1; //printf("--- act down.\n");
				xidf_RoutineLiveOnDown( a, inp, gpd, gpd2 );
			}else if( a.bLive && !bLive2 ){
				a.bLive = 0; //printf("--- act up.\n");
				xidf_RoutineLiveOnUp( a, inp, gpd, gpd2 );
			}
			if( a.bLive ){
				xidf_RoutineLivePerform( a, inp, gpd, gpd2 );
			}
		}
		for( auto& a : XidfData->aTrInputLive ){
			//aTrInputLive//Xidf_TI_MouseMove
			xidf_PerformTrInputLive( a, gpd, gpd2 );
		}
		inp.xistate.Gamepad = gpd2;
	}
	xidf_PerformCleanup();
	return 1;
}
void xidf_SetGamepadValue2( int eAction, float fNewValFrac, const XINPUT_GAMEPAD& gpd,
							XINPUT_GAMEPAD& gpd2 )
{
	int val = 0;
	fNewValFrac = std::abs( fNewValFrac );
	if( eAction == Xidf_Act_LTr )
		val = ( fNewValFrac * Xidf_MaxTriggerPos );
	else if( eAction == Xidf_Act_RTr )
		val = ( fNewValFrac * Xidf_MaxTriggerPos );
	else if( eAction == Xidf_Act_LSXAdd && gpd.sThumbLX > 0 )
		val = ( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_LSXSub && gpd.sThumbLX < 0 )
		val = -( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_LSYAdd && gpd.sThumbLY > 0 )
		val = ( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_LSYSub && gpd.sThumbLY < 0 )
		val = -( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSXAdd && gpd.sThumbRX > 0 )
		val = ( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSXSub && gpd.sThumbRX < 0 )
		val = -( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSYAdd && gpd.sThumbRY > 0 )
		val = ( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSYSub && gpd.sThumbRY < 0 )
		val = -( fNewValFrac * Xidf_MaxStickPos );
	else{
		val = ( fNewValFrac != 0.0f ? 1 : 0 );
	}
	xidf_SetGamepadValue( eAction, val, gpd, gpd2 );
}
void xidf_SetGamepadValue( int eAction, int nNewValue, const XINPUT_GAMEPAD& gpd,
							XINPUT_GAMEPAD& gpd2 )
{
	int mask2;
	if( (mask2 = xidf_ActionToBitIfAny( eAction ))){
		if( !nNewValue ){
			gpd2.wButtons &= ~mask2;
		}else
			gpd2.wButtons |= mask2;
	}else{
		if( eAction == Xidf_Act_LTr )
			gpd2.bLeftTrigger = nNewValue;
		if( eAction == Xidf_Act_RTr )
			gpd2.bRightTrigger = nNewValue;
		if( eAction == Xidf_Act_LSXAdd && gpd.sThumbLX > 0 )
			gpd2.sThumbLX = nNewValue;
		if( eAction == Xidf_Act_LSXSub && gpd.sThumbLX < 0 )
			gpd2.sThumbLX = nNewValue;
		if( eAction == Xidf_Act_LSYAdd && gpd.sThumbLY > 0 )
			gpd2.sThumbLY = nNewValue;
		if( eAction == Xidf_Act_LSYSub && gpd.sThumbLY < 0 )
			gpd2.sThumbLY = nNewValue;
		if( eAction == Xidf_Act_RSXAdd && gpd.sThumbRX > 0 )
			gpd2.sThumbRX = nNewValue;
		if( eAction == Xidf_Act_RSXSub && gpd.sThumbRX < 0 )
			gpd2.sThumbRX = nNewValue;
		if( eAction == Xidf_Act_RSYAdd && gpd.sThumbRY > 0 )
			gpd2.sThumbRY = nNewValue;
		if( eAction == Xidf_Act_RSYSub && gpd.sThumbRY < 0 )
			gpd2.sThumbRY = nNewValue;
	}
}
int xidf_StrToLimit( const char* inp, int eAct )
{
	int limit3 = -1;
	float fFrac = 0.0f;
	if( strchr( inp, '.' ) ){
		fFrac = atof( inp );
	}else if( strchr( inp, '%' ) ){
		fFrac = ( 0.01f * atoi( inp ) );
	}else{
		limit3 = atoi( inp );
	}
	if( xidf_IsStickAction( eAct ) ){
		limit3 = ( fFrac ? static_cast<int>( fFrac * Xidf_MaxStickPos ) : limit3 );
		limit3 = std::max<int>( 0, std::min<int>( Xidf_MaxStickPos, limit3 ) );
		limit3 = ( limit3 ? limit3 : XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE );
		//XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE
	}else if( xidf_IsTriggerAction( eAct ) ){
		limit3 = ( fFrac ? static_cast<int>( fFrac * Xidf_MaxTriggerPos ) : limit3 );
		limit3 = std::max<int>( 0, std::min<int>( Xidf_MaxTriggerPos, limit3 ) );
		limit3 = ( limit3 ? limit3 : XINPUT_GAMEPAD_TRIGGER_THRESHOLD );
	}
	return limit3;
}
Xidf_Modkey* xidf_FindModkeyById( int ident )
{
	assert( XidfData );
	std::vector<Xidf_Modkey>::iterator a;
	a = std::find_if( XidfData->modkeys3.begin(), XidfData->modkeys3.end(),
			[&]( const Xidf_Modkey& a )->bool{
				return a.ident3 == ident;
	});
	if( a != XidfData->modkeys3.end() ){
		return &*a;
	}
	return 0;
}
bool xidf_IsAnalogueActionType( int eBtn )
{
	std::vector<int>::const_iterator a;
	a = std::find( xidf_ActionIsStick.begin(), xidf_ActionIsStick.end(), eBtn );
	if( a == xidf_ActionIsStick.end() ){
		a = std::find( xidf_ActionIsTrigger.begin(), xidf_ActionIsTrigger.end(), eBtn );
		if( a == xidf_ActionIsTrigger.end() ){
			return 0;
		}
	}
	return 1;
}

bool
xidf_ParseTrInputs( const hxdw_IniData2& ini3, std::vector<Xidf_TrInput>& trOut, std::string* err2 )
{
	char bfr[512];
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srSecNameBgn2 = hxdw_TrimStr("s_input_tr:0", ":0", "R", -1 );
	std::vector<std::string> secnames = ini3.getSectionsByNamePrefix( srSecNameBgn2.c_str() );
	int nNr = 0;
	std::vector<std::string>::const_iterator a;
	for( a = secnames.begin(); a != secnames.end(); ++a, nNr++ ){
		std::string sname = *a;
		Xidf_TrInput tr2;
		std::string srMode  = ini3.getValue( sname.c_str(), "eTIMode" );
		std::string srHotk2 = ini3.getValue( sname.c_str(), "szHotkey2" );
		tr2.eOutputTy = xidf_StrToTrInputMode( srMode.c_str() );
		if( !tr2.eOutputTy ){
			sprintf_s( bfr, sizeof(bfr), "Unknown input-translation mode, [%s].eTIMode", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		if( !srHotk2.empty() ){ // allows no-hotkey tr-input.
			if(!xidf_ParseTriggerSequence( srHotk2.c_str(), tr2.trigger4, &err3, "" )){
				sprintf_s( bfr, sizeof(bfr), "Failed parsing trigger for tr-input, "
							"[%s].szHotkey2", sname.c_str() );
				err3 = bfr;
				return 0;
			}
		}
		std::string srInputs = ini3.getValue( sname.c_str(), "szInputs" );
		if( !xidf_ActionsToArray( srInputs.c_str(), ',', tr2.inputs2, &err3 ) ){
			sprintf_s( bfr, sizeof(bfr), "Failed parsing inputs, [%s].szInputs. [%s]", sname.c_str(), err3.c_str() );
			err3 = bfr;
			return 0;
		}
		if( tr2.inputs2.empty() ){
			sprintf_s( bfr, sizeof(bfr), "No input names. Empty: [%s].szInputs", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		tr2.nMovementPerSec = atoi( ini3.getValue( sname.c_str(), "nMovementPerSec").c_str() );
		tr2.nMovementPerSec = ( tr2.nMovementPerSec ? tr2.nMovementPerSec : 512 );
		//tr2.eIntrplTy =

		tr2.ident5 = ++XidfData->nLastTr2Id;
		trOut.push_back( tr2 );
	}
	return 1;
}

int xidf_Reinterpolate( int val, int deadzone2, int nMaxPosition )
{
	int nMul = ( val < 0 ? -1 : 1 );
	val = std::abs( val );
	float frac = ( float(val-deadzone2) / (nMaxPosition-deadzone2) );
	val = int( frac * nMaxPosition * nMul );
	return val;
}
bool
xidf_IsTriggerDown( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd, std::vector<int>* aPerTrgrDn2 )
{
	const Xidf_ModkeyDown* modd;
	std::vector<int> aSink, *aPerTrgrDn = ( aPerTrgrDn2 ? aPerTrgrDn2 : &aSink );
	bool bLive4 = 1;
	for( const auto& b : trgr.modkeyIds ){ // Xidf_Trigger
		modd = Xidf_ModkeyDown::findModkey( b, &XidfData->aModsDown[0], XidfData->aModsDown.size() );
		if( modd && modd->bDown2 ){
			aPerTrgrDn->push_back( modd->mod2->btnActivator );
		}else{
			bLive4 = 0;
			break;
		}
	}
	for( const auto& b : trgr.buttons2 ){
		if( !xidf_IsActionDown( b, gpd, {-1,-1,} ) ){
			bLive4 = 0;
			break;
		}else{
			aPerTrgrDn->push_back( b );
		}
	}
	return bLive4;
}
// FG-Squircular mapping
// mapping a square region to a circular disc
// input: (x,y) coordinates in the square
// output: (u,v) coordinates in the circle
// http://squircular.blogspot.com/2015/09/fg-squircle-mapping.html
void xidf_FgsSquareToDisc( double x, double y, double& xo, double& yo )
{
	if( x == 0.0 && y == 0.0 ){
		xo = yo = 0.0;
		return;
	}
	double xm = x < 0 ? -1 : 1;
	double ym = y < 0 ? -1 : 1;
	x = std::abs(x);
	y = std::abs(y);
	double maxv = std::max<double>(x,y);
	x /= maxv;
	y /= maxv;

	double u = x, v = y;
    double x2 = x * x;
    double y2 = y * y;
    double r2 = x2 + y2;
    double rad = sqrt( r2 - x2 * y2);
    double epsilon2 = std::numeric_limits<double>::epsilon();

    // avoid division by zero if (x,y) is closed to origin.
    if( r2 < epsilon2 ){
        //
    }else{
		// This code is amenable to the fast reciprocal sqrt floating point trick
		// https://en.wikipedia.org/wiki/Fast_inverse_square_root
		double reciprocalSqrt =  1.0/sqrt(r2);
		u = x * rad * reciprocalSqrt;
		v = y * rad * reciprocalSqrt;
	}
	u *= maxv * xm;
	v *= maxv * ym;
	xo = u;
	yo = v;
}
bool
xidf_PerformTrInputLive( Xidf_TrInputLive& tr3, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 )
{
	if( xidf_IsTriggerDown( tr3.trInput2->trigger4, gpd, 0 ) ){
		if( tr3.trInput2->eOutputTy == Xidf_TI_MouseMove ){ // "eMouseMotion"
			uint64_t nTmPos  = hxdw_GetTimeTicksUs();
			uint64_t nDeltaTMsecs = ( tr3.bLive3.second ? nTmPos - tr3.bLive3.second : 0 );
			float    fDeltaTSecs = float( double(nDeltaTMsecs) / 1000000.0 );
			if( fDeltaTSecs ){
				// get delta x and y using 4 inputs, specified previously in config.
				// all 4 map to up,right,down and left, in that order, respectivelly.
				const std::vector<int>& in2 = tr3.trInput2->inputs2;
				float upp    = ( in2.size() >= 1 ? xidf_GetInputValueForAction( in2[0], gpd ).second : 0.f );
				float rightt = ( in2.size() >= 2 ? xidf_GetInputValueForAction( in2[1], gpd ).second : 0.f );
				float downn  = ( in2.size() >= 3 ? xidf_GetInputValueForAction( in2[2], gpd ).second : 0.f );
				float leftt  = ( in2.size() >= 4 ? xidf_GetInputValueForAction( in2[3], gpd ).second : 0.f );
				double dx2 = (rightt - leftt) * fDeltaTSecs;
				double dy2 = (downn  - upp  ) * fDeltaTSecs;
				//eIntrplTy
				xidf_FgsSquareToDisc( dx2, dy2, dx2, dy2 );
				int dx3 = static_cast<int>( dx2 * tr3.trInput2->nMovementPerSec );
				int dy3 = static_cast<int>( dy2 * tr3.trInput2->nMovementPerSec );

				//printf("dxdy: %f, %f\n", dx2, dy2 );
				//xCircle = xSquare * sqrt(1 - 0.5*ySquare^2)
				//yCircle = ySquare * sqrt(1 - 0.5*xSquare^2)
				//https://stackoverflow.com/questions/1621831/how-can-i-convert-coordinates-on-a-square-to-coordinates-on-a-circle
				//float dx4 = float(dx3) * sqrtf( 1.0 - 0.5 * pow(dy3,2) );
				//float dy4 = float(dy3) * sqrtf( 1.0 - 0.5 * pow(dx3,2) );

				hxdw_SendMouseDeltaInput( { dx3, dy3,} );
				//float len = sqrt( pow( dx3, 2 ) + pow( dy3, 2 ) );
				//printf("dxdy: %-2d, %-2d, len:%f, %d\n",
				//		dx3, dy3, (float)len, (int)nDeltaTMsecs );
			}
		}else{
			assert(0);
		}
		tr3.bLive3 = { 1, hxdw_GetTimeTicksUs(),};
	}else{
		if( tr3.bLive3.first ){
			//printf("down2.\n");
			tr3.bLive3 = {0,0,};
		}
	}
	return 1;
}
int xidf_ApplyDeadZoneIfNeeded( int val, int deadzone2, int nMaxPosition )
{
	if( std::abs( val ) <= deadzone2 ){
		val = 0;
	}else if( nMaxPosition ){
		val = xidf_Reinterpolate( val, deadzone2, nMaxPosition );
	}
	return val;
}
int xidf_GetMouseFlags( int nMButton, const char* flags2 )
{
	bool bUp = !!strchr( flags2, 'u' );
	for( const auto& a : xidf_MButtonBits ){
		if( a.first == nMButton ){
			return ( !bUp ? a.second.first : a.second.second );
		}
	}
	return 0;
}
int xidf_FindModkeyByName( const char* modkname, const std::vector<Xidf_Modkey>& modkeys_ )
{
	for( const auto& a : modkeys_ ){
		if( a.rename2 == modkname ){
			return a.ident3;
		}
	}
	return 0;
}
void xidf_PerformCleanup()
{
	assert(XidfData);
	char bfrFl[32];
	uint64_t nTmNow = hxdw_GetTimeTicksUs();
	for( auto& rtne4 : XidfData->aRoutinesLive ){
		// Test keys for when need to terminate with key-up action.
		for( auto a = rtne4.aSendksLive.begin(); a != rtne4.aSendksLive.end(); ){
			auto endd = rtne4.routine2->aSendVk.end();
			auto b = std::find_if( rtne4.routine2->aSendVk.begin(), endd,
					[&]( const Xidf_SendKey& b ){
							return b.ident6 == a->first;
			});
			assert( b != endd );
			uint64_t nTmEnd = a->second + b->nIntrvl * 1000;
			if( nTmNow >= nTmEnd ){
				if( b->nMouseBtn ){
					int nMFlg = xidf_GetMouseFlags( b->nMouseBtn, "u" );
					hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
				}else{
					sprintf_s( bfrFl, sizeof(bfrFl), "u%s%s",
									( XidfData->bKeysUseWM ? "p" : "" ),
									( XidfData->bKeysUseSC ? "s" : "" ) );
					hxdw_SendKeyboardInput( {{ b->nVk, 0,},}, bfrFl ); //send key up. "u"
				}
				a = rtne4.aSendksLive.erase(a);  //Xidf_SendKey
			}else{
				++a;
			}
		}
	}
}
int xidf_StrToKeyAction( const char* inp )
{
	int len = strlen(inp);
	if( !len )
		return 0;
	if( len == 1 ){
		char chr = *inp;
		if( chr >= 'a' && chr <= 'z' ){
			int vkc = ( 0x41 + ( chr - 'a' ) );  // 0x41: VK_A
			return vkc;
		}else if( chr >= 'A' && chr <= 'Z' ){
			int vkc = ( 0x41 + ( chr - 'A' ) );  // 0x41: VK_A
			return vkc;
		}else if( chr >= '0' && chr <= '9' ){
			int vkc = ( 0x30 + ( chr - '0' ) ); // 0x30: VK_0
			return vkc;
		}
	}else if( len == 2 && strchr("Nn", inp[0] ) && strchr("0123456789", inp[1] ) ){
		// VK_NUMPAD0 - VK_NUMPAD9
		int vkc = ( VK_NUMPAD0 + ( inp[1] - '0' ) );
		return vkc;
	}else{
		if( len >= 2 && strchr("Ff", inp[0] ) && strchr("0123456789", inp[1] ) ){
			// VK_F1 - VK_F24
			int num = atoi( &inp[1] );
			if( num >= 1 && num <= 24 ){
				int vkc = ( VK_F1 + (num - 1) );
				return vkc;
			}
		}
		for( const auto& a : xidf_KeyNames ){
			for( auto b = a.second.begin(); b != a.second.end(); ++b ){
				if( !lstrcmpi( inp, b->c_str() ) ){
					return a.first;
				}
			}
		}
		if( len >= 2 && strchr("0123456789", inp[0] ) ){
			// if any number starting string, at least 2 characters long.
			return atoi( inp );
		}
	}
	return 0;
}
int xidf_StrToMouseButtonAction( const char* inp )
{
	int len = strlen(inp);
	if( len == 2 && strchr("Mm", inp[0] ) && strchr("123456789", inp[1] ) ){
		return atoi( &inp[1] );
	}
	return 0;
}
bool xidf_StrToInputList( const char* szBtnNames, char glue2,
							std::vector<Xidf_Input>& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btns;
	hxdw_StrExplode( szBtnNames, btns, {glue2,}, -1, "\x20\t" );
	for( const auto& a : btns ){
		int actn;
		if( (actn = xidf_StrToGamepadAction( a.c_str() )) ){
			outp.push_back( Xidf_Input( Xidf_IT_Gamepad, actn ) );
		}else if( (actn = xidf_StrToKeyAction( a.c_str() )) ){
			outp.push_back( Xidf_Input( Xidf_IT_Key, actn ) );
		}else if( (actn = xidf_StrToMouseButtonAction( a.c_str() )) ){
			outp.push_back( Xidf_Input( Xidf_IT_MouseButton, actn ) );
		}else{
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr), "Unrecognizaed input name '%s'. "
						"Eg. can be gamepad button.", a.c_str() );
			err3 = bfr;
			return 0;
		}
	}
	return 1;
}

void
xidf_RoutineLiveOnDown( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm__,
							const XINPUT_GAMEPAD& gpd__, XINPUT_GAMEPAD& gpd2__ )
{
	uint64_t uTmNow = hxdw_GetTimeTicksUs();
	char bfrFl[32];
	for( const auto& a : rtne2.routine2->aSendVk ){
		auto b = std::find_if( rtne2.aSendksLive.begin(), rtne2.aSendksLive.end(),
				[&]( const std::pair<int,uint64_t>& c ){
						return c.first == a.ident6;
		});
		if( a.nMouseBtn ){
			int nMFlg = xidf_GetMouseFlags( a.nMouseBtn, "" );
			hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
		}else{
			sprintf_s( bfrFl, sizeof(bfrFl), "%s%s",
							( XidfData->bKeysUseWM ? "p" : "" ),
							( XidfData->bKeysUseSC ? "s" : "" ) );
			hxdw_SendKeyboardInput( { { a.nVk, 0,},}, bfrFl );
		}
		if( b != rtne2.aSendksLive.end() ){
			b->second = uTmNow;
		}else{
			rtne2.aSendksLive.push_back( { a.ident6, uTmNow,} );
		}
	}
	for( const auto& a : rtne2.routine2->aHold2 ){ //Xidf_Input
		if( a.type2 == Xidf_IT_Key ){
			sprintf_s( bfrFl, sizeof(bfrFl), "%s%s",
							( XidfData->bKeysUseWM ? "p" : "" ),
							( XidfData->bKeysUseSC ? "s" : "" ) );
			hxdw_SendKeyboardInput( {{ a.input2, 0,},}, bfrFl );
		}else if( a.type2 == Xidf_IT_MouseButton ){
			int nMFlg = xidf_GetMouseFlags( a.input2, "" );
			hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
		}
	}
}
void
xidf_RoutineLiveOnUp( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm__,
							const XINPUT_GAMEPAD& gpd__, XINPUT_GAMEPAD& gpd2__ )
{
	char bfrFl[32];
	for( const auto& a : rtne2.routine2->aHold2 ){ //Xidf_Input
		if( a.type2 == Xidf_IT_Key ){
			sprintf_s( bfrFl, sizeof(bfrFl), "u%s%s",
							( XidfData->bKeysUseWM ? "p" : "" ),
							( XidfData->bKeysUseSC ? "s" : "" ) );
			hxdw_SendKeyboardInput( {{ a.input2, 0,},}, bfrFl );
		}else if( a.type2 == Xidf_IT_MouseButton ){
			int nMFlg = xidf_GetMouseFlags( a.input2, "u" );
			hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
		}
	}
}
void
xidf_RoutineLivePerform( const Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm,
							const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 )
{
	assert( rtne2.routine2 );
	auto lsInputs = xidf_GetValuesForRoutine( rtne2.routine2->trigger2, gpd );
	float fFirstVal = ( !lsInputs.empty() ? lsInputs[0].second : 0.0f );
	for( const auto& a : rtne2.routine2->aHold2 ){
		if( a.type2 == Xidf_IT_Gamepad ){
			xidf_SetGamepadValue2( a.input2, fFirstVal, gpd, gpd2 );
		}
	}
	for( const auto& a : rtne2.routine2->aSuppress ){
		xidf_SetGamepadValue( a, 0, gpd, gpd2 );
	}
}
std::vector<std::pair<int,float> >
xidf_GetValuesForRoutine( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd )
{
	std::vector<std::pair<int,float> > outp;
	const Xidf_ModkeyDown* modd;
	std::pair<int,float> val;
	for( int id3 : trgr.modkeyIds ){
		modd = Xidf_ModkeyDown::findModkey( id3, &XidfData->aModsDown[0], XidfData->aModsDown.size() );
		assert( modd && modd->mod2 );
		assert( modd->mod2->btnActivator );
		val = xidf_GetInputValueForAction( modd->mod2->btnActivator, gpd );
		outp.push_back( val );
	}
	for( int id4 : trgr.buttons2 ){
		val = xidf_GetInputValueForAction( id4, gpd );
		outp.push_back( val );
	}
	return outp;
}


