#include "xiei_entrypoint.h"
#include <assert.h>
#include <memory>

const char* szAppName = "Xinput Modkey Installer";
const char* szUsage =
		"Usage\n"
		"-------\n"
		"    program.exe [options] [xxx]\n"
		"    program.exe --ifn FILE\n"
		"    program.exe --ifn FILE --bGetExports [--ofn FILE] \n"
		"    program.exe --ifn FILE --bGetImportDLLs [--ofn FILE] \n"
		"\n"
		"Options\n"
		"-------\n"
		"    xxxxxx  --  xxxxxxxx xxxxxxxxx\n"
		"\n"
		"\n"
		"";
const std::vector<std::string> xinames = {
	"xinput1_3.dll",
	"xinput1_1.dll",
	"xinput1_2.dll",
	"xinput1_4.dll",
	"xinput9_1_0.dll",
};
const char* const aFwrdrNames[] = {
	"xinput_dll_forwarder_32.dll",
	"xinput_dll_forwarder_64.dll",
};
const char* const aXiModkeyNames[] = {
	"xinput_modkey_32.dll",
	"xinput_modkey_64.dll",
};
bool xiei_GetPEFileImports( const char* szFname, std::vector<std::string>& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	HANDLE hf2 = 0; PDETOUR_BINARY pExeBin = 0;
	std::shared_ptr<int> raii2( 0, [&]( int* ){
		if( hf2 ){ CloseHandle( hf2 ); hf2 = 0;}
		if( pExeBin ){  DetourBinaryClose( pExeBin ); pExeBin = 0;}
	} );
	hf2 = CreateFileA( szFname, GENERIC_READ, FILE_SHARE_READ,
					   0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
	if( !hf2 || hf2 == INVALID_HANDLE_VALUE ){
		err3 = "Failed to open input file [fd0sbfx]";
		return 0;
	}
	pExeBin = DetourBinaryOpen( hf2 );
	if( !pExeBin ){
		err3 = "Binary open failed [dbsbDxk]";
		return 0;
	}
	auto func2 = [&]( const char* szDllFname )->bool{
			outp.push_back( szDllFname );
			return 1;
	};
	std::function<bool(const char*)> func3(func2);
	DetourBinaryEditImports( pExeBin, &func3, 0,
			[]( PVOID user2, LPCSTR, LPCSTR szFile, LPCSTR* )->BOOL{
					auto func3 = *reinterpret_cast<std::function<bool(const char*)>*>(user2);
					return func3( szFile );
	}, 0, 0 );
	return 1;
}
bool xiei_GetPEExports( const char* pathname, std::vector<std::string>& outp )
{
	HMODULE hDll = LoadLibraryExA( pathname, 0, DONT_RESOLVE_DLL_REFERENCES );
	if( !hDll )
		return 0;
	using Fnc2_t = std::function<bool(int, const char*)>;
    auto fnc2 = Fnc2_t( [&]( int nOrdinal, const char* szExportName )->bool{
			outp.push_back( szExportName );
			return 1;
	});
	DetourEnumerateExports( hDll, &fnc2,
			[]( PVOID user2, ULONG nOrdinal, LPCSTR pszSymbol, PVOID pbTarget )->BOOL{
					Fnc2_t* fnc2 = reinterpret_cast<Fnc2_t*>( user2 );
					assert(fnc2);
					return (*fnc2)( static_cast<int>(nOrdinal), pszSymbol );
	});
	FreeLibrary(hDll);
	return 1;
}
bool xiei_IsDLLXinputModkeyFilter( const char* pathname )
{
	std::vector<std::string> exports2;
	if( xiei_GetPEExports( pathname, exports2 ) ){
		for( const auto& a : exports2 ){
			if( a == "xidf_dll_dummy" )
				return 1;
		}
	}
	return 0;
}
bool xiei_IsDLLXinputModkeyForwarder( const char* pathname )
{
	std::vector<std::string> exports2;
	if( xiei_GetPEExports( pathname, exports2 ) ){
		for( const auto& a : exports2 ){
			if( a == "xifw_dll_dummy" )
				return 1;
		}
	}
	return 0;
}
bool
xiei_GeXinputDllNameForPE( const char* szPEPath, std::string* srDllNameOu, std::string* err2 )
{
	std::vector<std::string> fnames; //std::string err2;
	if( !xiei_GetPEFileImports( szPEPath, fnames, err2 ) ){
		return 0;
	}
	for( const auto& a : fnames ){
		auto b = std::find_if( xinames.begin(), xinames.end(), [&]( const std::string& b )->bool{
				return !lstrcmpi( a.c_str(), b.c_str() );
		});
		if( b != xinames.end() ){
			*srDllNameOu = a;
			return 1;
		}
	}
	return 1;
}
std::string
xiei_StrPrintf( const char* fmt, std::vector<std::pair<const char*,int64_t> > args3 )
{
	std::string outp;
	int pos2 = 0, pos3 = 0, iArg = 0;
	const char* sz2 = fmt, *sz3 = 0;
	char bfr[256];
	for( const auto& a : args3 ){
		if( !(sz3 = strchr( sz2, '%' )) ){
			break;
		}
		if( !strchr( "ads", sz3[1] ) )
			break;
		outp.append( sz2, sz3-sz2 );
		sz2 = sz3 + 2;
		std::string arg;
		if( a.first ){
			arg = a.first;
		}else{
			sprintf_s( bfr, sizeof(bfr), "%lld", a.second );
			arg = bfr;
		}
		outp += arg;
		iArg++;
	}
	outp.append( sz2 );
	return outp;
}
/**
	Copies batch of files specified by input array.
	\param inp - list of pairs. for each, 'first' is full path to
	       source, existsing file, while 'second' is only base name for
	       new file.
	\param szDstDir - destination directory name.
*/
bool xiei_CopyFilesToDir( const std::vector<std::pair<std::string,std::string> >& inp, const char* szDstDir, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	for( const auto& a : inp ){
		std::string bn2 = hxdw_SplitPath(a.first.c_str()).second;
		std::string bn3 = a.second;
		std::string newfname = xiei_StrPrintf("%s\\%s", {{szDstDir,0,},{bn3.c_str(),0,},} );
	//	if( hxdw_FileExists( newfname.c_str() ) ){
	//		if( !DeleteFile( newfname.c_str() ) ){
	//			err3 = xiei_StrPrintf("File delete on copy failed [%s].",
	//					{{bn2.c_str(),0,},} );
	//			return 0;
	//		}
	//	}
		if( !CopyFile( a.first.c_str(), newfname.c_str(), 0 ) ){
			err3 = xiei_StrPrintf("Can't copy file '%s'.", {{bn2.c_str(),0,},} );
			return 0;
		}
	}
	return 1;
}
int main( int argc, const char*const* argv )
{
	std::string str;
	const bool bHlp = !hxdw_GetArgvByName( {"-h","/h","-?","/?","-help","--help",}, argc, argv, "ib" ).empty();
	if( bHlp ){
		str = "";
		str.resize( strlen(szAppName), '-' );
		printf("%s\n", szAppName );
		printf("%s\n", str.c_str() ); //-------------
		printf("Build: %s\n", __DATE__ );
		printf("\n");
		printf("%s", szUsage );
		return 2;
	}
	HWND hwnd = GetForegroundWindow();
	std::string ifn, ofn, srGameDir, err2;
	std::string srSrcFrwrdr, srSrcFilter, srTrgtFrwrdr, srTrgtFltr;
	bool bIsX64Binary = 0, bGetExports = 0, bGetImportDLLs = 0;
	ifn = hxdw_GetArgvByName( {"--ifn",}, argc, argv, "i" );
	bGetExports = !hxdw_GetArgvByName( {"--bGetExports",}, argc, argv, "ib" ).empty();
	bGetImportDLLs = !hxdw_GetArgvByName( {"--bGetImportDLLs",}, argc, argv, "ib" ).empty();
	ofn = hxdw_GetArgvByName( {"--ofn",}, argc, argv, "i" );
	if( ifn.empty() ){
		str = xiei_StrPrintf("Select Executable File - %s", {{szAppName,0,},} );
		ifn = hxdw_OpenFileNameWithUI( "", str.c_str(), "*.EXE;*.DLL", hwnd );
		if( ifn.empty() ){
			printf("XIEI: Cancelled.\n" );
			return 5;
		}
	}
	if( ifn.empty() ){
		std::string msg = "ERROR: No input file (see --ifn FILE) [5fjao964]";
		printf("XIEI: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 4;
	}
	if( bGetExports || bGetImportDLLs ){
		//printf("XIEL: bGetExports: yes\n");
		std::vector<std::string> exports3;
		if( bGetExports ){
			xiei_GetPEExports( ifn.c_str(), exports3 );
		}else{ // == bGetImportDLLs
			//printf("XIEL: bGetImportDLLs: Yes\n");
			xiei_GetPEFileImports( ifn.c_str(), exports3, 0 );
		}
		std::string data2;
		for( const auto& a : exports3 ){
			data2 += a + "\n";
		}
		if( ofn.empty() ){
			printf("%s\n", data2.c_str() );
		}else{
			hxdw_PutFileContents( ofn.c_str(), data2.c_str(), (int)data2.size() );
		}
		return 0;
	}
	srGameDir = hxdw_SplitPath( ifn.c_str() ).first;
	printf("XIEI: Accessing: [%s]\n", hxdw_StrLTruncate(ifn,54).c_str() );
	{
		DWORD eType = 0;
		if( !GetBinaryTypeA( ifn.c_str(), &eType ) ){
			std::string msg = xiei_StrPrintf(
					"Failed reading binary file information [1kfe0Mgc]\n"
					"File name: [%s]\n", {{ifn.c_str(),0,},} );
			printf("ERROR: %s\n", msg.c_str() );
			MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
			return 4;
		}
		if( eType == SCS_32BIT_BINARY ){ // win32/x86
			bIsX64Binary = 0;
		}else if( eType == SCS_64BIT_BINARY ){ // win64/x64
			bIsX64Binary = 1;
		}else{
			std::string msg =
					"Architecture not supported.\n"
					"It can be either x86 or x64 [ma4qfGPg]\n";
			printf("ERROR: %s\n", msg.c_str() );
			MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
			return 4;
		}
		printf("Architecture: [%s]\n", (bIsX64Binary ? "x64": "x86") );
	}
	if( !xiei_GeXinputDllNameForPE( ifn.c_str(), &srTrgtFrwrdr, &err2 ) ){
		std::string msg = xiei_StrPrintf("XIEI: ERROR: [%s] [pJ9GtYqQ]", {{err2.c_str(),0,},} );
		printf("XIEI: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 4;
	}
	srTrgtFrwrdr = hxdw_StrToLower( srTrgtFrwrdr );
	if( srTrgtFrwrdr.empty() ){
		std::string msg =
				"      This game/program seems to not be using Xinput [1lt9kdAx].\n"
				"      None of supported Xinput DLL names has been found in the \n"
				"      import table. Cannot continue.\n";
		printf("%s", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 5;
	}
	printf("XIEI: Forwarder xinpput DLL file name: [%s]\n", srTrgtFrwrdr.c_str() );

	{
		if( argc >= 1 ){
			std::string srAssetsDir;
			srAssetsDir = argv[0];
			srAssetsDir = hxdw_SplitPath( srAssetsDir.c_str() ).first;
			srAssetsDir = ( !srAssetsDir.empty() ? std::string("assets") : srAssetsDir + "\\assets" );
			srSrcFrwrdr = xiei_StrPrintf("%s\\%s", {
					{srAssetsDir.c_str(),0,},
					{(!bIsX64Binary ? aFwrdrNames[0] : aFwrdrNames[1] ),0,},} );
			srSrcFilter = xiei_StrPrintf("%s\\%s", {
					{srAssetsDir.c_str(),0,},
					{(!bIsX64Binary ? aXiModkeyNames[0] : aXiModkeyNames[1] ),0,},} );
		}
		if( !hxdw_FileExists( srSrcFrwrdr.c_str() ) ){
			std::string msg = "Forwarder DLL not found [jHT0Aa00].";
			printf("ERROR: %s\n", msg.c_str() );
			MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
			return 4;
		}
		if( !hxdw_FileExists( srSrcFilter.c_str() ) ){
			std::string msg = "Filter DLL not found [6U5rXl38].";
			printf("ERROR: %s\n", msg.c_str() );
			MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
			return 4;
		}
	}
	srTrgtFrwrdr = xiei_StrPrintf("%s\\%s", {{srGameDir.c_str(),0,},{srTrgtFrwrdr.c_str(),0,},} );
	srTrgtFltr = xiei_StrPrintf("%s\\xinput_modkey.dll", {{srGameDir.c_str(),0,},} );
	printf("\n");
	printf("Filter       : [%s]\n", hxdw_StrLTruncate( srSrcFilter.c_str(),54).c_str() );
	printf("Forwarder    : [%s]\n", hxdw_StrLTruncate( srSrcFrwrdr.c_str(),54).c_str() );
	printf("Architecture : [%s]\n", (bIsX64Binary ? "x64" : "x86" ) );
	printf("Filter-r     : [%s]\n", hxdw_StrLTruncate( srTrgtFltr,54).c_str() );
	printf("Forwarder-t  : [%s]\n", hxdw_StrLTruncate( srTrgtFrwrdr,54).c_str() );
	printf("\n");
	{
		std::string msg =
				"This isntaller does not modify any existing files "
				"in the selected game/program folder. It only copies 2 new files "
				"that are needed for Xinput-Modkey to function correctly.\n"
				"\n"
				"Press OK to continue and copy files.";
		if( IDOK != MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONINFORMATION|MB_OKCANCEL)){
			printf("XIEI: Cancelled.\n" );
			return 5;
		}
	}
	{
		std::vector<std::string> testfiles = { srTrgtFrwrdr, srTrgtFltr,};
		for( const auto& a : testfiles ){
			if( hxdw_FileExists( a.c_str() ) ){
				bool bKnown = 0;
				bKnown = xiei_IsDLLXinputModkeyFilter( a.c_str() );
				bKnown = ( !bKnown ? xiei_IsDLLXinputModkeyForwarder(a.c_str()) : bKnown );
				if( !bKnown ){
					std::string msg = xiei_StrPrintf(
						"There is already an existing DLL file inside\n"
						"the targer program/game folder that is not part\n"
						"of the Xinput-Modkey installation.\n"
						"File name: '%s'.\n"
						"This installer won't continue to auto replace it [5dLm8bxk].\n",
							{{ hxdw_SplitPath( a.c_str() ).second.c_str(),0,},} );
					printf("ERROR: %s\n", msg.c_str() );
					MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
					return 4;
				}
			}
		}
	}
	printf("XIEI: Copying files...\n" );
	bool rs2 = 1;
	rs2 = xiei_CopyFilesToDir(
		std::vector<std::pair<std::string,std::string> >( {
			{ srSrcFilter, hxdw_SplitPath( srTrgtFltr.c_str() ).second,},
			{ srSrcFrwrdr, hxdw_SplitPath( srTrgtFrwrdr.c_str() ).second,},
		} ),
		srGameDir.c_str(), &err2 );
	if( !rs2 ){
		//printf("XIEI: ERROR: File copy failed [4fOa3CRc_]\n");
		//printf("             %s\n", err2.c_str() );
		std::string msg = xiei_StrPrintf(
			"File copy failed [4fOa3CRc]\n"
            "%s\n", {{err2.c_str(),0,},} );
		printf("ERROR: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 4;
	}
	printf("XIEI: Done.\n" );
	MessageBox( hwnd, "Installation completed successfully.", szAppName, MB_ICONINFORMATION );
	return 0;
}





