=======================================
Xinput Modkey - Forwarder DLL
=======================================

	This is a forwarder DLL module that is intended to
	forward Windows|Xinput API calls into "xinput_modkey.dll".

	The only task of this DLL is to load another DLL, "xinput_modkey.dll",
	into process memory. This is done automatically since the DLL is already
	present in the inport table.

	Original Ximput file name can be, for example, "XInput9_1_0.dll".
	Name of this file depends on Xinput version the target program|game
	is using. This is the file name this DLL (forwarder) is needed to
	be renamed to, and stored as, in the target program|game directory.

	Since DEF+DLL forwarding seems to not work,
	forwarding is done by locating the target DLL file by its file name in
	its system directory with the LoadLibrary() Winapi function.

