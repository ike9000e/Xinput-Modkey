#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <string>
#include <vector>

bool        hxdw_GetPEFileImports( const char* szFname, std::vector<std::string>& outp, std::string* err2 );
bool        hxdw_GetPEExports( const char* pathname, std::vector<std::string>& outp );
