#include "xinput_ts_main.h"

CXBOXController* Player1;
int main( int argc, const char*const* argv )
{
	int deadzoneLStk = 0;//XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE; //7849, --deadzone2
	int deadzoneRStk = 0;//XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE; //8689
	int deadzoneTrg = 0;//XINPUT_GAMEPAD_TRIGGER_THRESHOLD; //30

	Player1 = new CXBOXController(1);
	printf("Test your buttons...\n");
	printf("\n");
	while( 1 ){
		std::string srBtns;
		if( Player1->IsConnected() ){
			WORD bts = Player1->GetState().Gamepad.wButtons;
			//if( bts & XINPUT_GAMEPAD_START && bts & XINPUT_GAMEPAD_BACK )
			//	break;
			srBtns +=
					std::string( bts & XINPUT_GAMEPAD_A ? "A," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_B ? "B," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_X ? "X," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_Y ? "Y," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_DPAD_UP ? "UP," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_DPAD_DOWN ? "DOWN," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_DPAD_LEFT ? "LEFT," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_DPAD_RIGHT ? "RIGHT," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_START ? "START," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_BACK ? "BACK," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_LEFT_SHOULDER ? "LSh," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_RIGHT_SHOULDER ? "RSh," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_LEFT_THUMB ? "LTh," : "" ) +
					std::string( bts & XINPUT_GAMEPAD_RIGHT_THUMB ? "RTh," : "" ) +
					"";
			char bfr[128];
			BYTE uLTrg = Player1->GetState().Gamepad.bLeftTrigger;
			if( uLTrg > deadzoneTrg ){
				sprintf( bfr, "LTr:%03d,", (int)(unsigned int)uLTrg );
				srBtns += bfr;
			}
			BYTE uRTrg = Player1->GetState().Gamepad.bRightTrigger;
			if( uRTrg > deadzoneTrg ){
				sprintf( bfr, "RTr:%03d,", (int)(unsigned int)uRTrg );
				srBtns += bfr;
			}
			int nLSX = static_cast<int>( Player1->GetState().Gamepad.sThumbLX );
			int nLSY = static_cast<int>( Player1->GetState().Gamepad.sThumbLY );
			int nRSX = static_cast<int>( Player1->GetState().Gamepad.sThumbRX );
			int nRSY = static_cast<int>( Player1->GetState().Gamepad.sThumbRY );

			if( std::abs(nLSX) > deadzoneLStk || std::abs(nLSY) > deadzoneLStk ){
				sprintf( bfr, "LS:(%6d,%6d),", nLSX, nLSY );
				srBtns += bfr;
			}
			if( std::abs(nRSX) > deadzoneRStk || std::abs(nRSY) > deadzoneRStk ){
				sprintf( bfr, "RS:(%6d,%6d),", nRSX, nRSY );
				srBtns += bfr;
			}
			for( int iVk=1; iVk < 256; iVk++ ){
				SHORT nDwn = GetAsyncKeyState(iVk);
				if( nDwn & 0x8000 ){
					sprintf( bfr, "k%d,", iVk );
					srBtns += bfr;
				}
			}
		}else{
			printf("\n");
			printf("ERROR! PLAYER 1 - XBOX 360 Controller Not Found!\n");
			printf("Press Any Key To Exit.\n");
			delete(Player1);
			return 181;
		}
		srBtns.resize(64,'_');
		printf("\r%s", srBtns.c_str() );
		//Sleep(100);
		//Sleep(17); // 1000/60=16.66
		Sleep(16);
	}
	delete(Player1);
	return 0;
}
