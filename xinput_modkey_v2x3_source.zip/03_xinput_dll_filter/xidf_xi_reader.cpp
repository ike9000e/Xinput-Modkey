#include "xidf_xi_reader.h"
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <vector>
#include <string>
#include <stdint.h>
#include <stdio.h>
#include <windows.h>
#include <xinput.h>
#include "hxdw/hxdw_utils.h"
#include "xidf_functions.h"

bool xidf_XiInternalInit()
{
	if( !XidfData->sXiRd.bXiEnabled )
		return 1;
	if( XidfData->sXiRd.eScrapMode == Xidf_P2_Thread ){
		XidfData->sXiRd.hScrapThr = CreateThread( 0,0, []( void* )->DWORD{
				//
				for( ;; ){
					xidf_XiInternalPerform();
					uint32_t uMillis = (uint32_t) XidfData->sXiRd.fSleepIntervalMs;
					Sleep( uMillis );
					if( !XidfData->sXiRd.bRunThr )
						break;
				}
				return 0;
		}, 0, 0, 0 );
	}else if( XidfData->sXiRd.eScrapMode == Xidf_P2_TranslateMsgApi ){
		//DetourTransactionBegin();
		//DetourUpdateThread( GetCurrentThread() );
		//DetourAttach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
		//DetourTransactionCommit();
	}
	return 1;
}
bool xidf_XiInternalPerform()
{
	if( !XidfData->sXiRd.bXiEnabled )
		return 1;
	XINPUT_STATE xse;
	memset( &xse, 0, sizeof(XINPUT_STATE) );
	XInputGetState( 0, &xse );
	return 1;
}
bool xidf_XiInternalDeinit()
{
	if( !XidfData->sXiRd.bXiEnabled )
		return 1;
	if( XidfData->sXiRd.hScrapThr ){
		XidfData->sXiRd.bRunThr = 0;
		for( ;; ){ // spin and wait for thread to terminate itself.
			DWORD rslt = WaitForSingleObject( XidfData->sXiRd.hScrapThr, 0 );
			if( rslt == WAIT_OBJECT_0 ){
				// if the thread handle is signaled - the thread has terminated.
				// else the thread handle is not signaled - the thread is still alive.
				break;
			}
			uint32_t msWait = (uint32_t)( XidfData->sXiRd.fSleepIntervalMs / 2.0 );
			Sleep( msWait );
		}
	}
	return 1;
}




