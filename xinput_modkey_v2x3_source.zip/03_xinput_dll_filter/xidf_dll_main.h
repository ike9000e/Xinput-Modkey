#include "xidf_functions.h"
#pragma once

/*
typedef struct _XINPUT_STATE {
  DWORD          dwPacketNumber;
  XINPUT_GAMEPAD Gamepad;
} XINPUT_STATE, *PXINPUT_STATE;
typedef struct _XINPUT_GAMEPAD {
  WORD  wButtons;
  BYTE  bLeftTrigger;
  BYTE  bRightTrigger;
  SHORT sThumbLX;
  SHORT sThumbLY;
  SHORT sThumbRX;
  SHORT sThumbRY;
} XINPUT_GAMEPAD, *PXINPUT_GAMEPAD;
*/

//DWORD XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, PXINPUT_KEYSTROKE pKeystroke );
//Xinput1_3.dll, Xinput1_4.dll, XInputGetKeystroke
//https://docs.microsoft.com/en-us/windows/desktop/api/xinput/nf-xinput-xinputgetkeystroke
//using XInputGetKeystroke_t = DWORD( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke );
//DWORD (WINAPI*  ori_XInputGetKeystroke)( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke ) = XInputGetKeystroke;
//DWORD WINAPI    xidf_XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke );

// XInputGetState()
using XInputGetState_t = DWORD __stdcall( DWORD dwUserIndex,XINPUT_STATE *pState );
DWORD (WINAPI*  ori_XInputGetState)( DWORD dwUserIndex,XINPUT_STATE *pState ) = XInputGetState;
DWORD WINAPI    xidf_XInputGetState( DWORD dwUserIndex,XINPUT_STATE *pState );

bool xidf_InitData( HINSTANCE hInst );
auto xidf_GetLocalTimeStr() -> std::string;
void xidf_LogMessage( const char* flags2, const char* szMsg );
