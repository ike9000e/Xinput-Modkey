#pragma once

bool xidf_XiInternalInit();
bool xidf_XiInternalPerform();
bool xidf_XiInternalDeinit();
