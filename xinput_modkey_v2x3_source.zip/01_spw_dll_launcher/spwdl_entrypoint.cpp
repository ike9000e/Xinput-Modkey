#include "spwdl_entrypoint.h"

const char* szAppName = "SPWDL - Start Process With DLL Launcher";
const char* szUsage =
		"Usage\n"
		"-------\n"
		"\n"
		"    spwd_launcher.exe --dll2 <FILE> [--nowait] -- <commandline>\n"
		"    spwd_launcher.exe --ts2\n"
		"\n"
		"Options\n"
		"-------\n"
		"\n"
		"\n"
		"    --dll2 <FILE>  :  Specify name of a DLL file to load.\n"
		"    --nowait       :  Optional. don't wait for the process to finish.\n"
		"                      Otherwise, tries to return the value returned\n"
		"                      by the target process\n"
		"    --ts2          :  Causes to return current timestamp in \n"
		"                      milliseconds, POSIX format, and exits.\n"
		"\n"
		"Examples\n"
		"--------\n"
		"    spwd_launcher.exe --dll2 my_dll.dll -- c:/windows/notepad.exe\n"
		"\n"
		"";

int main( int argc, const char*const* argv )
{
	bool bHlp = !hxdw_GetArgvByName( {"-h","/h","-?","/?","-help","--help",}, argc, argv, "ib" ).empty();
	if( argc <= 1 || bHlp ){
		std::string str;
		str.resize( strlen(szAppName), '-' );
		printf("%s\n", szAppName );
		printf("%s\n", str.c_str() );
		printf("Build: %s\n", __DATE__ );
		printf("\n");
		printf("%s", szUsage );
		return 2;
	}
	bool bTs2 = !hxdw_GetArgvByName( {"--ts2",}, argc, argv, "ib" ).empty();
	if( bTs2 ){
		printf("%llu\n", (hxdw_GetPosixTimeUs() / 1000) );
		return 0;
	}
	STARTUPINFOA si2;
	PROCESS_INFORMATION pi2;
	ZeroMemory(&si2, sizeof(si2));
	ZeroMemory(&pi2, sizeof(pi2));
	si2.cb = sizeof(si2);
	std::string srDllName, srCmd;
	bool bDdashed = 0, bWait = 1;
	for( int i=0; i<argc; i++ ){
		const char* sz2 = argv[i];
		if( bDdashed ){
			bool bSpc = !!strchr( sz2, '\x20');
			srCmd +=
					std::string( srCmd.empty() ? "" : "\x20" ) +
					( bSpc ? "\x22" : "" ) +
					std::string( sz2 ) +
					( bSpc ? "\x22" : "" );
		}else if( !strcmp( sz2, "--") ){
			bDdashed = 1;
		}else if( !strcmp( sz2, "--dll2") && (i+1 < argc) ){
			srDllName = argv[++i];
		}else if( !strcmp( sz2, "--nowait") ){
			bWait = 0;
		}
	}
	if( srDllName.empty() ){
		printf("SPWDL: ERROR: No DLL parameter (see --dll2 FILE).\n");
		return 181;
	}
	printf("SPWDL: Command-line: [%s]\n", srCmd.c_str() );

	bool rs2 = DetourCreateProcessWithDllEx(
			srCmd.c_str(), 0,   //lpCommandLine
			0, 0, 1,            //bInheritHandles,
			0,                  //dwFlags //CREATE_DEFAULT_ERROR_MODE
			0, 0,
			&si2, &pi2,
			srDllName.c_str(), 0 );
	if(!rs2){
		printf("SPWDL: ERROR: failed creating new process.\n");
		return 184;
	}
	if( !bWait ){
		CloseHandle( pi2.hProcess );
		CloseHandle( pi2.hThread );
		return 0;
	}
	if( WAIT_FAILED == WaitForSingleObject( pi2.hProcess, INFINITE ) ){
		CloseHandle( pi2.hProcess );
		CloseHandle( pi2.hThread );
		return 182;
	}
	DWORD exitCode = 183;
	bool rs3 = !!GetExitCodeProcess( pi2.hProcess, &exitCode );
	if(!rs3){
		exitCode = 183;
	}
	CloseHandle( pi2.hProcess );
	CloseHandle( pi2.hThread );
	return static_cast<int>( exitCode );
}




