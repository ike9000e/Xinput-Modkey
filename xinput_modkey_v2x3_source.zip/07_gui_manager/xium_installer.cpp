#include "xium_installer.h"
#include <assert.h>
#include <windows.h>
#include "hxdw/hxdw_utils.h"
#include "hxdw/hxdw_detours_misc.h"

const char* szAppName = "Xinput Modkey Inst. Module";

const std::vector<std::string> xinames = {
	"xinput1_3.dll",
	"xinput1_1.dll",
	"xinput1_2.dll",
	"xinput1_4.dll",
	"xinput9_1_0.dll",
};
const char* const aFwrdrNames[] = {
	"xinput_dll_forwarder_32.dll",
	"xinput_dll_forwarder_64.dll",
};
const char* const aFilterNames[] = {
	"xinput_modkey_32.dll",
	"xinput_modkey_64.dll",
};

std::vector<std::string> aInstlrBaseNames = {
	"instlr32.exe",
	"instlr64.exe",
};

bool xium_IsDLLXinputModkeyFilter2( const char* pathname, const char* szAssetsDir2 )
{
	std::vector<std::string> exports2;
	xium_GetPEExportsAnyArch( pathname, szAssetsDir2, exports2, 0 );
	for( const auto& a : exports2 ){
		if( a == "xidf_dll_dummy" )
			return 1;
	}
	return 0;
}
bool xium_IsDLLXinputModkeyForwarder2( const char* pathname, const char* szAssetsDir2 )
{
	std::vector<std::string> exports2;
	xium_GetPEExportsAnyArch( pathname, szAssetsDir2, exports2, 0 );
	for( const auto& a : exports2 ){
		if( a == "xifw_dll_dummy" )
			return 1;
	}
	return 0;
}
bool
xium_GetPEExportsAnyArch( const char* pathname, const char* szAssetsDir2, std::vector<std::string>& exports3, bool* bX64Arch )
{
	std::vector<std::string>::const_iterator a;
	assert( aInstlrBaseNames.size() >= 2 );
	std::vector<std::string> aInstlrNames = {
		hxdw_StrPrintf("%s\\%s", {{szAssetsDir2,},{aInstlrBaseNames[0],},} ),
		hxdw_StrPrintf("%s\\%s", {{szAssetsDir2,},{aInstlrBaseNames[1],},} ),
	};
	if( sizeof(size_t) == 64/8 ){
		std::reverse( aInstlrNames.begin(), aInstlrNames.end() );
	}
	exports3.clear();
	std::string srTmp2; char bfr[1024]; int i; bool bX64Arch2 = 0;
	GetTempPath( sizeof(bfr)-1, bfr );
	srTmp2 = hxdw_TrimStr( bfr, "\\/", "R", -1 );
	srTmp2 = hxdw_StrPrintf("%s\\xium_exports_q2bgqqp.tmp", {{srTmp2.c_str(),0,},} );
	for( i=0, a = aInstlrNames.begin(); a != aInstlrNames.end(); ++a, i++ ){
		std::string srInstlr = *a;
		bX64Arch2 = !!strstr( hxdw_SplitPath(*a).second.c_str(), "64");
		DeleteFile( srTmp2.c_str() );
		std::vector<std::string> args2 = {
				srInstlr, "--bGetExports", "--ifn", pathname,
				"--ofn", srTmp2,};
		if( !xium_EexecProcess( 0, args2, 1, 0 ) ){ // if failed
			std::string msg = "ERROR: Exec process failed [bgqQPrvc]";
			printf("XIEI: %s\n", msg.c_str() );
			printf("      [%s]\n", srInstlr.c_str() );
			continue;
		}

		std::string str;
		if( !(str = hxdw_GetTextFileContents( srTmp2.c_str() )).empty() ){
			//printf("Exports2 [%s]:\n%s\n",
			//		hxdw_SplitPath(pathname).second.c_str(), str.c_str() );
			hxdw_StrExplode( str.c_str(), exports3, {'\n',}, -1, "\r\n\t\x20" );
			if( !exports3.empty() ){
				if(bX64Arch)
					*bX64Arch = bX64Arch2;
				return 1;
			}
		}
	}
	return 1;
}
/// Returns DLL file names that input EXE|DLL imports from.
/// \param pathname - PE file name, ie. exe or dll.
bool
xium_GetPEFileImportDLLNames( const char* pathname, const char* szAssetsDir3,
				std::vector<std::string>& imports2, std::string* err2 )
{
	std::vector<std::string>::const_iterator a;
	assert( aInstlrBaseNames.size() >= 2 );
	std::vector<std::string> aInstlrNames = {
		hxdw_StrPrintf("%s\\%s", {{szAssetsDir3,},{aInstlrBaseNames[0],},} ),
		hxdw_StrPrintf("%s\\%s", {{szAssetsDir3,},{aInstlrBaseNames[1],},} ),
	};
	if( sizeof(size_t) == 64/8 ){
		std::reverse( aInstlrNames.begin(), aInstlrNames.end() );
	}
	imports2.clear();
	std::string srTmp2; char bfr[1024]; int i;
	GetTempPath( sizeof(bfr)-1, bfr );
	srTmp2 = hxdw_TrimStr( bfr, "\\/", "R", -1 );
	srTmp2 = hxdw_StrPrintf("%s\\xium_exports_oi3jgd.tmp", {{srTmp2.c_str(),0,},} );
	for( i=0, a = aInstlrNames.begin(); a != aInstlrNames.end(); ++a, i++ ){
		std::string srInstlr = *a;
		DeleteFile( srTmp2.c_str() );
		std::vector<std::string> args2 = {
				srInstlr, "--bGetImportDLLs", "--ifn", pathname,
				"--ofn", srTmp2,};
		if( !xium_EexecProcess( 0, args2, 1, 0 ) ){ // if failed
			std::string msg = "ERROR: Exec process failed [bgqQPrvc]";
			printf("XIEI: %s\n", msg.c_str() );
			printf("      [%s]\n", srInstlr.c_str() );
			continue;
		}
		std::string str;
		if( !(str = hxdw_GetTextFileContents( srTmp2.c_str() )).empty() ){
			//printf("Imports2 [%s]:\n%s\n",
			//		hxdw_SplitPath(pathname).second.c_str(), str.c_str() );
			hxdw_StrExplode( str.c_str(), imports2, {'\n',}, -1, "\r\n\t\x20" );
			if( !imports2.empty() ){
				return 1;
			}
		}
	}
	return 1;
}
//*/
bool
xium_GetXinputDllNameForPEIfAny( const char* szPEPath,
						const char* szAssetsDir, std::string* srDllNameOu,
						std::string* err2 )
{
	std::vector<std::string> fnames; //std::string err2;
	//if( !hxdw_GetPEFileImports( szPEPath, fnames, err2 ) )
	if( !xium_GetPEFileImportDLLNames( szPEPath, szAssetsDir, fnames, err2 ) ){
		return 0;
	}
	printf("n-imports: %d\n", (int)fnames.size() );
	for( const auto& a : fnames ){
		auto b = std::find_if( xinames.begin(), xinames.end(), [&]( const std::string& b )->bool{
				return !lstrcmpi( a.c_str(), b.c_str() );
		});
		if( b != xinames.end() ){
			*srDllNameOu = a;
			return 1;
		}
	}
	*srDllNameOu = "";
	return 1;
}
/**
	Opens input executable and determines which forwarder DLL
	name to use and performs a files copy.

	All source DLL files are expected to be located in the directory
	specified by 'szAssetsDir'.
	Once input file has been opened and forwarder name determined,
	copies files into input file's directory.
	If target file exists, it is replaced only if it's determned it's from
	some previous installation - examines the export table.
*/
bool xium_InstallDLLsForBinary( const char* szBinFname, const char* szAssetsDir,
						uint32_t hwnd2, std::vector<std::string>& aDllNames )
{
	HWND hwnd = reinterpret_cast<HWND>( static_cast<size_t>( hwnd2 ) );
	std::string str, srGameDir, err2, ifn = szBinFname, srSrcIni, srTrgtIni;
	std::string srSrcFrwrdr, srSrcFilter, srTrgtFrwrdr, srTrgtFltr;
	bool bIsX64Binary = 0;
	if( ifn.empty() ){
		std::string msg = "ERROR: No input file [5fjao964]";
		printf("XIEI: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 0;
	}
	{
		DWORD eType = 0;
		if( !GetBinaryTypeA( ifn.c_str(), &eType ) ){
			std::string msg = hxdw_StrPrintf(
					"Failed reading binary file information [1kfe0Mgc]\n"
					"File name: [%s]\n", {{ifn.c_str(),0,},} );
			printf("ERROR: %s\n", msg.c_str() );
			MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
			return 0;
		}
		if( eType == SCS_32BIT_BINARY ){ // win32/x86
			bIsX64Binary = 0;
		}else if( eType == SCS_64BIT_BINARY ){ // win64/x64
			bIsX64Binary = 1;
		}else{
			std::string msg =
					"Architecture not supported.\n"
					"It can be either x86 or x64 [ma4qfGPg]\n";
			printf("ERROR: %s\n", msg.c_str() );
			MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
			return 0;
		}
	}
	srGameDir = hxdw_SplitPath( ifn.c_str() ).first;
	printf("XIEI: Accessing: [%s]\n", hxdw_StrLTruncate(ifn,54).c_str() );

	if( !xium_GetXinputDllNameForPEIfAny( ifn.c_str(), szAssetsDir, &srTrgtFrwrdr, &err2 ) ){
		std::string msg = hxdw_StrPrintf("XIEI: ERROR: [%s] [pJ9GtYqQ]", {{err2.c_str(),0,},} );
		printf("XIEI: %s\n", msg.c_str() );
		printf("      File: [%s]\n", ifn.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 0;
	}
	srTrgtFrwrdr = hxdw_StrToLower( srTrgtFrwrdr );
	if( srTrgtFrwrdr.empty() ){
		std::string msg =
				"This game/program seems to not be using Xinput [1ft9dA].\n"
				"None of supported Xinput DLL names has been found in the \n"
				"import table. Cannot continue.\n";
		printf("%s", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 0;
	}
	printf("XIEI: Forwarder xinpput DLL file name: [%s]\n", srTrgtFrwrdr.c_str() );

	srSrcFrwrdr = hxdw_StrPrintf("%s\\%s", {
			{szAssetsDir,0,},
			{(!bIsX64Binary ? aFwrdrNames[0] : aFwrdrNames[1] ),0,},} );
	srSrcFilter = hxdw_StrPrintf("%s\\%s", {
			{szAssetsDir,0,},
			{(!bIsX64Binary ? aFilterNames[0] : aFilterNames[1] ),0,},} );
	srSrcIni = hxdw_StrPrintf("%s\\xinput_modkey.ini", {{szAssetsDir,},} );
	if( !hxdw_FileExists( srSrcFrwrdr.c_str() ) ){
		std::string msg = "Forwarder DLL not found [jHT0Aa00].";
		printf("ERROR: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 0;
	}
	if( !hxdw_FileExists( srSrcFilter.c_str() ) ){
		std::string msg = "Filter DLL not found [6U5rXl38].";
		printf("ERROR: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 0;
	}
	srTrgtFrwrdr = hxdw_StrPrintf("%s\\%s", {{srGameDir.c_str(),0,},{srTrgtFrwrdr.c_str(),0,},} );
	srTrgtFltr = hxdw_StrPrintf("%s\\xinput_modkey.dll", {{srGameDir.c_str(),0,},} );
	srTrgtIni = hxdw_StrPrintf("%s\\xinput_modkey.ini", {{srGameDir.c_str(),0,},} );
	printf("\n");
	printf("Filter       : [%s]\n", hxdw_StrLTruncate( srSrcFilter.c_str(),54).c_str() );
	printf("Forwarder    : [%s]\n", hxdw_StrLTruncate( srSrcFrwrdr.c_str(),54).c_str() );
	printf("Architecture : [%s]\n", (bIsX64Binary ? "x64" : "x86" ) );
	printf("Filter-r     : [%s]\n", hxdw_StrLTruncate( srTrgtFltr,54).c_str() );
	printf("Forwarder-t  : [%s]\n", hxdw_StrLTruncate( srTrgtFrwrdr,54).c_str() );
	printf("\n");
	{
		std::string msg =
				"This isntaller does not modify any existing files "
				"in the selected game/program folder; it only copies new files "
				"into it, that are needed for Xinput-Modkey to function \n"
				"correctly [G0HdLXR].\n"
				"\n"
				"Press OK to continue and copy files.";
	//	if( IDOK != MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONINFORMATION|MB_OKCANCEL)){
	//		printf("XIEI: Cancelled.\n" );
	//		return 0;
	//	}
	}
	{
		std::vector<std::string> testfiles = { srTrgtFrwrdr, srTrgtFltr,};
		for( const auto& a : testfiles ){
			if( hxdw_FileExists( a.c_str() ) ){
				bool bKnown = 0;
				bKnown = xium_IsDLLXinputModkeyFilter2( a.c_str(), szAssetsDir );
				bKnown = ( !bKnown ? xium_IsDLLXinputModkeyForwarder2( a.c_str(), szAssetsDir ) : bKnown );
				if( !bKnown ){
					std::string msg = hxdw_StrPrintf(
						"There is already an existing DLL file inside\n"
						"the targer program/game folder that is not part\n"
						"of the Xinput-Modkey installation.\n"
						"File name: '%s'.\n"
						"This installer won't continue to auto replace it [5dLm8bxk].\n",
							{{ hxdw_SplitPath( a.c_str() ).second.c_str(),0,},} );
					printf("ERROR: %s\n", msg.c_str() );
					MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
					return 0;
				}
			}
		}
	}
	std::vector<std::pair<std::string,std::string> > filesToCpy( {
		{ srSrcFilter, hxdw_SplitPath( srTrgtFltr.c_str() ).second,},
		{ srSrcFrwrdr, hxdw_SplitPath( srTrgtFrwrdr.c_str() ).second,},
	});
	if( !hxdw_FileExists( srTrgtIni.c_str() ) ){
		filesToCpy.push_back({ srSrcIni, hxdw_SplitPath( srTrgtIni ).second,});
	}
	printf("XIEI: Copying files (%d)...\n", (int)filesToCpy.size() );
	bool rs2 = 1;
	rs2 = hxdw_CopyFilesToDir( filesToCpy, srGameDir.c_str(), &err2 );
	if( !rs2 ){
		std::string msg = hxdw_StrPrintf(
				"File copy failed [4fOa3CRc]\n"
				"%s\n", {{err2.c_str(),0,},} );
		printf("ERROR: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 0;
	}
	aDllNames.push_back( hxdw_SplitPath( srTrgtFltr ).second );
	aDllNames.push_back( hxdw_SplitPath( srTrgtFrwrdr ).second );
	printf("XIEI: Install done.\n");
	//MessageBox( hwnd, "Installation completed successfully.", szAppName, MB_ICONINFORMATION );
	return 1;
}
/// Returns 1 on success.
/// Exit codes are 160+ if create process failed.
bool xium_EexecProcess( const char* szCmd,
		const std::vector<std::string>& argv2, bool bWait, int* nExitCode )
{
	assert( !szCmd != argv2.empty() );
	std::string cmd2; DWORD exitCode = 0;
	STARTUPINFOA si2;
	PROCESS_INFORMATION pi2;
	ZeroMemory(&si2, sizeof(si2));
	ZeroMemory(&pi2, sizeof(pi2));
	si2.cb = sizeof(si2);
	if( !argv2.empty() ){
		for( auto a : argv2 ){
			a = ( !!strchr( a.c_str(), '\x20' ) ? ("\x22"+a+"\x22") : a );
			cmd2 += a + "\x20";
		}
	}else{
		cmd2 = szCmd;
	}
	std::shared_ptr<int> raii2( 0, [&]( int* ){
		if( pi2.hProcess ){ CloseHandle( pi2.hProcess ); pi2.hProcess = 0;}
		if( pi2.hThread ){  CloseHandle( pi2.hThread  ); pi2.hThread  = 0;}
		if( nExitCode ){ *nExitCode = (int)exitCode; }
	} );
	//printf("XIUM: Command-line: [%s]\n", cmd2.c_str() );
	// dwFlags: CREATE_DEFAULT_ERROR_MODE,CREATE_NO_WINDOW,
	//          CREATE_NO_WINDOW: dont spawn the console for CLI programs.
	bool rs2 = CreateProcess(
			0, (char*)cmd2.c_str(),   //lpCommandLine
			0, 0, 1,            //bInheritHandles,
			CREATE_NO_WINDOW,  //dwFlags
			0, 0,
			&si2, &pi2 );
	if( !rs2 ){
		printf("XIUM: ERROR: failed creating new process [ZRnrjxD]\n");
		exitCode = 160;
		return 0;
	}
	if( !bWait )
		return 1; //ok.
	if( WAIT_FAILED == WaitForSingleObject( pi2.hProcess, INFINITE ) ){
		printf("XIUM: ERROR: failed waiting for process to finish [AEVaK0]\n");
		exitCode = 161;
		return 0;
	}
	bool rs3 = !!GetExitCodeProcess( pi2.hProcess, &exitCode );
	if(!rs3){ // if no exit code.
		printf("XIUM: ERROR: failed getting process exit code [yZfyQ0M]\n");
		exitCode = 163;
		return 0;
	}
	return 1; //ok.
}
bool
xium_UninstallDLLsForBinary( const std::string& srBinFname,
						const char* szAssetsDir,
						uint32_t hwnd2,
						const std::vector<std::string> aDllNames,
						const char* flags2 )
{
	HWND hwnd = (HWND)(size_t)hwnd2;
	std::string srGameDir2 = hxdw_SplitPath(srBinFname).first;
	std::vector<std::string> paths2;
	bool bDelIni = !!strchr( flags2, 'i' );

	for( const auto& bn2 : aDllNames ){
		std::string fn2 = hxdw_StrPrintf("%s\\%s",
				{{srGameDir2.c_str(),}, {bn2.c_str(),},} );
		bool bKnown = 0;
		bKnown = xium_IsDLLXinputModkeyFilter2( fn2.c_str(), szAssetsDir );
		bKnown = ( !bKnown ? xium_IsDLLXinputModkeyForwarder2( fn2.c_str(), szAssetsDir ) : bKnown );
		if( bKnown ){
			//printf("To delete: [%s]\n", fn2.c_str() );
			paths2.push_back( fn2 );
		}
	}
	if( bDelIni ){
		std::string fn3 = hxdw_StrPrintf("%s\\xinput_modkey.ini", {{srGameDir2,},} );
		paths2.push_back( fn3 );
	}
	bool bOk; std::string err2;
	bOk = hxdw_DeleteFilesWithRollback( paths2, &err2 );
	if( !bOk ){
		std::string msg = hxdw_StrPrintf(
				"File remove failed [4lXBHD].\n"
				"%s\n", {{err2.c_str(),0,},} );
		printf("ERROR: %s\n", msg.c_str() );
		MessageBox( hwnd, msg.c_str(), szAppName, MB_ICONERROR );
		return 0;
	}
	return 1;
}






