#include "xium_entrypoint.h"
#include "xium_wnd.h"

int main( int argc, char** argv )
{
	//Fl::args( argc, argv );
	XiumMainWindow *win = new XiumMainWindow;
	win->icon( (char*)LoadIcon(fl_display, MAKEINTRESOURCE(101)) );
    win->show( argc, argv );
    return Fl::run();
}
