// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <functional>
#include <windows.h>

HWND        hxdw_FindWndByCaptionPart( const char* szNeedle, const char* flags2 );
bool        hxdw_SendDropFilesToWnd( HWND hwnd, const std::vector<std::string>& fnames );
bool        hxdw_GetDirFilesRcv( const char* szDir, std::vector<std::string>& fnames, const char* szFlags );
bool        hxdw_StrExplode( const char* inp, std::vector<std::string>& parts2, const std::vector<char> lsGlueItems, int nLimit = -1, const char* szTrimLR = 0 );
int         hxdw_FileExists( const char* fname );
auto        hxdw_SplitExt( const char* inp ) -> std::pair<std::string,std::string>;
auto        hxdw_SplitPath( const char* inp ) -> std::pair<std::string,std::string>;
bool        hxdw_IsDir( const char* pathname );
std::string hxdw_GetTextFileContents( const char* fname );
bool        hxdw_GetTextLinesFromFile( const char* fname, std::vector<std::string>* lines2 );
std::string hxdw_GetArgvByName( const std::vector<std::string> argnames2, int argc2, const char*const* argv2, const char* szFlags = "" );
std::string hxdw_TrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 );
int         hxdw_StrCmpOpt( const char* a, const char* b, int num = -1, const char* flags2 = "" );
int         hxdw_GetFileSize( const char* fname );

/// Used by hxdw_ParseINIFile().
using hxdw_IniSection = std::pair< std::string, std::vector<std::pair<std::string,std::string> > >;
using hxdw_IniData3 = std::vector< hxdw_IniSection >;
struct hxdw_IniData2{
	hxdw_IniData3 sections2;
	//findSection();
	bool eachSection( std::function<bool( const hxdw_IniSection& )> calb2 )const;
	bool eachVariable( const std::vector<std::string> sectnames, std::function<bool( const char* secname, const char* kname, const char* value2 )> calb2 )const;
	std::string getValue( const char* sec2, const char* kname )const;
};

hxdw_IniData2 hxdw_ParseINIFile( const char* szIniFname );
