#include "xidf_dll_main.h"
#include <assert.h>
#include <algorithm>
#include "detours.h"
#include <process.h>   //_getpid()

XidfGlobals* XidfData = 0;

//DWORD WINAPI xidf_XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke )
//{
//	assert(0);
//	return 00;
//}
BOOL WINAPI DllMain( HINSTANCE hInst, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			assert( !XidfData );
			XidfData = new XidfGlobals;
			printf("XIDF: Starting DLL\n");
			//printf("XIDF: dll path: [%s]\n", XidfData->srDllPath.c_str() );
			xidf_InitData( hInst );
			DetourTransactionBegin();
			DetourUpdateThread( GetCurrentThread() );
			//DetourAttach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
			{
				HINSTANCE hDll2 = LoadLibrary( XidfData->srXiDllFName.c_str() );
				assert( hDll2 );
				ori_XInputGetState = (XInputGetState_t*) GetProcAddress( hDll2, "XInputGetState" );
				assert( ori_XInputGetState );
				DetourAttach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
			}
			DetourTransactionCommit();
		}
		break;
	case DLL_PROCESS_DETACH:
		assert( XidfData );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
		DetourTransactionCommit();
		xidf_LogMessage("", "DLL_PROCESS_DETACH");

		delete XidfData;
		XidfData = 0;
		break;
	}
	return 1;
}
const std::vector<std::pair<int,int> > xidf_ButtonBits = {
	{ Xidf_Act_A, XINPUT_GAMEPAD_A,},
	{ Xidf_Act_B, XINPUT_GAMEPAD_B,},
	{ Xidf_Act_X, XINPUT_GAMEPAD_X,},
	{ Xidf_Act_Y, XINPUT_GAMEPAD_Y,},
	{ Xidf_Act_UP, XINPUT_GAMEPAD_DPAD_UP,},
	{ Xidf_Act_DOWN, XINPUT_GAMEPAD_DPAD_DOWN,},
	{ Xidf_Act_LEFT, XINPUT_GAMEPAD_DPAD_LEFT,},
	{ Xidf_Act_RIGHT, XINPUT_GAMEPAD_DPAD_RIGHT,},
	{ Xidf_Act_START, XINPUT_GAMEPAD_START,},
	{ Xidf_Act_BACK, XINPUT_GAMEPAD_BACK,},
	{ Xidf_Act_LS, XINPUT_GAMEPAD_LEFT_SHOULDER,},
	{ Xidf_Act_RS, XINPUT_GAMEPAD_RIGHT_SHOULDER,},
	{ Xidf_Act_LT, XINPUT_GAMEPAD_LEFT_THUMB,},
	{ Xidf_Act_RT, XINPUT_GAMEPAD_RIGHT_THUMB,},
};
const std::vector<int> xidf_ActionIsStick = {
	Xidf_Act_LSXAdd, Xidf_Act_LSXSub,
	Xidf_Act_LSYAdd, Xidf_Act_LSYSub,
	Xidf_Act_RSXAdd, Xidf_Act_RSXSub,
};
const std::vector<int> xidf_ActionIsTrigger = {
	Xidf_Act_LTr, Xidf_Act_RTr,
};
const std::vector<std::pair<int,std::string> > xidf_ActNames = {
	{ Xidf_Act_A, "A", },
	{ Xidf_Act_B, "B", },
	{ Xidf_Act_X, "X", },
	{ Xidf_Act_Y, "Y", },
	{ Xidf_Act_LT, "LTh", },  // Left Thumbstick.
	{ Xidf_Act_RT, "RTh", },
	{ Xidf_Act_LTr, "LTr", },  // Left Trigger.
	{ Xidf_Act_RTr, "RTr", },
	{ Xidf_Act_START, "START", },
	{ Xidf_Act_BACK, "BACK", },
	{ Xidf_Act_UP, "UP", },
	{ Xidf_Act_DOWN, "DOWN", },
	{ Xidf_Act_LEFT, "LEFT", },
	{ Xidf_Act_RIGHT, "RIGHT", },
	{ Xidf_Act_LS, "LSh", },
	{ Xidf_Act_RS, "RSh", },
	{ Xidf_Act_LSXAdd, "LSXPlus", },
	{ Xidf_Act_LSXSub, "LSXMinus", },
	{ Xidf_Act_LSYAdd, "LSYPlus", },
	{ Xidf_Act_LSYSub, "LSYMinus", },
	{ Xidf_Act_RSXAdd, "RSXPlus", },
	{ Xidf_Act_RSXSub, "RSXMinus", },
	{ Xidf_Act_RSYAdd, "RSYPlus", },
	{ Xidf_Act_RSYSub, "RSYMinus", },
};
/// This is only for the dummy symbol name exporting; to make it
/// available for when patching some executables.
int xidf_dll_dummy()
{
	return 49775;
}

void xidf_MsgBoxIf( HWND hwnd, const char* msg, const char* flags2 )
{
	assert( XidfData );
	if( XidfData->bCLIOnly )
		return;
	bool bErr = !strchr( flags2, 'k' );
	MessageBox( hwnd, msg, "XIDF", (bErr?MB_ICONERROR:0) );
}
std::string xidf_GetLocalTimeStr()
{
	char buf[128];
	SYSTEMTIME stt;
	GetLocalTime( &stt ); // Local time
	sprintf_s( buf, sizeof(buf), "%04u%02u%02u%02u%02u%02u",
			stt.wYear, stt.wMonth, stt.wDay,
			stt.wHour, stt.wMinute, stt.wSecond ); // 24h format
	return buf;
}
void xidf_LogMessage( const char* flags2, const char* szMsg )
{
	if( !XidfData->srLogFile.empty() ){
		FILE* fp2 = fopen( XidfData->srLogFile.c_str(), "ab" );
		if(fp2){
			std::string srMesg = hxdw_TrimStr( szMsg, "\r\n", "R", -1 );
			char bfr2[2048];
			sprintf_s( bfr2, sizeof(bfr2), "%d: %s\r\n", _getpid(), srMesg.c_str() );
			fwrite( bfr2, 1, strlen(bfr2), fp2 );
			fclose(fp2);
		}
	}
}

bool xidf_InitData( HINSTANCE hInst )
{
	char bfr2[MAX_PATH] = ""; std::string str, err2;
	{
		const char* sz2; std::string srTmpDir;
		std::vector<std::string> aTmps2 = {"C:\\Temp","%TEMP%","%TMP%",};
		for( const auto& a : aTmps2 ){
			if( a[0] == '%' ){
				str = hxdw_TrimStr( a, "%", "LR", -1 );
				if( (sz2 = getenv( str.c_str() )) ){
					if( hxdw_IsDir( sz2 ) ){
						srTmpDir = sz2;
						break;
					}
				}
			}else if( hxdw_IsDir( a.c_str() ) ){
				srTmpDir = a.c_str();
				break;
			}
		}
		if( !srTmpDir.empty() ){
			sprintf_s( bfr2, sizeof(bfr2), "%s\\xinput_modkey.log", srTmpDir.c_str() );
			XidfData->srLogFile = bfr2;
			printf("XIDF: Log file: [%s]\n", XidfData->srLogFile.c_str() );
			if( (128*1024) < hxdw_GetFileSize( XidfData->srLogFile.c_str() ) ){
				DeleteFile( XidfData->srLogFile.c_str() );
			}
		}
	}
	GetModuleFileName( hInst, bfr2, sizeof(bfr2) );
	XidfData->srDllPath = bfr2;

	if( !XidfData->srLogFile.empty() ){
		sprintf_s( bfr2, sizeof(bfr2), "%s Starting from [%s]",
				xidf_GetLocalTimeStr().c_str(), XidfData->srDllPath.c_str() );
		xidf_LogMessage( "", bfr2 );
		//
		GetModuleFileName( 0, bfr2, sizeof(bfr2)-1 );
		std::string srExec = bfr2;
		sprintf_s( bfr2, sizeof(bfr2), "Executable name [%s]", srExec.c_str() );
		xidf_LogMessage( "", bfr2 );
	}
	std::pair<std::string,std::string> dp2;
	dp2 = hxdw_SplitPath( XidfData->srDllPath.c_str() );
	XidfData->srCfgFname = dp2.first + "\\" + hxdw_SplitExt( dp2.second.c_str() ).first + ".ini";
	printf("XIDF: Config path: [%s]\n", XidfData->srCfgFname.c_str() );

	if( !hxdw_FileExists( XidfData->srCfgFname.c_str() ) ){
		printf("XIDF: ERROR: configuration file not found.\n");
		return 0;
	}
	hxdw_IniData2 ini2 = hxdw_ParseINIFile( XidfData->srCfgFname.c_str() );
	XidfData->bEnforceAPIDeadzones = !!atoi( ini2.getValue( "s_main", "bEnforceAPIDeadzones" ).c_str() );
	XidfData->nGamepadIndex = !!atoi( ini2.getValue( "s_main", "nGamepadIndex" ).c_str() );
	if( !( str = ini2.getValue( "s_main", "szXinputDllName" ).c_str() ).empty() ){
		if( str == "eDAuto" ){
			// Enumerate DLLs in the PE executable.
			for( HMODULE hDll3 = 0; (hDll3 = DetourEnumerateModules(hDll3)); ){
				char szName[MAX_PATH] = {0,};
				GetModuleFileNameA(hDll3, szName, sizeof(szName) - 1);
				str = hxdw_SplitPath( szName ).second;
				// Below: eg. marches when: "XINPUT9_1_0.dll", "Xinput1_3.dll", etc.
				if( !hxdw_StrCmpOpt( "xinput", str.c_str(), 0x0006, "i" ) ){
					if( strchr( "19", str[0x0006] ) ){
						XidfData->srXiDllFName = str;
						//printf("DLL: [%s]\n", str.c_str() );
						break;
					}
				}
			}
		}else{
			XidfData->srXiDllFName = str;
		}
	}
	if( !(str = ini2.getValue( "s_main", "szGlobalSuppress" ).c_str()).empty() ){
		if( !xidf_ActionsToArray( str.c_str(), ',', XidfData->aGlobSuppr, &err2 ) ){
			printf("XIDF: ERROR: %s\n", err2.c_str() );
			return 0;
		}
	}
	printf("XIDF: Using Xinput DLL: [%s]\n", XidfData->srXiDllFName.c_str() );
	sprintf_s( bfr2, sizeof(bfr2), "Using Xinput DLL [%s]", XidfData->srXiDllFName.c_str() );
	xidf_LogMessage("", bfr2 );

	if( !xidf_ParseModkeys2( ini2, XidfData->modkeys3, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfData->modkeys3 ){
		XidfData->aModsDown.push_back( Xidf_ModkeyDown( &a ) );
	}
	if( !xidf_ParseActions( ini2, XidfData->routines2, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfData->routines2 ){
		XidfData->aRoutinesLive.push_back( Xidf_RoutineLive( &a ) );
	}
	XidfData->bInited = 1;
	return 1;
}
void xidf_EnforceAPIDeadZones( XINPUT_GAMEPAD& gp2 )
{
	const int deadzoneLStk = XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE; //7849
	const int deadzoneRStk = XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE; //8689
	const int deadzoneTrg  = XINPUT_GAMEPAD_TRIGGER_THRESHOLD; //30
	if( gp2.bLeftTrigger <= deadzoneTrg ){
		gp2.bLeftTrigger = 0;
	}
	if( gp2.bRightTrigger <= deadzoneTrg ){
		gp2.bRightTrigger = 0;
	}
	float magnitude2 = sqrt( pow( gp2.sThumbLX, 2 ) + pow( gp2.sThumbLY, 2 ) );
	if( magnitude2 <= deadzoneLStk ){
		gp2.sThumbLX = 0;
		gp2.sThumbLY = 0;
	}
	magnitude2 = sqrt( pow( gp2.sThumbRX, 2 ) + pow( gp2.sThumbRY, 2 ) );
	if( magnitude2 <= deadzoneRStk ){
		gp2.sThumbRX = 0;
		gp2.sThumbRY = 0;
	}
}
int xidf_StrToAction( const char* inp )
{
	int outp = 0;
	std::find_if( xidf_ActNames.begin(), xidf_ActNames.end(),
			[&]( const std::pair<int,std::string>& a ){
					if( a.second == inp ){
						outp = a.first;
						return 1;
					}
					return 0;
			}
	);
	return outp;
}
bool xidf_ParseActions( const hxdw_IniData2& ini3, std::vector<Xidf_Routine>& actionsOu, std::string* err2 )
{
	bool bSucc = 1; char bfr[512];
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srSecNameBgn = hxdw_TrimStr("s_routine:0", ":0", "R", -1 );
	ini3.eachSection( [&]( const hxdw_IniSection& sec2 ){
			std::string secname = sec2.first;
			if( secname.size() > srSecNameBgn.size() )
				secname = secname.substr( 0, srSecNameBgn.size() );
			if( secname == srSecNameBgn ){
				std::string srHotk = ini3.getValue( sec2.first.c_str(), "szHotkey" );
				if( srHotk.empty() ){
					sprintf_s( bfr, sizeof(bfr),
							"No trigger specified for action [%s]",
							sec2.first.c_str() );
					err3 = bfr;
					bSucc = 0;
					return 0;
				}
				Xidf_Trigger trgr;
				if( !xidf_ParseTriggerSequence( srHotk.c_str(), trgr, &err3 ) ){
					sprintf_s( bfr, sizeof(bfr),
							"Failed parsing trigger for action [%s]. 'szHotkey' [%s]",
							sec2.first.c_str(), err3.c_str() );
					err3 = bfr;
					bSucc = 0;
					return 0;
				}
				std::string vSprss = ini3.getValue( sec2.first.c_str(), "szSuppress" );
				std::string vHold = ini3.getValue( sec2.first.c_str(), "szHold" );
				Xidf_Routine actn;
				xidf_ActionsToArray( vSprss.c_str(), ',', actn.aSuppress, &err3 );
				xidf_ActionsToArray( vHold.c_str(), ',', actn.aHold, &err3 );
				actn.bHExclusive = !!atoi( ini3.getValue( sec2.first.c_str(), "bHExclusive" ).c_str() );
				//printf("bHExclusive: %d\n", actn.bHExclusive );
				//
				actn.trigger2 = trgr;
				actionsOu.push_back( actn );
			}
			return 1;
	});
	return bSucc;
}
int xidf_FindModkeyByName( const char* modkname, const std::vector<Xidf_Modkey>& modkeys_ )
{
	for( const auto& a : modkeys_ ){
		if( a.rename2 == modkname ){
			return a.ident3;
		}
	}
	return 0;
}
bool xidf_ParseTriggerSequence( const char* inp, Xidf_Trigger& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btnsOrMdk;
	hxdw_StrExplode( inp, btnsOrMdk, {'+',}, -1, "\x20\t" );
	if( btnsOrMdk.empty() || btnsOrMdk[0].empty() ){
		err3 = "No modkey name.";
		return 0;
	}
	for( const auto& a : btnsOrMdk ){
		int id2;
		if( (id2 = xidf_FindModkeyByName( a.c_str(), XidfData->modkeys3 )) ){
			outp.modkeyIds.push_back( id2 );
		}else if( (id2 = xidf_StrToAction( a.c_str() )) ){
			outp.buttons2.push_back( id2 );
		}else{
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr),
					"Trigger item '%s' not recognizaed. "
					"It must be either modkey name or button name.",
					a.c_str() );
			err3 = bfr;
			return 0;
		}
	}
	outp.ident4 = ++XidfData->nLastTriggerId;
	return 1;
}
bool xidf_ActionsToArray( const char* szBtnNames, char glue2, std::vector<int>& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btns;
	hxdw_StrExplode( szBtnNames, btns, {glue2,}, -1, "\x20\t" );
	for( const auto& a : btns ){
		int id2;
		if( !(id2 = xidf_StrToAction( a.c_str() )) ){
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr),
					"Unrecognizaed action anme '%s'.", a.c_str() );
			err3 = bfr;
			return 0;
		}
		outp.push_back(id2);
	}
	return 1;
}
bool xidf_ParseModkeys2( const hxdw_IniData2& ini3, std::vector<Xidf_Modkey>& modkeysOu, std::string* err2 )
{
	char bfr[512];
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srSecNameBgn2 = hxdw_TrimStr("s_modkey:0", ":0", "R", -1 );
	std::vector<std::string> secnames;
	ini3.eachSection( [&]( const hxdw_IniSection& sec ){
			std::string secnme( sec.first );
			if( secnme.size() > srSecNameBgn2.size() )
				secnme = secnme.substr( 0, srSecNameBgn2.size() );
			if( secnme == srSecNameBgn2 )
				secnames.push_back( sec.first );
			return 1;
	});
	int nNr = 0;
	std::vector<std::string>::const_iterator a;
	for( a = secnames.begin(); a != secnames.end(); ++a, nNr++ ){
		std::string sname = *a;
		Xidf_Modkey mdk0;
		std::string srBtn    = ini3.getValue( sname.c_str(), "szButton" );
		std::string srThrsh  = ini3.getValue( sname.c_str(), "nFloor" );
		std::string srLimit  = ini3.getValue( sname.c_str(), "nCeil" );
		std::string srRename = ini3.getValue( sname.c_str(), "szName" );
		if( srBtn.empty() ){
			sprintf_s( bfr, sizeof(bfr), "Empty button name, [%s].szButton", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		mdk0.btnActivator = xidf_StrToAction( srBtn.c_str() );
		if( !mdk0.btnActivator ){
			sprintf_s( bfr, sizeof(bfr), "Unknown button name, [%s].szButton", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		mdk0.threshold2 = ( srThrsh.empty() ? -1 : xidf_StrToLimit( srThrsh.c_str(), mdk0.btnActivator ) );
		mdk0.limit2 = ( srLimit.empty() ? -1 : xidf_StrToLimit( srLimit.c_str(), mdk0.btnActivator ) );
		mdk0.limit2 = ( !mdk0.limit2 ? -1 : mdk0.limit2 );

		if( !srRename.empty() ){
			mdk0.rename2 = srRename;
		}else{
			sprintf_s( bfr, sizeof(bfr), "Mod%d", nNr );
			mdk0.rename2 = bfr;
		}
		mdk0.bSuppress = !!atoi( ini3.getValue( sname.c_str(), "bSuppress" ).c_str() );
		mdk0.ident3    = ++XidfData->nLastModkId;

		modkeysOu.push_back( mdk0 );
	}
	return 1;
}
bool xidf_IsStickAction( int eAction )
{
	for( const auto& a : xidf_ActionIsStick ){
		if( a == eAction )
			return 1;
	}
	return 0;
}
bool xidf_IsTriggerAction( int eAction )
{
	for( const auto& a : xidf_ActionIsTrigger ){
		if( a == eAction )
			return 1;
	}
	return 0;
}
DWORD WINAPI xidf_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pState )
{
	XINPUT_STATE& sta = *pState;
	XINPUT_GAMEPAD& gpd = sta.Gamepad;
	DWORD rs2 = ori_XInputGetState( dwUserIndex, &sta );
	if( XidfData->bEnforceAPIDeadzones ){
		xidf_EnforceAPIDeadZones( gpd );
	}
	//if( gpd.wButtons & XINPUT_GAMEPAD_A ){
	//	gpd.wButtons |= XINPUT_GAMEPAD_X;
	//}
	//if( gpd.bLeftTrigger == 255 ){
	//	gpd.wButtons |= XINPUT_GAMEPAD_X;
	//}
	//32767 * 2 = 65534
	Xidf_Perform prf( *pState, dwUserIndex );
	xidf_PerformModkeys( prf );

	//if( sta.dwPacketNumber ){
	//}
	return rs2;
}
int xidf_ActionToBitIfAny( int eBtn )
{
	for( const auto& a : xidf_ButtonBits ){
		if( a.first == eBtn )
			return a.second;
	}
	return 0;
}
bool xidf_TestAnalogueModkeyDown( int eBtn2, std::pair<int,int> aRange, const XINPUT_GAMEPAD& gpd )
{
	const std::vector<std::tuple<int,int,bool> > aActivatorPosInv = {
		{ Xidf_Act_LTr,    gpd.bLeftTrigger,  0,},
		{ Xidf_Act_RTr,    gpd.bRightTrigger, 0,},
		{ Xidf_Act_LSXAdd, gpd.sThumbLX, 0,},
		{ Xidf_Act_LSXSub, gpd.sThumbLX, 1,},
		{ Xidf_Act_LSYAdd, gpd.sThumbLY, 0,},
		{ Xidf_Act_LSYSub, gpd.sThumbLY, 1,},
		{ Xidf_Act_RSXAdd, gpd.sThumbRX, 0,},
		{ Xidf_Act_RSXSub, gpd.sThumbRX, 1,},
		{ Xidf_Act_RSYAdd, gpd.sThumbRY, 0,},
		{ Xidf_Act_RSYSub, gpd.sThumbRY, 1,},
	};
	int threshold3 = aRange.first;
	int ceil2      = aRange.second;
	for( const auto& a : aActivatorPosInv ){
		if( std::get<0>(a) == eBtn2 ){
			const int poss = std::get<1>(a);
			if( !std::get<2>(a) ){
				if( poss && poss >= threshold3 )
					if( ceil2 == -1 || poss < ceil2 )
						return 1;
			}else{
				if( poss && poss <= -threshold3 )
					if( ceil2 == -1 || poss > -ceil2 )
						return 1;
			}
		}
	}
	return 0;
}
Xidf_ModkeyDown* Xidf_ModkeyDown::findModkey( int ident, Xidf_ModkeyDown* inp, size_t num )
{
	for( int i=0; i<num; i++ ){
		if( inp[i].mod2->ident3 == ident )
			return &inp[i];
	}
	return 0;
}
bool xidf_IsActionDown( int eBtn, const XINPUT_GAMEPAD& gpd, std::pair<int,int> aRange )
{
	if( xidf_IsStickAction( eBtn ) || xidf_IsTriggerAction( eBtn ) ){
		//threshold4
		if( aRange.first == -1 ){
			aRange.first = xidf_GetThresholdForActionIfAny( eBtn );
		}
		return xidf_TestAnalogueModkeyDown( eBtn, aRange, gpd );
	}else{
		int flg = xidf_ActionToBitIfAny( eBtn );
		if( flg & gpd.wButtons )
			return 1;
	}
	return 0;
}
int xidf_GetThresholdForActionIfAny( int eBtn )
{
	const auto a = std::find( xidf_ActionIsStick.begin(), xidf_ActionIsStick.end(), eBtn );
	if( a != xidf_ActionIsStick.end() ){
		//XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE
		return XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE;
	}
	const auto b = std::find( xidf_ActionIsTrigger.begin(), xidf_ActionIsTrigger.end(), eBtn );
	if( b != xidf_ActionIsTrigger.end() ){
		return XINPUT_GAMEPAD_TRIGGER_THRESHOLD;
	}
	return -1;
}
bool xidf_PerformModkeys( Xidf_Perform& inp )
{
	if( XidfData->bInited && inp.dwUserIndex2 == XidfData->nGamepadIndex ){
		const XINPUT_GAMEPAD& gpd = inp.xistate.Gamepad;
		XINPUT_GAMEPAD gpd2 = inp.xistate.Gamepad;

		for( const int a : XidfData->aGlobSuppr ){
			xidf_SuppressXiButtonGivenAction( a, gpd, gpd2 );
		}

		for( auto& a : XidfData->aModsDown ){ // Xidf_ModkeyDown, Xidf_Modkey
			bool bDown3 = xidf_IsActionDown( a.mod2->btnActivator, gpd, { a.mod2->threshold2, a.mod2->limit2,} );
			if( a.bDown2 && !bDown3 ){
				a.bDown2 = 0; //printf("--- modk up!\n");
			}else if( !a.bDown2 && bDown3 ){
				a.bDown2 = 1; //printf("--- modk down!\n");
			}
			if( a.mod2->bSuppress ){
				xidf_SuppressXiButtonGivenAction( a.mod2->btnActivator, gpd, gpd2 );
			}
		}
		for( auto& a : XidfData->aRoutinesLive ){
			const Xidf_ModkeyDown* modd;
			std::vector<int> aBtnsDownPerActn;
			bool bLive2 = 1;
			for( const auto& b : a.routine2->trigger2.modkeyIds ){ // Xidf_Trigger
				modd = Xidf_ModkeyDown::findModkey( b, &XidfData->aModsDown[0], XidfData->aModsDown.size() );
				if( modd && modd->bDown2 ){
					aBtnsDownPerActn.push_back( modd->mod2->btnActivator );
				}else{
					bLive2 = 0;
					break;
				}
			}
			for( const auto& b : a.routine2->trigger2.buttons2 ){
				if( !xidf_IsActionDown( b, gpd, {-1,-1,} ) ){
					bLive2 = 0;
					break;
				}else{
					aBtnsDownPerActn.push_back( b );
				}
			}
			//if( bLive2 != a.bLive && a.routine2->bHExclusive )
			if( a.routine2->bHExclusive ){
				for( const auto& b : xidf_ActNames ){
					const auto c = std::find( aBtnsDownPerActn.begin(), aBtnsDownPerActn.end(), b.first );
					if( c == aBtnsDownPerActn.end() ){
						if( xidf_IsActionDown( b.first, gpd, {0,-1,} ) ){
							bLive2 = 0;
							break;
						}
					}
				}
			}
			if( !a.bLive && bLive2 ){
				a.bLive = 1; //printf("--- act down.\n");
			}else if( a.bLive && !bLive2 ){
				a.bLive = 0; //printf("--- act up.\n");
			}
			if( a.bLive ){
				xidf_RoutineLivePerform( a, inp, gpd, gpd2 );
			}
		}

		//
		inp.xistate.Gamepad = gpd2;
	}
	return 1;
}
void
xidf_RoutineLivePerform( const Xidf_RoutineLive& actn2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 )
{
	for( const auto& a : actn2.routine2->aHold ){
		int mask2 = xidf_ActionToBitIfAny( a );
		if( mask2 ){
			gpd2.wButtons |= mask2;
		}
	}
	for( const auto& a : actn2.routine2->aSuppress ){
		xidf_SuppressXiButtonGivenAction( a, gpd, gpd2 );
	}
}
void xidf_SuppressXiButtonGivenAction( int eAction, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 )
{
	int mask2;
	if( (mask2 = xidf_ActionToBitIfAny( eAction ))){
		gpd2.wButtons &= ~mask2;
	}else{
		if( eAction == Xidf_Act_LTr )
			gpd2.bLeftTrigger = 0;
		if( eAction == Xidf_Act_RTr )
			gpd2.bRightTrigger = 0;
		if( eAction == Xidf_Act_LSXAdd && gpd.sThumbLX > 0 )
			gpd2.sThumbLX = 0;
		if( eAction == Xidf_Act_LSXSub && gpd.sThumbLX < 0 )
			gpd2.sThumbLX = 0;
		if( eAction == Xidf_Act_LSYAdd && gpd.sThumbLY > 0 )
			gpd2.sThumbLY = 0;
		if( eAction == Xidf_Act_LSYSub && gpd.sThumbLY < 0 )
			gpd2.sThumbLY = 0;
		if( eAction == Xidf_Act_RSXAdd && gpd.sThumbRX > 0 )
			gpd2.sThumbRX = 0;
		if( eAction == Xidf_Act_RSXSub && gpd.sThumbRX < 0 )
			gpd2.sThumbRX = 0;
		if( eAction == Xidf_Act_RSYAdd && gpd.sThumbRY > 0 )
			gpd2.sThumbRY = 0;
		if( eAction == Xidf_Act_RSYSub && gpd.sThumbRY < 0 )
			gpd2.sThumbRY = 0;
	}
}
int xidf_StrToLimit( const char* inp, int eAct )
{
	int limit3 = -1;
	float fFrac = 0.0f;
	if( strchr( inp, '.' ) ){
		fFrac = atof( inp );
	}else if( strchr( inp, '%' ) ){
		fFrac = ( 0.01f * atoi( inp ) );
	}else{
		limit3 = atoi( inp );
	}
	if( xidf_IsStickAction( eAct ) ){
		limit3 = ( fFrac ? static_cast<int>( fFrac * Xidf_MaxStickPos ) : limit3 );
		limit3 = std::max<int>( 0, std::min<int>( Xidf_MaxStickPos, limit3 ) );
		limit3 = ( limit3 ? limit3 : XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE );
		//XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE
	}else if( xidf_IsTriggerAction( eAct ) ){
		limit3 = ( fFrac ? static_cast<int>( fFrac * Xidf_MaxTriggerPos ) : limit3 );
		limit3 = std::max<int>( 0, std::min<int>( Xidf_MaxTriggerPos, limit3 ) );
		limit3 = ( limit3 ? limit3 : XINPUT_GAMEPAD_TRIGGER_THRESHOLD );
		//printf("XIDF: limit3: %d\n", limit3 );
	}
	return limit3;
}






