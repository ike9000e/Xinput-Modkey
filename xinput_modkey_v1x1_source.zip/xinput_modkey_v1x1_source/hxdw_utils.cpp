#include "hxdw_utils.h"
#include <stdint.h>
#include <assert.h>
#pragma warning( disable : 4091 ) // Win SDK 7.1 | shlobj.h warning C4091: typedef ignored on left of tagGPFIDL_FLAGS ...
#include <shlobj.h>
// vector(960): warning C4530: C++ exception handler used, but unwind
// semantics are not enabled. Specify /EHsc (aka. /GX)

/// Used internally by hxdw_FindWndByCaptionPart().
struct hxdw_WndEnumFuncCalbData{
	std::function<bool(HWND, const char*)> calb5;
};
BOOL CALLBACK hxdw_WndEnumFunc( HWND hwnd, LPARAM lParam )
{
	//char classname2[256];
	//GetClassName( hwnd, classname2, 256 );
	char caption2[256];
	GetWindowText( hwnd, caption2, 256 );
	hxdw_WndEnumFuncCalbData* cd2 = (hxdw_WndEnumFuncCalbData*)lParam;
	//if( !(*cd2->calb4)( hwnd, caption2 ) )
	if( !(cd2->calb5)( hwnd, caption2 ) ){
		return 0;
	}
	return 1;
}
/// Finds window by partial text of caption (title).
HWND hxdw_FindWndByCaptionPart( const char* szNeedle, const char* flags2 )
{
	std::vector<HWND> wnds;
	auto calb2 = [&]( HWND hwnd2, const char* szCaption )->bool{
		bool bFound = !!strstr( szCaption, szNeedle );
		if(bFound)
			wnds.push_back(hwnd2);
		return 1;
	};
	hxdw_WndEnumFuncCalbData cdt;
	cdt.calb5   = calb2;
	EnumWindows( hxdw_WndEnumFunc, (LPARAM)&cdt );
	if( strchr( flags2, 'b' ) ){
		return ( wnds.empty() ? 0 : wnds.back() );
	}else{
		return ( wnds.empty() ? 0 : wnds[0] );
	}
}

bool hxdw_SendDropFilesToWnd( HWND hwnd, const std::vector<std::string>& fnames )
{
	int len2 = sizeof(DROPFILES);
	for( auto sr2 : fnames ){
		len2 += strlen(sr2.c_str()) + 1;
	}
	len2 += 1; //one more for extra null terminator.
	HGLOBAL hGlobal = GlobalAlloc( GHND, len2 );
	if( !hGlobal ){
		printf("CPTA DLL: ERROR: global data alloc failed.\n");
		return 0;
	}
	DROPFILES* dfi = static_cast<DROPFILES*>(GlobalLock(hGlobal));
	dfi->pFiles = sizeof(DROPFILES);
	int len3 = len2 - sizeof(DROPFILES);
	assert( len3 > 0 );
	char* pStrDataBgn = reinterpret_cast<char*>(dfi) + sizeof(DROPFILES);
	char* pStrDataEnd = pStrDataBgn + len3;
	int nWri = 0;
	char* ptr;
	for( const auto& sr2 : fnames ){
		ptr = &pStrDataBgn[nWri];
		assert( ptr < pStrDataEnd );
		memcpy( ptr, sr2.c_str(), sr2.size() + 1 );
		nWri += sr2.size() + 1;
	}
	ptr = &pStrDataBgn[nWri];
	assert( ptr < pStrDataEnd );
	*ptr = 0;  // write extra null terminator.
	printf("CPTA DLL Sending message...\n");
	bool rs2 = !!PostMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	//bool rs2 = !!SendMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	if( !rs2 ){
		printf("CPTA DLL: ERROR: post message failed.\n");
		GlobalFree(hGlobal);
		return 0;
	}
	return 1;
}
/**
	Retrieves dir contents given input dir.
	szFlags - string flags:
			  f: get files, d: get dirs, r: recursive to subdirs,
			  s: mark every dir with trailing slash/backslash.
*/
bool hxdw_GetDirFilesRcv( const char* szDir, std::vector<std::string>& fnames, const char* szFlags )
{
	std::string srDir = std::string(szDir) + "\\*";
	bool bRcv   = !!strchr( szFlags, 'r' );
	bool bDirs  = !!strchr( szFlags, 'd' );
	bool bFiles = !!strchr( szFlags, 'f' );
	bool bDSuff = !!strchr( szFlags, 's' );
	WIN32_FIND_DATA wfd;
	memset( &wfd, 0, sizeof(wfd) );
	HANDLE hFnd = FindFirstFile( srDir.c_str(), &wfd );
	if( !hFnd || hFnd == INVALID_HANDLE_VALUE ){
		return 1;
	}
	for( bool rs2 = !!hFnd; rs2; rs2 = FindNextFile( hFnd, &wfd ) ){
		const bool bDir = !!( wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY );
		const std::string bn2 = wfd.cFileName;
		const std::string fn2 = szDir + std::string("\\") + bn2;
		if( bn2 == ".." || bn2 == "." )
			continue;
		if( ( bDir && bDirs ) || ( !bDir && bFiles ) ){
			std::string fn3 = ( (bDSuff && bDir) ?  (fn2 + "\\") : fn2 );
			fnames.push_back(fn3);
		}
		if( bDir && bRcv ){
			if( !hxdw_GetDirFilesRcv( fn2.c_str(), fnames, szFlags ) ){
				return 0;
			}
		}
	}
	return 1;
}
bool hxdw_StrExplode( const char* inp, std::vector<std::string>& parts2,
					const std::vector<char> lsGlueItems, int nLimit, const char* szTrimLR )
{
	assert( !lsGlueItems.empty() );
	const char* sz2 = inp;
	for( ; nLimit; --nLimit ){
		const char *sz3 = 0, *sz4;
		for( auto chr : lsGlueItems ){
			if( (sz4 = strchr(sz2, chr )) ){
				sz3 = std::min<const char*>( (sz3 ? sz3 : sz4), sz4 );
			}
		}
		if(!sz3)
			break;
		assert( sz2 <= sz3 );
		if( sz2 < sz3 ){
			std::string str( sz2, sz3-sz2 );
			if( szTrimLR )
				str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
			parts2.push_back(str);
		}
		sz2 = sz3 + 1;
	}
	if( *sz2 ){
		std::string str( sz2 );
		if( szTrimLR )
			str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
		parts2.push_back(str);
	}
	return 1;
}

int hxdw_FileExists( const char* fname )
{
	WIN32_FIND_DATA FindFileData;
	HANDLE handle2 = FindFirstFile( fname, &FindFileData) ;
	int bFound = handle2 != INVALID_HANDLE_VALUE;
	if( bFound ){
		FindClose( handle2 );
	}
	return bFound;
}
/// Returns pair of base file name part and extension.
/// Extension is without the leading dot character.
std::pair<std::string,std::string> hxdw_SplitExt( const char* inp )
{
	int pos = -1;
	const char* sz2 = strrchr( inp, '\\');
	const char* sz3 = strrchr( inp, '/');
	const char* sz4 = strrchr( inp, '.');
	sz2 = ( sz2 && sz3 ? std::min<const char*>(sz2,sz3) : ( sz2 ? sz2 : sz3 ) );
	if( sz4 && sz4 > sz2 && sz4[1] != 0 ){
		std::string a( inp, sz4-inp );
		std::string b( sz4 + 1 );
		return {a,b};
	}
	return {inp,""};
}

bool hxdw_IsDir( const char* pathname )
{
	bool bDir = !!( FILE_ATTRIBUTE_DIRECTORY & GetFileAttributes( pathname ) );
	return bDir;
}
std::string hxdw_GetTextFileContents( const char* fname )
{
	std::string outp;
	char buf[2048];
	FILE* fp2;
	size_t nread;
	fp2 = fopen( fname, "r" );
	if( !fp2 ){
		return "";
	}
	while( (nread = fread(buf, 1, sizeof(buf), fp2)) > 0 ){
		outp.append( buf, nread );
	}
	if( ferror(fp2) ){
		return "";
	}
	fclose(fp2);
	fp2 = 0;
	return outp;
}
bool hxdw_GetTextLinesFromFile( const char* fname,
								std::vector<std::string>* lines2 )
{
	std::vector<std::string> lines3;
	std::string data2 = hxdw_GetTextFileContents( fname );
	hxdw_StrExplode( data2.c_str(), lines3, {'\n',}, -1, "\r\n" );
	for( auto& a : lines3 ){
		if( !a.empty() ){
			lines2->push_back( a );
		}
	}
	return 1;
}
/// Retrieves command line single argument given 1 or more of its names.
/// names2  - arg-names.
/// szFlags - flags as c-string characters.
///           b: boolean, returns "1" if name has been found.
///           i: case insensitive.
std::string
hxdw_GetArgvByName( const std::vector<std::string> names2,
						int argc2, const char*const* argv2, const char* szFlags )
{
	bool bBool = strchr( szFlags, 'b' );
	bool bCasei = strchr( szFlags, 'i' );
	for( int i=0; i<argc2; i++ ){
		std::string val2, name3 = argv2[i];
		auto a = std::find_if( names2.begin(), names2.end(), [&]( const std::string& a )->bool{
			if( bCasei ){
				return !lstrcmpi( a.c_str(), name3.c_str() );
			}else{
				return a == name3;
			}
		});
		if( a != names2.end() ){
			i++;
			val2 = ( bBool ? "1" : ( i < argc2 ? argv2[i] : "" ) );
			return val2;
		}
	}
	return "";
}
/// Given input path name splits it into dirname and basename pair.
/// Eg. "c:/temp/a.txt" ---> "c:/temp" and "a.txt".
/// Eg. "./data/x.txt"  ---> "./data"  and "x.txt".
/// Eg. "b.txt"         ---> ""        and "b.txt".
std::pair<std::string,std::string> hxdw_SplitPath( const char* inp )
{
	const char* sz2 = strrchr( inp, '/' );
	const char* sz3 = strrchr( inp, '\\' );
	if( (sz2 = std::max<const char*>( sz2, sz3 )) ){
		std::string dirname2( inp, sz2-inp );
		return { dirname2, &sz2[1] };
	}
	return {"", inp,};
}
std::string hxdw_TrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 )
{
	std::string outp;
	int nCount = 0, nRCount = 0;
	bool bLeft = 1, bRight = 1;
	if( flags2 && *flags2 ){
		bLeft = !!strchr( flags2, 'L' );
		bRight = !!strchr( flags2, 'R' );
	}
	if( strchr( flags2, 'L' ) ){
		std::string::const_iterator a;
		for( a = inp.begin(); a != inp.end() && limit2 != nCount; ++a, nCount++ ){
			if( charset2.find( *a ) == std::string::npos )
				break;
		}
	}
	if( strchr( flags2, 'R' ) ){
		std::string::const_reverse_iterator b;
		for( b = inp.rbegin(); b != inp.rend() && limit2 != nRCount; ++b, nRCount++ ){
			if( charset2.find( *b ) == std::string::npos )
				break;
		}
	}
	size_t nChop = static_cast<size_t>( nCount + nRCount );
	assert( nChop <= inp.size() );
	if( nChop == inp.size() )
		return "";
	outp = inp.substr( nCount, inp.size() - nChop );
	return outp;
}
hxdw_IniData2 hxdw_ParseINIFile( const char* szIniFname )
{
	hxdw_IniData2 ini2;
	std::vector<std::string>::iterator a;
	std::vector<std::string> lines2;
	hxdw_GetTextLinesFromFile( szIniFname, &lines2 );
	for( a = lines2.begin(); a != lines2.end(); ++a ){
		*a = hxdw_TrimStr( *a, "\r\n\t\x20", "LR", -1 );
		if( !a->empty() ){
			if( (*a)[0] == '[' && ((*a).back() == ']') ){ //0x5B: bracket open.
				hxdw_IniSection el2;
				el2.first = a->substr( 1, a->size() - 2 );
				ini2.sections2.push_back( el2 );
			}else if( strchr("#;", (*a)[0] ) ){ //if comment
				// just ignore comment.
			}else{
				if( ini2.sections2.empty() )
					ini2.sections2.push_back( hxdw_IniSection() );
				std::vector<std::string> kval;
				hxdw_StrExplode( a->c_str(), kval, {'=',}, 1, "\r\n\t\x20" );
				kval.resize(2);
				if( kval[1].size() >= 2 ){ // then check for quotes strip.
					if( strchr("\x22\x27", kval[1][0] ) && kval[1][0] == kval[1].back() )
						kval[1] = kval[1].substr( 1, kval[1].size() - 2 );
				}
				std::pair<std::string,std::string> el3;
				ini2.sections2.back().second.push_back( { kval[0], kval[1],} );
			}
		}
	}
	return ini2;
}
bool hxdw_IniData2::
eachSection( std::function<bool( const hxdw_IniSection& )> calb2 )const
{
	hxdw_IniData3::const_iterator a;
	for( a = sections2.begin(); a != sections2.end(); ++a ){
		if( !calb2( *a ) )
			break;
	}
	return 1;
}
bool hxdw_IniData2::
eachVariable( const std::vector<std::string> sectnames, std::function<bool( const char* secname, const char* kname, const char* val2 )> calb3 )const
{
	bool rs2 = eachSection( [&]( const hxdw_IniSection& sec2 ){
		if( !sectnames.empty() ){
			auto b = std::find( sectnames.begin(), sectnames.end(), sec2.first );
			if( b == sectnames.end() )
				return 1;
		}
		for( const auto& aVar : sec2.second ){
			if( !calb3( sec2.first.c_str(), aVar.first.c_str(), aVar.second.c_str() ) ){
				return 0;
			}
		}
		return 1;
	});
	return rs2;
}
std::string hxdw_IniData2::getValue( const char* sec2, const char* kname2 )const
{
	std::string val2;
	eachVariable( {sec2,}, [&]( const char* secname, const char* kname3, const char* value2 ){
			if( !strcmp( kname2, kname3 ) ){
				val2 = value2;
				return 0;
			}
			return 1;
	});
	return val2;
}
int hxdw_StrCmpOpt( const char* a, const char* b, int num, const char* flags2 )
{
	bool bCi = !!strchr( flags2, 'i');
	for( ; *a && *b && num; ++a, ++b, --num ){
		if( *a != *b ){
			if(bCi){
				char ch2 = *a, ch3 = *b;
				ch2 = ( ch2 >= 'a' && ch2 <= 'z' ? (ch2 -= ('a'-'A')) : ch2 );
				ch3 = ( ch3 >= 'a' && ch3 <= 'z' ? (ch3 -= ('a'-'A')) : ch3 );
				if( ch2 != ch3 ){
					break;
				}
			}else{
				break;
			}
		}
	}
	return ( !num ? 0 : ( static_cast<int>( *a ) - static_cast<int>( *b ) ) );
	//return 0; // if input c-strings equal.
}
int hxdw_GetFileSize( const char* fname )
{
	FILE* fp2 = fopen( fname, "r" );
	if( fp2 ){
		fseek( fp2, 0, SEEK_END );
		int nEnd = (int)ftell( fp2 );
		fclose(fp2);
		return nEnd;
	}
	return 0;
}




