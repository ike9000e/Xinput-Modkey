
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <string>
#include <windows.h>
#include <commdlg.h>
#include <xinput.h>
#include "hxdw/hxdw_utils.h"

extern "C" __declspec(dllexport) int xidf_dll_dummy();

/*
typedef struct _XINPUT_STATE {
  DWORD          dwPacketNumber;
  XINPUT_GAMEPAD Gamepad;
} XINPUT_STATE, *PXINPUT_STATE;
typedef struct _XINPUT_GAMEPAD {
  WORD  wButtons;
  BYTE  bLeftTrigger;
  BYTE  bRightTrigger;
  SHORT sThumbLX;
  SHORT sThumbLY;
  SHORT sThumbRX;
  SHORT sThumbRY;
} XINPUT_GAMEPAD, *PXINPUT_GAMEPAD;
*/
// XInputGetState()
using XInputGetState_t = DWORD __stdcall( DWORD dwUserIndex,XINPUT_STATE *pState );
DWORD (WINAPI*  ori_XInputGetState)( DWORD dwUserIndex,XINPUT_STATE *pState ) = XInputGetState;
DWORD WINAPI    xidf_XInputGetState( DWORD dwUserIndex,XINPUT_STATE *pState );

//DWORD XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, PXINPUT_KEYSTROKE pKeystroke );
//Xinput1_3.dll, Xinput1_4.dll, XInputGetKeystroke
//https://docs.microsoft.com/en-us/windows/desktop/api/xinput/nf-xinput-xinputgetkeystroke
//using XInputGetKeystroke_t = DWORD( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke );
//DWORD (WINAPI*  ori_XInputGetKeystroke)( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke ) = XInputGetKeystroke;
//DWORD WINAPI    xidf_XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke );

enum{
	Xidf_Act_START = 1001, Xidf_Act_BACK,
	Xidf_Act_A, Xidf_Act_B, Xidf_Act_X, Xidf_Act_Y,
	Xidf_Act_LT, Xidf_Act_RT,
	Xidf_Act_UP, Xidf_Act_DOWN, Xidf_Act_LEFT, Xidf_Act_RIGHT,
	Xidf_Act_LS, Xidf_Act_RS,
	Xidf_Act_LSXAdd,
	Xidf_Act_LSXSub,
	Xidf_Act_LSYAdd,
	Xidf_Act_LSYSub,
	Xidf_Act_RSXAdd,
	Xidf_Act_RSXSub,
	Xidf_Act_RSYAdd,
	Xidf_Act_RSYSub,
	Xidf_Act_LTr, Xidf_Act_RTr,
};
struct Xidf_Trigger{
	int ident4;
	std::vector<int> modkeyIds;   // modkey identifiers of Xidf_Modkey.
	std::vector<int> buttons2;    // eg. Xidf_Act_A
};
const int Xidf_MaxStickPos = 32767;
const int Xidf_MaxTriggerPos = 255;

struct Xidf_Modkey{
	int               ident3 = 0;
	int               btnActivator = 0;  //eg. Xidf_Act_A
	int               btnBitIfAny = 0;   //eg. XINPUT_GAMEPAD_A
	int               threshold2 = 0;    //max=32767; eg. 7001. only for analog inputs (eg. Xidf_Act_LSXAdd).
	int               limit2 = -1;
	int               timeout2 = 0;
	std::string       rename2;
	bool              bSuppress = 0;
};
struct Xidf_ModkeyDown{
	const Xidf_Modkey*  mod2;
	bool                bDown2 = 0;
	Xidf_ModkeyDown( const Xidf_Modkey* mod2_ ) : mod2(mod2_) {}
	static Xidf_ModkeyDown* findModkey( int ident, Xidf_ModkeyDown* inp, size_t num );
};
struct Xidf_Routine{
	int                       ident2;
	Xidf_Trigger              trigger2;
	std::vector<int>          aSuppress;   //eg. Xidf_Act_A
	std::vector<int>          aHold;       //eg. Xidf_Act_A
	bool                      bHExclusive = 0;
};
struct Xidf_RoutineLive{
	const Xidf_Routine*  routine2 = 0;
	bool                 bLive = 0;
	Xidf_RoutineLive( const Xidf_Routine* action2_ ) : routine2(action2_) {}
};
struct Xidf_Perform{
	DWORD            dwUserIndex2;  //Index of the user's controller. Can be a value from 0 to 3.
	XINPUT_STATE&    xistate;
	Xidf_Perform( XINPUT_STATE& xistate_, DWORD dwUserIndex2_ ) : xistate(xistate_), dwUserIndex2(dwUserIndex2_) {}
};
struct XidfGlobals{
	std::string                   srDllPath, srCfgFname, srLogFile;
	std::string                   srXiDllFName = "eDAuto"; //"eDAuto","Xinput1_3.dll"
	bool                          bInited = 0, bCLIOnly = 0;
	bool                          bEnforceAPIDeadzones = 0;
	std::vector<Xidf_Modkey>      modkeys3;
	std::vector<Xidf_Routine>     routines2;
	int                           nLastModkId = 2001, nLastTriggerId = 3001;
	std::vector<Xidf_ModkeyDown>  aModsDown;
	std::vector<Xidf_RoutineLive> aRoutinesLive;
	int                           nGamepadIndex = 0;
	std::vector<int>              aGlobSuppr;
};
extern XidfGlobals* XidfData;

void xidf_MsgBoxIf( HWND hwnd, const char* msg, const char* flags2 = "" );
bool xidf_InitData( HINSTANCE hInst );
void xidf_EnforceAPIDeadZones( XINPUT_GAMEPAD& gp2 );
bool xidf_ParseModkeys2( const hxdw_IniData2& ini3, std::vector<Xidf_Modkey>& modkeysOu, std::string* err2 );
bool xidf_ParseOneModkey( const char* inp, Xidf_Modkey& outp, int nNr, std::string* err2 );
bool xidf_ParseActions( const hxdw_IniData2& ini3, std::vector<Xidf_Routine>& actionsOu, std::string* err2 );
bool xidf_ParseTriggerSequence( const char* inp, Xidf_Trigger& outp, std::string* err2 );
int  xidf_FindModkeyByName( const char* modkname, const std::vector<Xidf_Modkey>& modkeys_ );
bool xidf_ActionsToArray( const char* szBtnNames, char glue2, std::vector<int>& outp, std::string* err2 );
bool xidf_IsStickAction( int eAction );
bool xidf_IsTriggerAction( int eAction );
int  xidf_ActionToBitIfAny( int eBtn );
bool xidf_TestAnalogueModkeyDown( int eBtn2, int threshold3, const XINPUT_GAMEPAD& gpd );
bool xidf_IsActionDown( int eBtn, const XINPUT_GAMEPAD& gpd, const std::pair<int,int> aRange );
int  xidf_GetThresholdForActionIfAny( int eBtn );
bool xidf_PerformModkeys( Xidf_Perform& inp );
void xidf_RoutineLivePerform( const Xidf_RoutineLive& actn2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_SuppressXiButtonGivenAction( int eAction, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
auto xidf_GetLocalTimeStr() -> std::string;
void xidf_LogMessage( const char* flags2, const char* szMsg );
int  xidf_StrToLimit( const char* inp, int eAct );

