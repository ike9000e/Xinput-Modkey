#include "xidf_dll_main.h"
#include "detours.h"
#include <process.h>   //_getpid()
#include <assert.h>
#include <algorithm>

BOOL WINAPI DllMain( HINSTANCE hInst, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			assert( !XidfData );
			XidfData = new XidfGlobals;
			printf("XIDF: Starting DLL\n");
			//printf("XIDF: dll path: [%s]\n", XidfData->srDllPath.c_str() );
			xidf_InitData( hInst );
			DetourTransactionBegin();
			DetourUpdateThread( GetCurrentThread() );
			//DetourAttach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
			{
				HINSTANCE hDll2 = LoadLibrary( XidfData->srXiDllFName.c_str() );
				assert( hDll2 );
				ori_XInputGetState = (XInputGetState_t*) GetProcAddress( hDll2, "XInputGetState" );
				assert( ori_XInputGetState );
				DetourAttach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
			}
			DetourTransactionCommit();
		}
		break;
	case DLL_PROCESS_DETACH:
		assert( XidfData );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
		DetourTransactionCommit();
		xidf_LogMessage("", "DLL_PROCESS_DETACH");

		delete XidfData;
		XidfData = 0;
		break;
	}
	return 1;
}
/// This is only for the dummy symbol name exporting; to make it
/// available for when patching some executables.
int xidf_dll_dummy()
{
	return 49775;
}
DWORD WINAPI xidf_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pState )
{
	XINPUT_STATE& sta = *pState;
	XINPUT_GAMEPAD& gpd = sta.Gamepad;
	DWORD rs2 = ori_XInputGetState( dwUserIndex, &sta );
	if( XidfData->bEnforceAPIDeadzones ){
		xidf_EnforceAPIDeadZones( gpd, XidfData->bADZReinterpolate );
	}
	//if( gpd.wButtons & XINPUT_GAMEPAD_A ){
	//	gpd.wButtons |= XINPUT_GAMEPAD_X;
	//}
	//32767 * 2 = 65534
	Xidf_Perform prf( *pState, dwUserIndex );
	xidf_PerformModkeys( prf );

	//if( sta.dwPacketNumber ){
	//}
	return rs2;
}
bool xidf_InitData( HINSTANCE hInst )
{
	char bfr2[MAX_PATH] = ""; std::string str, err2;
	{
		const char* sz2; std::string srTmpDir;
		std::vector<std::string> aTmps2 = {"C:\\Temp","%TEMP%","%TMP%",};
		for( const auto& a : aTmps2 ){
			if( a[0] == '%' ){
				str = hxdw_TrimStr( a, "%", "LR", -1 );
				if( (sz2 = getenv( str.c_str() )) ){
					if( hxdw_IsDir( sz2 ) ){
						srTmpDir = sz2;
						break;
					}
				}
			}else if( hxdw_IsDir( a.c_str() ) ){
				srTmpDir = a.c_str();
				break;
			}
		}
		if( !srTmpDir.empty() ){
			sprintf_s( bfr2, sizeof(bfr2), "%s\\xinput_modkey.log", srTmpDir.c_str() );
			XidfData->srLogFile = bfr2;
			printf("XIDF: Log file: [%s]\n", XidfData->srLogFile.c_str() );
			if( (128*1024) < hxdw_GetFileSize( XidfData->srLogFile.c_str() ) ){
				DeleteFile( XidfData->srLogFile.c_str() );
			}
		}
	}
	GetModuleFileName( hInst, bfr2, sizeof(bfr2) );
	XidfData->srDllPath = bfr2;

	if( !XidfData->srLogFile.empty() ){
		sprintf_s( bfr2, sizeof(bfr2), "%s Starting from [%s]",
				xidf_GetLocalTimeStr().c_str(), XidfData->srDllPath.c_str() );
		xidf_LogMessage( "", bfr2 );
		//
		GetModuleFileName( 0, bfr2, sizeof(bfr2)-1 );
		std::string srExec = bfr2;
		sprintf_s( bfr2, sizeof(bfr2), "Executable name [%s]", srExec.c_str() );
		xidf_LogMessage( "", bfr2 );
	}
	std::pair<std::string,std::string> dp2;
	dp2 = hxdw_SplitPath( XidfData->srDllPath.c_str() );
	XidfData->srCfgFname = dp2.first + "\\" + hxdw_SplitExt( dp2.second.c_str() ).first + ".ini";
	printf("XIDF: Config path: [%s]\n", XidfData->srCfgFname.c_str() );

	if( !hxdw_FileExists( XidfData->srCfgFname.c_str() ) ){
		printf("XIDF: ERROR: configuration file not found.\n");
		return 0;
	}
	hxdw_IniData2 ini2 = hxdw_ParseINIFile( XidfData->srCfgFname.c_str() );
	XidfData->bEnforceAPIDeadzones = !!atoi( ini2.getValue( "s_main", "bEnforceAPIDeadzones" ).c_str() );
	XidfData->bADZReinterpolate = !!atoi( ini2.getValue( "s_main", "bADZReinterpolate" ).c_str() );
	XidfData->nGamepadIndex = !!atoi( ini2.getValue( "s_main", "nGamepadIndex" ).c_str() );
	if( !( str = ini2.getValue( "s_main", "szXinputDllName" ).c_str() ).empty() ){
		if( str == "eDAuto" ){
			// Enumerate DLLs in the PE executable.
			for( HMODULE hDll3 = 0; (hDll3 = DetourEnumerateModules(hDll3)); ){
				char szName[MAX_PATH] = {0,};
				GetModuleFileNameA(hDll3, szName, sizeof(szName) - 1);
				str = hxdw_SplitPath( szName ).second;
				// Below: eg. marches when: "XINPUT9_1_0.dll", "Xinput1_3.dll", etc.
				if( !hxdw_StrCmpOpt( "xinput", str.c_str(), 0x0006, "i" ) ){
					if( strchr( "19", str[0x0006] ) ){
						XidfData->srXiDllFName = str;
						//printf("DLL: [%s]\n", str.c_str() );
						break;
					}
				}
			}
		}else{
			XidfData->srXiDllFName = str;
		}
	}
	if( !(str = ini2.getValue( "s_main", "szGlobalSuppress" ).c_str()).empty() ){
		if( !xidf_ActionsToArray( str.c_str(), ',', XidfData->aGlobSuppr, &err2 ) ){
			printf("XIDF: ERROR: %s\n", err2.c_str() );
			return 0;
		}
	}
	printf("XIDF: Using Xinput DLL file: [%s]\n", XidfData->srXiDllFName.c_str() );
	sprintf_s( bfr2, sizeof(bfr2), "Using Xinput DLL [%s]", XidfData->srXiDllFName.c_str() );
	xidf_LogMessage("", bfr2 );

	if( !xidf_ParseModkeys2( ini2, XidfData->modkeys3, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfData->modkeys3 ){
		XidfData->aModsDown.push_back( Xidf_ModkeyDown( &a ) );
	}
	if( !xidf_ParseTrInputs( ini2, XidfData->trInputs, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfData->trInputs ){
		XidfData->aTrInputLive.push_back( Xidf_TrInputLive( &a ) );
	}

	if( !xidf_ParseRoutines( ini2, XidfData->routines2, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfData->routines2 ){
		XidfData->aRoutinesLive.push_back( Xidf_RoutineLive( &a ) );
	}
	XidfData->bInited = 1;
	return 1;
}
std::string xidf_GetLocalTimeStr()
{
	char buf[128];
	SYSTEMTIME stt;
	GetLocalTime( &stt ); // Local time
	sprintf_s( buf, sizeof(buf), "%04u%02u%02u%02u%02u%02u",
			stt.wYear, stt.wMonth, stt.wDay,
			stt.wHour, stt.wMinute, stt.wSecond ); // 24h format
	return buf;
}
void xidf_LogMessage( const char* flags2, const char* szMsg )
{
	if( !XidfData->srLogFile.empty() ){
		FILE* fp2 = fopen( XidfData->srLogFile.c_str(), "ab" );
		if(fp2){
			std::string srMesg = hxdw_TrimStr( szMsg, "\r\n", "R", -1 );
			char bfr2[2048];
			sprintf_s( bfr2, sizeof(bfr2), "%d: %s\r\n", _getpid(), srMesg.c_str() );
			fwrite( bfr2, 1, strlen(bfr2), fp2 );
			fclose(fp2);
		}
	}
}
