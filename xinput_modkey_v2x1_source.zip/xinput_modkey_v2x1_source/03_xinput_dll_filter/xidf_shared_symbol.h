#pragma once

#ifdef XIDF_USER
#	define XIDF_API __declspec(dllimport)
#else
#	define XIDF_API __declspec(dllexport)
#endif //XIDF_USER

extern "C" XIDF_API int xidf_dll_dummy();
