//#ifndef XIDF_FUNCTIONS_H_INCLUDED
//#define XIDF_FUNCTIONS_H_INCLUDED
#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <string>
#include <windows.h>
#include <commdlg.h>
#include <xinput.h>
#include "hxdw/hxdw_utils.h"

enum{
	Xidf_TI_MouseMove = 3001, //"eMouseMotion"
	Xidf_TI_KbdArrows,
	//
	Xidf_IP_Linear = 4001, //interpolation linear.
	Xidf_IP_Exp,
};

enum{
	Xidf_Act_START = 1001, Xidf_Act_BACK,
	Xidf_Act_A, Xidf_Act_B, Xidf_Act_X, Xidf_Act_Y,
	Xidf_Act_LT, Xidf_Act_RT,
	Xidf_Act_UP, Xidf_Act_DOWN, Xidf_Act_LEFT, Xidf_Act_RIGHT,
	Xidf_Act_LS, Xidf_Act_RS,
	Xidf_Act_LSXAdd,
	Xidf_Act_LSXSub,
	Xidf_Act_LSYAdd,
	Xidf_Act_LSYSub,
	Xidf_Act_RSXAdd,
	Xidf_Act_RSXSub,
	Xidf_Act_RSYAdd,
	Xidf_Act_RSYSub,
	Xidf_Act_LTr, Xidf_Act_RTr,
};
struct Xidf_Trigger{
	int ident4;
	std::vector<int> modkeyIds;   // modkey identifiers of Xidf_Modkey.
	std::vector<int> buttons2;    // eg. Xidf_Act_START
};
const int Xidf_MaxStickPos = 32767;
const int Xidf_MaxTriggerPos = 255;

struct Xidf_Modkey{
	int               ident3 = 0;
	int               btnActivator = 0;  //eg. Xidf_Act_START
	int               btnBitIfAny = 0;   //eg. XINPUT_GAMEPAD_A
	int               threshold2 = 0;    //max=32767; eg. 7001. only for analog inputs (eg. Xidf_Act_LSXAdd).
	int               limit2 = -1;
	int               timeout2 = 0;
	std::string       rename2;
	bool              bSuppress = 0;
};
struct Xidf_ModkeyDown{
	const Xidf_Modkey*  mod2;
	bool                bDown2 = 0;
	Xidf_ModkeyDown( const Xidf_Modkey* mod2_ ) : mod2(mod2_) {}
	static Xidf_ModkeyDown* findModkey( int ident, Xidf_ModkeyDown* inp, size_t num );
};
enum{
	Xidf_IT_Gamepad = 201,
	Xidf_IT_Key,
	Xidf_IT_MouseButton,
};
struct Xidf_Input{
	int type2  = 0;  // eg. Xidf_IT_Gamepad
	int input2 = 0;  // eg. Xidf_Act_START, virtual-key-code, or mouse-button.
	Xidf_Input( int type2_, int input2_ ) : type2(type2_), input2(input2_) {}
};
struct Xidf_SendKey{
	int ident6 = 0;
	int nVk = 0, nIntrvl = 16, nMouseBtn = 0;
	Xidf_SendKey( int nVk_, int ident_ ) : nVk(nVk_), ident6(ident_) {}
};
struct Xidf_Routine{
	int                       ident2;
	Xidf_Trigger              trigger2;
	std::vector<int>          aSuppress;   //eg. Xidf_Act_START
	std::vector<Xidf_Input>   aHold2;
	bool                      bHExclusive = 0;
	std::vector<Xidf_SendKey> aSendVk;
};
struct Xidf_RoutineLive{
	const Xidf_Routine*  routine2 = 0;
	bool                 bLive = 0;
	std::vector<std::pair<int,uint64_t> > aSendksLive;  //<id,start-at>
	Xidf_RoutineLive( const Xidf_Routine* action2_ ) : routine2(action2_) {}
};
/// Translate input structure.
struct Xidf_TrInput{
	int               ident5 = 0;
	int               eOutputTy = 0;  // output type, eg. Xidf_TI_MouseMove
//	int               eIntrplTy = 0;  // interpolation type, eg. Xidf_IP_Linear.
//	float             fInterpolateFac = 1.0f;
	int               nMovementPerSec = 512;
//	float             fAccelFac = 1.f;
	Xidf_Trigger      trigger4;
	std::vector<int>  inputs2;        //eg. Xidf_Act_START
//	std::vector<int>  accelerators2;  //eg. Xidf_Act_START
};
struct Xidf_TrInputLive{
	const Xidf_TrInput*       trInput2 = 0;
	std::pair<bool,uint64_t>  bLive3 = {0,0,};  // <is-live,timestamp>
	Xidf_TrInputLive( const Xidf_TrInput* tr2_ ) : trInput2(tr2_) {}
};
struct Xidf_Perform{
	DWORD            dwUserIndex2;  //Index of the user's controller. Can be a value from 0 to 3.
	XINPUT_STATE&    xistate;
	Xidf_Perform( XINPUT_STATE& xistate_, DWORD dwUserIndex2_ ) : xistate(xistate_), dwUserIndex2(dwUserIndex2_) {}
};
struct XidfGlobals{
	std::string                   srDllPath, srCfgFname, srLogFile;
	std::string                   srXiDllFName = "eDAuto"; //"eDAuto","Xinput1_3.dll"
	bool                          bInited = 0, bCLIOnly = 0;
	bool                          bEnforceAPIDeadzones = 0, bADZReinterpolate = 0;
	std::vector<Xidf_Modkey>      modkeys3;
	std::vector<Xidf_Routine>     routines2;
	std::vector<Xidf_TrInput>     trInputs;
	int                           nLastModkId = 2001, nLastTriggerId = 3001, nLastTr2Id = 4001, nLastSendkId = 5001;
	std::vector<Xidf_ModkeyDown>  aModsDown;
	std::vector<Xidf_RoutineLive> aRoutinesLive;
	std::vector<Xidf_TrInputLive> aTrInputLive;
	int                           nGamepadIndex = 0;
	std::vector<int>              aGlobSuppr;
};
extern XidfGlobals* XidfData;

void xidf_MsgBoxIf( HWND hwnd, const char* msg, const char* flags2 = "" );
void xidf_EnforceAPIDeadZones( XINPUT_GAMEPAD& gp2, bool bReinterpolate );
bool xidf_ParseModkeys2( const hxdw_IniData2& ini3, std::vector<Xidf_Modkey>& modkeysOu, std::string* err2 );
bool xidf_ParseOneModkey( const char* inp, Xidf_Modkey& outp, int nNr, std::string* err2 );
bool xidf_ParseRoutines( const hxdw_IniData2& ini3, std::vector<Xidf_Routine>& actionsOu, std::string* err2 );
bool xidf_ParseTrInputs( const hxdw_IniData2& ini3, std::vector<Xidf_TrInput>& actionsOu, std::string* err2 );
bool xidf_ParseTriggerSequence( const char* inp, Xidf_Trigger& outp, std::string* err2, const char* flags2 );
auto xidf_FindModkeyById( int ident_ ) -> Xidf_Modkey*;
bool xidf_ActionsToArray( const char* szBtnNames, char glue2, std::vector<int>& outp, std::string* err2 );
bool xidf_IsStickAction( int eAction );
bool xidf_IsTriggerAction( int eAction );
int  xidf_ActionToBitIfAny( int eBtn );
bool xidf_TestActionDown( int eBtn2, int threshold3, const XINPUT_GAMEPAD& gpd );
auto xidf_GetInputValueForAction( int eBtn2, const XINPUT_GAMEPAD& gpd ) -> std::pair<int,float>;
bool xidf_IsActionDown( int eBtn, const XINPUT_GAMEPAD& gpd, const std::pair<int,int> aRangeFloorCeil );
int  xidf_GetThresholdForActionIfAny( int eBtn );
bool xidf_PerformModkeys( Xidf_Perform& inp );
bool xidf_PerformTrInputLive( Xidf_TrInputLive& trInpLv, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_PerformCleanup();
void xidf_RoutineLivePerform( const Xidf_RoutineLive& actn2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_RoutineLiveOnDown( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_RoutineLiveOnUp( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_SetGamepadValue( int eAction, int nNewValue, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_SetGamepadValue2( int eAction, float fNewValue, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
int  xidf_FindModkeyByName( const char* modkname, const std::vector<Xidf_Modkey>& modkeys_ );
bool xidf_IsAnalogueActionType( int eBtn );
bool xidf_IsTriggerDown( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd, std::vector<int>* aPerTrgrDn2 );
int  xidf_Reinterpolate( int val, int deadzone2, int nMaxPosition );
int  xidf_ApplyDeadZoneIfNeeded( int val, int deadzone2, int nMaxPosition );
void xidf_FgsSquareToDisc( double x, double y, double& xo, double& yo );
int  xidf_GetMouseFlags( int nMButton, const char* flags2 );
int  xidf_StrToTrInputMode( const char* inp );
bool xidf_StrToInputList( const char* szBtnNames, char glue2, std::vector<Xidf_Input>& outp, std::string* err2 );
int  xidf_StrToLimit( const char* inp, int eAct );
int  xidf_StrToGamepadAction( const char* inp );
int  xidf_StrToKeyAction( const char* inp );
auto xidf_GetValuesForRoutine( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd2 ) -> std::vector<std::pair<int,float> >;

//#endif // XIDF_FUNCTIONS_H_INCLUDED
