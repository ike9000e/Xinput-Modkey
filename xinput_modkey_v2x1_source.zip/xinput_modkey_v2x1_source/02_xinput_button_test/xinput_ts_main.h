#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <string>
#include "CXBOXController.h"

// Xbox 360 Controller Input in C++ with XInput
// https://www.codeproject.com/Articles/26949/Xbox-Controller-Input-in-C-with-XInput

//typedef struct _XINPUT_GAMEPAD {
//	WORD wButtons;
//	BYTE bLeftTrigger;
//	BYTE bRightTrigger;
//	SHORT sThumbLX;
//	SHORT sThumbLY;
//	SHORT sThumbRX;
//	SHORT sThumbRY;
//} XINPUT_GAMEPAD, *PXINPUT_GAMEPAD;

