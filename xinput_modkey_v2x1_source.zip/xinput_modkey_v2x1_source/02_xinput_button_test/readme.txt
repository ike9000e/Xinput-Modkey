
Test xinput gamepads
--------------------------


Based on example by Minalien:

    Xbox 360 Controller Input in C++ with XInput
    https://www.codeproject.com/Articles/26949/Xbox-Controller-Input-in-C-with-XInput
    Minalien, 14 Jun 2008
    >> A small tutorial on how to use XInput (requires the DX SDK) to handle input from an Xbox 360 Controller for Windows.
