#include "hxdw_utils.h"
#include <stdint.h>
#include <assert.h>
#pragma warning( disable : 4091 ) // Win SDK 7.1 | shlobj.h warning C4091: typedef ignored on left of tagGPFIDL_FLAGS ...
#include <shlobj.h>
#include <commdlg.h>
#include <memory>

// vector(960): warning C4530: C++ exception handler used, but unwind
// semantics are not enabled. Specify /EHsc (aka. /GX)

/// Used internally by hxdw_FindWndByCaptionPart().
struct hxdw_WndEnumFuncCalbData{
	std::function<bool(HWND, const char*)> calb5;
};
BOOL CALLBACK hxdw_WndEnumFunc( HWND hwnd, LPARAM lParam )
{
	//char classname2[256];
	//GetClassName( hwnd, classname2, 256 );
	char caption2[256];
	GetWindowText( hwnd, caption2, 256 );
	hxdw_WndEnumFuncCalbData* cd2 = (hxdw_WndEnumFuncCalbData*)lParam;
	//if( !(*cd2->calb4)( hwnd, caption2 ) )
	if( !(cd2->calb5)( hwnd, caption2 ) ){
		return 0;
	}
	return 1;
}
/// Finds window by partial text of caption (title).
HWND hxdw_FindWndByCaptionPart( const char* szNeedle, const char* flags2 )
{
	std::vector<HWND> wnds;
	auto calb2 = [&]( HWND hwnd2, const char* szCaption )->bool{
		bool bFound = !!strstr( szCaption, szNeedle );
		if(bFound)
			wnds.push_back(hwnd2);
		return 1;
	};
	hxdw_WndEnumFuncCalbData cdt;
	cdt.calb5   = calb2;
	EnumWindows( hxdw_WndEnumFunc, (LPARAM)&cdt );
	if( strchr( flags2, 'b' ) ){
		return ( wnds.empty() ? 0 : wnds.back() );
	}else{
		return ( wnds.empty() ? 0 : wnds[0] );
	}
}

bool hxdw_SendDropFilesToWnd( HWND hwnd, const std::vector<std::string>& fnames )
{
	int len2 = sizeof(DROPFILES);
	for( auto sr2 : fnames ){
		len2 += strlen(sr2.c_str()) + 1;
	}
	len2 += 1; //one more for extra null terminator.
	HGLOBAL hGlobal = GlobalAlloc( GHND, len2 );
	if( !hGlobal ){
		printf("CPTA DLL: ERROR: global data alloc failed.\n");
		return 0;
	}
	DROPFILES* dfi = static_cast<DROPFILES*>(GlobalLock(hGlobal));
	dfi->pFiles = sizeof(DROPFILES);
	int len3 = len2 - sizeof(DROPFILES);
	assert( len3 > 0 );
	char* pStrDataBgn = reinterpret_cast<char*>(dfi) + sizeof(DROPFILES);
	char* pStrDataEnd = pStrDataBgn + len3;
	int nWri = 0;
	char* ptr;
	for( const auto& sr2 : fnames ){
		ptr = &pStrDataBgn[nWri];
		assert( ptr < pStrDataEnd );
		memcpy( ptr, sr2.c_str(), sr2.size() + 1 );
		nWri += sr2.size() + 1;
	}
	ptr = &pStrDataBgn[nWri];
	assert( ptr < pStrDataEnd );
	*ptr = 0;  // write extra null terminator.
	printf("CPTA DLL Sending message...\n");
	bool rs2 = !!PostMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	//bool rs2 = !!SendMessage( hwnd, WM_DROPFILES, (WPARAM)hGlobal, 0 );
	if( !rs2 ){
		printf("CPTA DLL: ERROR: post message failed.\n");
		GlobalFree(hGlobal);
		return 0;
	}
	return 1;
}
/**
	Retrieves dir contents given input dir.
	szFlags - string flags:
			  f: get files, d: get dirs, r: recursive to subdirs,
			  s: mark every dir with trailing slash/backslash.
*/
bool hxdw_GetDirFilesRcv( const char* szDir, std::vector<std::string>& fnames, const char* szFlags )
{
	std::string srDir = std::string(szDir) + "\\*";
	bool bRcv   = !!strchr( szFlags, 'r' );
	bool bDirs  = !!strchr( szFlags, 'd' );
	bool bFiles = !!strchr( szFlags, 'f' );
	bool bDSuff = !!strchr( szFlags, 's' );
	WIN32_FIND_DATA wfd;
	memset( &wfd, 0, sizeof(wfd) );
	HANDLE hFnd = FindFirstFile( srDir.c_str(), &wfd );
	if( !hFnd || hFnd == INVALID_HANDLE_VALUE ){
		return 1;
	}
	std::shared_ptr<int> ptr( 0, [&]( int* ){
			if(hFnd){ FindClose(hFnd); hFnd = 0; }
	});
	for( bool rs2 = !!hFnd; rs2; rs2 = FindNextFile( hFnd, &wfd ) ){
		const bool bDir = !!( wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY );
		const std::string bn2 = wfd.cFileName;
		const std::string fn2 = szDir + std::string("\\") + bn2;
		if( bn2 == ".." || bn2 == "." )
			continue;
		if( ( bDir && bDirs ) || ( !bDir && bFiles ) ){
			std::string fn3 = ( (bDSuff && bDir) ?  (fn2 + "\\") : fn2 );
			fnames.push_back(fn3);
		}
		if( bDir && bRcv ){
			if( !hxdw_GetDirFilesRcv( fn2.c_str(), fnames, szFlags ) ){
				return 0;
			}
		}
	}
	return 1;
}
std::string hxdw_StrImplode( const std::vector<std::string>& parts2, const std::string glue2, const char* szTrimLR )
{
	std::string z; int i = 0;
	for( auto str : parts2 ){
		if( i )
			z += glue2;
		if(szTrimLR)
			str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
		z += str;
		i++;
	}
	return z;
}
bool hxdw_StrExplode( const char* inp, std::vector<std::string>& parts2,
					const std::vector<char> lsGlueItems, int nLimit, const char* szTrimLR )
{
	assert( !lsGlueItems.empty() );
	const char* sz2 = inp;
	for( ; nLimit; --nLimit ){
		const char *sz3 = 0, *sz4;
		for( auto chr : lsGlueItems ){
			if( (sz4 = strchr(sz2, chr )) ){
				sz3 = std::min<const char*>( (sz3 ? sz3 : sz4), sz4 );
			}
		}
		if(!sz3)
			break;
		assert( sz2 <= sz3 );
		if( sz2 < sz3 ){
			std::string str( sz2, sz3-sz2 );
			if( szTrimLR )
				str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
			parts2.push_back(str);
		}
		sz2 = sz3 + 1;
	}
	if( *sz2 ){
		std::string str( sz2 );
		if( szTrimLR )
			str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
		parts2.push_back(str);
	}
	return 1;
}
/// Returns pair of base file name part and extension.
/// Extension is without the leading dot character.
std::pair<std::string,std::string> hxdw_SplitExt( std::string inp2 )
{
	const char* inp = inp2.c_str();
	int pos = -1;
	const char* sz2 = strrchr( inp, '\\');
	const char* sz3 = strrchr( inp, '/');
	const char* sz4 = strrchr( inp, '.');
	sz2 = ( sz2 && sz3 ? std::min<const char*>(sz2,sz3) : ( sz2 ? sz2 : sz3 ) );
	if( sz4 && sz4 > sz2 && sz4[1] != 0 ){
		std::string a( inp, sz4-inp );
		std::string b( sz4 + 1 );
		return {a,b};
	}
	return {inp,""};
}
int hxdw_FileExists( const char* fname )
{
	WIN32_FIND_DATA FindFileData;
	HANDLE handle2 = FindFirstFile( fname, &FindFileData) ;
	int bFound = handle2 != INVALID_HANDLE_VALUE;
	if( bFound ){
		FindClose( handle2 );
	}
	return bFound;
}
bool hxdw_IsDir( const char* pathname )
{
	if( hxdw_FileExists(pathname) ){
		bool bDir = !!( FILE_ATTRIBUTE_DIRECTORY & GetFileAttributes( pathname ) );
		return bDir;
	}
	return 0;
}
std::string hxdw_GetTextFileContents( const char* fname )
{
	std::string outp;
	char buf[2048];
	FILE* fp2;
	size_t nread;
	fp2 = fopen( fname, "r" );
	if( !fp2 ){
		return "";
	}
	while( (nread = fread(buf, 1, sizeof(buf), fp2)) > 0 ){
		outp.append( buf, nread );
	}
	if( ferror(fp2) ){
		return "";
	}
	fclose(fp2);
	fp2 = 0;
	return outp;
}
bool hxdw_GetTextLinesFromFile( const char* fname,
								std::vector<std::string>* lines2 )
{
	std::vector<std::string> lines3;
	std::string data2 = hxdw_GetTextFileContents( fname );
	hxdw_StrExplode( data2.c_str(), lines3, {'\n',}, -1, "\r\n" );
	for( auto& a : lines3 ){
		if( !a.empty() ){
			lines2->push_back( a );
		}
	}
	return 1;
}
/// Retrieves command line single argument given 1 or more of its names.
/// names2  - arg-names.
/// szFlags - flags as c-string characters.
///           b: boolean, returns "1" if name has been found.
///           i: case insensitive.
std::string
hxdw_GetArgvByName( const std::vector<std::string> names2,
						int argc2, const char*const* argv2, const char* szFlags )
{
	bool bBool = strchr( szFlags, 'b' );
	bool bCasei = strchr( szFlags, 'i' );
	for( int i=0; i<argc2; i++ ){
		std::string val2, name3 = argv2[i];
		auto a = std::find_if( names2.begin(), names2.end(), [&]( const std::string& a )->bool{
			if( bCasei ){
				return !lstrcmpi( a.c_str(), name3.c_str() );
			}else{
				return a == name3;
			}
		});
		if( a != names2.end() ){
			i++;
			val2 = ( bBool ? "1" : ( i < argc2 ? argv2[i] : "" ) );
			return val2;
		}
	}
	return "";
}
/// Given input path name splits it into dirname and basename pair.
/// Eg. "c:/temp/a.txt" ---> "c:/temp" and "a.txt".
/// Eg. "./data/x.txt"  ---> "./data"  and "x.txt".
/// Eg. "b.txt"         ---> ""        and "b.txt".
std::pair<std::string,std::string> hxdw_SplitPath( std::string inp2 )
{
	inp2 = hxdw_TrimStr( inp2, "\\/", "R", -1 );
	{
		const char* inp = inp2.c_str();
		const char* sz2 = strrchr( inp, '/' );
		const char* sz3 = strrchr( inp, '\\' );
		if( (sz2 = std::max<const char*>( sz2, sz3 )) ){
			std::string dirname2( inp, sz2-inp );
			return { dirname2, &sz2[1] };
		}
		return {"", inp,};
	}
}
std::string hxdw_TrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 )
{
	std::string outp;
	int nCount = 0, nRCount = 0;
	bool bLeft = 1, bRight = 1;
	if( flags2 && *flags2 ){
		bLeft = !!strchr( flags2, 'L' );
		bRight = !!strchr( flags2, 'R' );
	}
	if( strchr( flags2, 'L' ) ){
		std::string::const_iterator a;
		for( a = inp.begin(); a != inp.end() && limit2 != nCount; ++a, nCount++ ){
			if( charset2.find( *a ) == std::string::npos )
				break;
		}
	}
	if( strchr( flags2, 'R' ) ){
		std::string::const_reverse_iterator b;
		for( b = inp.rbegin(); b != inp.rend() && limit2 != nRCount; ++b, nRCount++ ){
			if( charset2.find( *b ) == std::string::npos )
				break;
		}
	}
	size_t nChop = static_cast<size_t>( nCount + nRCount );
	assert( nChop <= inp.size() );
	if( nChop == inp.size() )
		return "";
	outp = inp.substr( nCount, inp.size() - nChop );
	return outp;
}
hxdw_IniData2 hxdw_ParseINIFile( const char* szIniFname )
{
	hxdw_IniData2 ini2;
	std::vector<std::string>::iterator a;
	std::vector<std::string> lines2;
	hxdw_GetTextLinesFromFile( szIniFname, &lines2 );
	for( a = lines2.begin(); a != lines2.end(); ++a ){
		*a = hxdw_TrimStr( *a, "\r\n\t\x20", "LR", -1 );
		if( !a->empty() ){
			if( (*a)[0] == '[' && ((*a).back() == ']') ){ //0x5B: bracket open.
				hxdw_IniSection el2;
				el2.first = a->substr( 1, a->size() - 2 );
				ini2.sections2.push_back( el2 );
			}else if( strchr("#;", (*a)[0] ) ){ //if comment
				// just ignore commented out line.
			}else{
				if( ini2.sections2.empty() )
					ini2.sections2.push_back( hxdw_IniSection() );
				std::vector<std::string> kval;
				hxdw_StrExplode( a->c_str(), kval, {'=',}, 1, "\r\n\t\x20" );
				kval.resize(2);
				if( kval[1].size() >= 2 ){ // then check for quotes strip.
					if( strchr("\x22\x27", kval[1][0] ) && kval[1][0] == kval[1].back() )
						kval[1] = kval[1].substr( 1, kval[1].size() - 2 );
				}
				ini2.sections2.back().second.push_back( { kval[0], kval[1],} );
			}
		}
	}
	return ini2;
}
bool hxdw_IniData2::
eachSection( std::function<bool( const hxdw_IniSection& )> calb2 )const
{
	hxdw_IniData3::const_iterator a;
	for( a = sections2.begin(); a != sections2.end(); ++a ){
		if( !calb2( *a ) )
			break;
	}
	return 1;
}
bool hxdw_IniData2::
eachVariable( const std::vector<std::string> sectnames, std::function<bool( const char* secname, const char* kname, const char* val2 )> calb3 )const
{
	bool rs2 = eachSection( [&]( const hxdw_IniSection& sec2 ){
		if( !sectnames.empty() ){
			auto b = std::find( sectnames.begin(), sectnames.end(), sec2.first );
			if( b == sectnames.end() )
				return 1;
		}
		for( const auto& aVar : sec2.second ){
			if( !calb3( sec2.first.c_str(), aVar.first.c_str(), aVar.second.c_str() ) ){
				return 0;
			}
		}
		return 1;
	});
	return rs2;
}
std::string hxdw_IniData2::getValue( const char* sec2, const char* kname2 )const
{
	std::string val2;
	eachVariable( {sec2,}, [&]( const char* secname, const char* kname3, const char* value2 ){
			if( !strcmp( kname2, kname3 ) ){
				val2 = value2;
				return 0;
			}
			return 1;
	});
	return val2;
}
int hxdw_StrCmpOpt( const char* a, const char* b, int num, const char* flags2 )
{
	bool bCi = !!strchr( flags2, 'i');
	for( ; *a && *b && num; ++a, ++b, --num ){
		if( *a != *b ){
			if(bCi){
				char ch2 = *a, ch3 = *b;
				ch2 = ( ch2 >= 'a' && ch2 <= 'z' ? (ch2 - ('a'-'A')) : ch2 );
				ch3 = ( ch3 >= 'a' && ch3 <= 'z' ? (ch3 - ('a'-'A')) : ch3 );
				if( ch2 != ch3 ){
					break;
				}
			}else{
				break;
			}
		}
	}
	return ( !num ? 0 : ( static_cast<int>( *a ) - static_cast<int>( *b ) ) );
	//return 0; // if input c-strings equal.
}
int hxdw_GetFileSize( const char* fname )
{
	FILE* fp2 = fopen( fname, "r" );
	if( fp2 ){
		fseek( fp2, 0, SEEK_END );
		int nEnd = (int)ftell( fp2 );
		fclose(fp2);
		return nEnd;
	}
	return 0;
}
std::vector<std::string>
hxdw_IniData2::getSectionsByNamePrefix( const char* szPrefix, const char* flags2 )const
{
	std::vector<std::string> outp;
	int len = strlen( szPrefix );
	if(!len)
		return outp;
	bool rs2 = eachSection( [&]( const hxdw_IniSection& sec2 ){
		if( !hxdw_StrCmpOpt( sec2.first.c_str(), szPrefix, len, "" ) ){
			outp.push_back( sec2.first );
		}
		return 1;
	});
	return outp;
}
/// Rerurns time ticks in microseconds.
/// 1,000,000 = 1 second.
uint64_t hxdw_GetTimeTicksUs()
{
	return hxdw_GetPosixTimeUs();
}
/// Returns POSIX time in microseconds.
/// Format is: POSIX time in microseconds, 1,000,000 = 1 second.
/// ref: https://stackoverflow.com/questions/4568221/c-get-system-time-to-microsecond-accuracy-on-windows
/// -    https://docs.microsoft.com/en-us/windows/desktop/sysinfo/acquiring-high-resolution-time-stamps
uint64_t hxdw_GetPosixTimeUs()
{
    FILETIME ft;
    GetSystemTimeAsFileTime( &ft );
    uint64_t tt = ft.dwHighDateTime; //unsigned long long
    tt <<= 32;
    tt |= ft.dwLowDateTime;
    tt /= 10;
    tt -= 11644473600000000ULL;
	return  tt;
}
uint64_t hxdw_GetTimeTicksMs()
{
	// Note that GetTickCount() is inacurate. Steps have
	// spikes at 32 milliseconds when probing every 16 milliseconds.
	return hxdw_GetTimeTicksUs() / 1000;
}
bool hxdw_SendKeyboardInput( const std::vector< std::pair<int,int> >& aKeys, const char* flags2 )
{
	bool bUp = !!strchr( flags2, 'u');
	std::vector<INPUT> iinputs2;
	for( const auto& a : aKeys ){
		INPUT in2;
		memset( &in2, 0, sizeof(in2) );
		in2.type       = INPUT_KEYBOARD;
		in2.ki.dwFlags = ( bUp ? KEYEVENTF_KEYUP : 0 );
		in2.ki.wVk     = a.first;
		in2.mi.dwExtraInfo = GetMessageExtraInfo();
		iinputs2.push_back(in2);
	}
	bool bOk = !!SendInput( iinputs2.size(), &iinputs2[0], sizeof(INPUT) );
	return bOk;
}
bool hxdw_SendMouseDeltaInput( std::pair<int,int> xyDelta )
{
	// UINT SendInput(UINT cInputs,LPINPUT pInputs,int cbSize);
	// https://docs.microsoft.com/en-us/windows/desktop/api/winuser/nf-winuser-sendinput
	INPUT in2;
	memset( &in2, 0, sizeof(in2) );
	in2.type       = INPUT_MOUSE;//INPUT_KEYBOARD
	in2.mi.dwFlags = MOUSEEVENTF_MOVE;//|MOUSEEVENTF_ABSOLUTE|0;
	in2.mi.time    = 0; //GetTickCount();
	in2.mi.dx      = xyDelta.first;
	in2.mi.dy      = xyDelta.second;
	in2.mi.dwExtraInfo = GetMessageExtraInfo();
	bool bOk = !!SendInput( 1, &in2, sizeof(INPUT) );
	return bOk;
}
/// Sends mouse buttons using SendInput() Winapi.
/// Each element of input 'aMButtons' must be set bo mouse button
/// flag, eg. MOUSEEVENTF_LEFTDOWN or MOUSEEVENTF_LEFTUP.
bool
hxdw_SendMouseButtonInput( const std::vector< std::pair<int,int> >& aMButtons )
{
	std::vector<INPUT> iinputs2;
	for( const auto& a : aMButtons ){
		/*auto b = std::find_if( mbtns.begin(), mbtns.end(),
				[&]( const std::pair< int, std::pair<int,int> >& b ){
						return a.first == b.first;
		});//*/
		int nMButtonFlag = a.first;
		INPUT in2;
		memset( &in2, 0, sizeof(in2) );
		in2.type           = INPUT_MOUSE;
		in2.mi.dwFlags     = nMButtonFlag;// eg. MOUSEEVENTF_MOVE
		in2.mi.time        = 0; //GetTickCount();
		in2.mi.dwExtraInfo = GetMessageExtraInfo();
		iinputs2.push_back( in2 );
	}
	bool bOk = !!SendInput( iinputs2.size(), &iinputs2[0], sizeof(INPUT) );
	return bOk;
}
/// Opens standard open file dialog box.
/// szDefaultFn - Optional. Initial file name path, or just directory.
/// szTitle     - Optional.
/// szExeFilter - Optional. File ext filter, if any. Eg. "*.EXE;*.DLL;*.BAT"
std::string hxdw_OpenFileNameWithUI( const char* szDefaultFn, const char* szTitle, const char* szExeFilter, HWND hwParent )
{
	std::string srInitDir;
	char bfr[1024*4] = "";
	char bfrExtFltr[256] = "";
	if( szExeFilter && *szExeFilter )
		sprintf_s( bfrExtFltr, sizeof(bfrExtFltr), "%s\0%s\0\0", szExeFilter, szExeFilter );
	if( szDefaultFn && *szDefaultFn ){
		if( hxdw_IsDir( szDefaultFn ) ){
			srInitDir = szDefaultFn;
		}else{
			auto dp2 = hxdw_SplitPath( szDefaultFn );
			srInitDir = dp2.first;
			sprintf_s( bfr, sizeof(bfr), "%s", dp2.second.c_str() );
		}
	}
	OPENFILENAME ofn;
	memset( &ofn, 0, sizeof(ofn) );
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.Flags       |= OFN_NOVALIDATE;          // prevent disabling of front slashes
	ofn.Flags       |= OFN_HIDEREADONLY;        // hide readonly flag
	ofn.Flags       |= OFN_EXPLORER;            // use 'newer' explorer windows
	ofn.Flags       |= OFN_ENABLESIZING;        // allow window to be resized
	ofn.Flags       |= OFN_NOCHANGEDIR;         // prevent dialog for messing up the cwd
	ofn.nMaxFile     = sizeof(bfr)-1;
	ofn.lpstrFile    = bfr;
	ofn.hwndOwner    = hwParent;//GetForegroundWindow();
	ofn.lpstrTitle   = szTitle;// "Open Executable File (XIEI)";
	ofn.lpstrFilter  = bfrExtFltr;
	ofn.lpstrInitialDir = srInitDir.c_str();
	if( GetOpenFileName( &ofn ) ){
		return bfr;
	}
	return "";
}
std::string hxdw_StrToLower( std::string inp )
{
	std::string::iterator a;
	for( a = inp.begin(); a != inp.end(); ++a ){
		if( *a >= 'A' && *a <= 'Z' ){
			*a += 'a' - 'A';
		}
	}
	return inp;
}
std::string hxdw_StrTruncate( std::string inp, int maxlen, const std::string dots2 )
{
	if( maxlen < (int)inp.size() ){
		inp.resize( maxlen );
		if( !dots2.empty() && inp.size() > dots2.size() ){
			inp = inp.substr( 0, inp.size() - dots2.size() );
			inp += dots2;
		}
	}
	return inp;
}
std::string hxdw_StrLTruncate( std::string inp, int maxlen, const std::string dots2 )
{
	if( maxlen < (int)inp.size() ){
		//inp.resize( maxlen );
		inp = inp.substr( inp.size() - maxlen );
		if( !dots2.empty() && inp.size() > dots2.size() ){
			inp = dots2 + inp.substr( dots2.size() );
		}
	}
	return inp;
}
std::string
hxdw_StrPrintf( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string outp;
	const char* sz2 = fmt, *sz3 = 0;
	char bfr[256];
	for( const auto& a : args4 ){
		if( !(sz3 = strchr( sz2, '%' )) )
			break;
		if( !strchr( "ads", sz3[1] ) )
			break;
		outp.append( sz2, sz3-sz2 );
		sz2 = sz3 + 2;
		std::string arg;
		if( a.bStr ){
			arg = a.srVal;
		}else{
			sprintf_s( bfr, sizeof(bfr), "%lld", a.nVal );
			arg = bfr;
		}
		outp += arg;
	}
	outp.append( sz2 );
	return outp;
}
/**
	Copies batch of files specified by input array.
	\param inp - list of pairs. for each, 'first' is full path to
	       source, existsing file, while 'second' is only base name for
	       new file.
	\param szDstDir - destination directory name.
*/
bool hxdw_CopyFilesToDir( const std::vector<std::pair<std::string,std::string> >& inp, const char* szDstDir, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	for( const auto& a : inp ){
		std::string bn2 = hxdw_SplitPath(a.first.c_str()).second;
		std::string bn3 = a.second;
		std::string newfname = hxdw_StrPrintf("%s\\%s", {{szDstDir,0,},{bn3.c_str(),0,},} );
		if( !CopyFile( a.first.c_str(), newfname.c_str(), 0 ) ){
			err3 = hxdw_StrPrintf("Can't copy file '%s'.", {{bn2.c_str(),0,},} );
			return 0;
		}
	}
	return 1;
}
/// Returns value from GetBinaryType().
/// Doesn't work with DLLs, only EXEs.
/// Eg: SCS_32BIT_BINARY - win32/x86
///     SCS_64BIT_BINARY - win64/x64
DWORD hxdw_GetBinaryType( const std::string srFname )
{
	DWORD eType = -1;
	if( !GetBinaryTypeA( srFname.c_str(), &eType ) )
		return -1;
	return eType;
}
bool hxdw_PutFileContents( const std::string filename, const char* data2, int nNumBytes )
{
	FILE* fp2 = fopen( filename.c_str(), "wb");
	if(!fp2)
		return 0;
	fwrite( data2, 1, nNumBytes, fp2 );
	fclose(fp2);
	fp2 = 0;
	return 1;
}
std::string
hxdw_PathJoin( const std::string& dir2, const std::string& basename2, const std::string& ext2 )
{
	std::string z;
	z = hxdw_StrPrintf("%s%s%s%s%s", {
				{ dir2,},
				{ (!dir2.empty() ? "\\" : ""),},
				{ basename2,},
				{ (!ext2.empty() ? "." : ""),},
				{ ext2,},
				});
	return z;
}
bool
hxdw_DeleteFilesWithRollback( const std::vector<std::string> filenames, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srTmstp;
	{
		uint64_t ts2 = ( hxdw_GetPosixTimeUs() / 1000 );
		char bfr[64];
		sprintf_s( bfr, sizeof(bfr), "%llu", ts2 );
		srTmstp = bfr;
	}
	std::vector<std::string> renamed2;
	for( const auto& fn2 : filenames ){
		auto dparts  = hxdw_SplitPath( fn2 );
		auto bparts  = hxdw_SplitExt( dparts.second );
		auto bn4     = hxdw_StrPrintf("%s_tmp%s", {{bparts.first,},{srTmstp,},} );
		auto frename = hxdw_PathJoin( dparts.first, bn4, bparts.second );
		if( hxdw_FileExists( frename.c_str() ) ){
			err3 = hxdw_StrPrintf("Cannot rename [%s] [3KxX2U]", {{frename,},} );
			return 0;
		}
		if( !MoveFile( fn2.c_str(), frename.c_str() ) ){
			err3 = hxdw_StrPrintf("Temporary move file failed [%s] [sO281M]", {{fn2,},} );
			return 0;
		}
		renamed2.push_back(frename);
	}
	for( const auto& fn2 : renamed2 ){
		if( !DeleteFile( fn2.c_str() ) ){
			err3 = hxdw_StrPrintf("Delete file failed [%s] [wxHg0o]", {{fn2,},} );
			return 0;
		}
	}
	return 1;
}
