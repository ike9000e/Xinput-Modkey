#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <functional>
#include <windows.h>

/// Adaptor for input vector element parameter for hxdw_StrPrintf().
struct HxdwPrintAdp {
	HxdwPrintAdp( const std::string& inp ) {srVal = inp; nVal = 0;}
	HxdwPrintAdp( int64_t inp ) {srVal = ""; nVal = inp; bStr = 0; }
	HxdwPrintAdp( const char* a, int64_t b ) {srVal = a; nVal = b; bStr = (a?1:0);}
private:
	std::string srVal;
	int64_t nVal;
	bool bStr = 1;
	friend std::string hxdw_StrPrintf( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
};

HWND        hxdw_FindWndByCaptionPart( const char* szNeedle, const char* flags2 );
bool        hxdw_SendDropFilesToWnd( HWND hwnd, const std::vector<std::string>& fnames );
bool        hxdw_GetDirFilesRcv( const char* szDir, std::vector<std::string>& fnames, const char* szFlags );
bool        hxdw_StrExplode( const char* inp, std::vector<std::string>& parts2, const std::vector<char> lsGlueItems, int nLimit = -1, const char* szTrimLR = 0 );
std::string hxdw_StrImplode( const std::vector<std::string>& parts2, const std::string glue2, const char* szTrimLR = 0 );
int         hxdw_FileExists( const char* fname );
auto        hxdw_SplitExt( std::string inp ) -> std::pair<std::string,std::string>;
auto        hxdw_SplitPath( std::string inp ) -> std::pair<std::string,std::string>;
std::string hxdw_PathJoin( const std::string& dir_, const std::string& basename_, const std::string& ext_ );
bool        hxdw_IsDir( const char* pathname );
std::string hxdw_GetTextFileContents( const char* fname );
bool        hxdw_PutFileContents( const std::string filename, const char* data2, int nNumBytes );
bool        hxdw_GetTextLinesFromFile( const char* fname, std::vector<std::string>* lines2 );
std::string hxdw_GetArgvByName( const std::vector<std::string> argnames2, int argc2, const char*const* argv2, const char* szFlags = "" );
std::string hxdw_TrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 );
int         hxdw_StrCmpOpt( const char* a, const char* b, int num = -1, const char* flags2 = "" );
int         hxdw_GetFileSize( const char* fname );
uint64_t    hxdw_GetTimeTicksUs();
uint64_t    hxdw_GetTimeTicksMs();
uint64_t    hxdw_GetPosixTimeUs();
bool        hxdw_SendKeyboardInput( const std::vector< std::pair<int,int> >& aKeys, const char* flags2 );
bool        hxdw_SendMouseDeltaInput( std::pair<int,int> xyDelta );
bool        hxdw_SendMouseButtonInput( const std::vector< std::pair<int,int> >& aMButtons );
std::string hxdw_OpenFileNameWithUI( const char* szDefaultFn, const char* szTitle, const char* szExeFilter, HWND hwParent );
std::string hxdw_StrToLower( std::string inp );
std::string hxdw_StrTruncate( std::string inp, int maxlen, const std::string dots2 = "..." );
std::string hxdw_StrLTruncate( std::string inp, int maxlen, const std::string dots2 = "..." );
//          hxdw_StrPrintf( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
bool        hxdw_CopyFilesToDir( const std::vector<std::pair<std::string,std::string> >& inp, const char* szDstDir, std::string* err2 );
DWORD       hxdw_GetBinaryType( const std::string srFname );
bool        hxdw_DeleteFilesWithRollback( const std::vector<std::string> filenames, std::string* err2 );

/// Used by hxdw_ParseINIFile().
using hxdw_IniSection = std::pair< std::string, std::vector<std::pair<std::string,std::string> > >;
using hxdw_IniData3 = std::vector< hxdw_IniSection >;
struct hxdw_IniData2{
	hxdw_IniData3 sections2;
	//findSection();
	bool eachSection( std::function<bool( const hxdw_IniSection& )> calb2 )const;
	bool eachVariable( const std::vector<std::string> sectnames, std::function<bool( const char* secname, const char* kname, const char* value2 )> calb2 )const;
	std::string getValue( const char* sec2, const char* kname )const;
	auto getSectionsByNamePrefix( const char* szPrefix, const char* flags2 = "" )const -> std::vector<std::string>;
};

hxdw_IniData2 hxdw_ParseINIFile( const char* szIniFname );
