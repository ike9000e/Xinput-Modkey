#include "xium_wnd.h"
#include "hxdw/hxdw_utils.h"
#include <assert.h>
#include "xium_installer.h"
#include <shellapi.h>  //ShellExecute()

const char* XiumMainWindow::AppName = "Xinput Modkey Manager";
const char* XiumMainWindow::CfgFileName = "./xium_config.ini";

XiumMainWindow::XiumMainWindow()
	: Fl_Window( 640, 480, XiumMainWindow::AppName )
{
	fl_message_hotspot( 0 );
	fl_message_title_default( AppName ); //Fl_Widget* fl_message_icon();
	assert( !wInstBrsr && !wInstExe );
	int whTabs[] = { 640-20,430-20, };//320
    Fl_Tabs *tabs = new Fl_Tabs(10,10, whTabs[0], whTabs[1] );
	{
		Fl_Group *aaa = new Fl_Group(10,35, whTabs[0], whTabs[1], "Manager");
		{
			int yyy = 64;
			setptr2( new Fl_Browser( 32, yyy, 256, 320, "" ), &wInstBrsr );
			setptr2( new Fl_Button( 256+32+64*0+11, yyy, 64, 24, "Add"), &wInstAdd );
			setptr2( new Fl_Button( 256+32+64*1+11, yyy, 64, 24, "Install"), &wInstIns );
			setptr2( new Fl_Button( 256+32+64*2+11, yyy, 64, 24, "Uninstall"), &wInstUnins );
			setptr2( new Fl_Button( 256+32+64*3+11, yyy, 64, 24, ">"), &wInstMnu );
			setptr2( new Fl_Check_Button( 256+32+64*0+11, yyy+=24+4, 192, 18, "Auto install on Add"), &wAutoInst );
			setptr2( new Fl_Check_Button( 256+32+64*0+11, yyy+=24, 192, 18, "Auto Remove INI on Uninstall"), &wAutoIniRmv );
			yyy += 24;
			setptr2( new Fl_Box( 256+32+11, yyy+=24, 256, 20, "" ), &wNameLbl );
			setptr2( new Fl_Input( 256+32+11, yyy+=24, 256, 24, "" ), &wInstExe );
			setptr2( new Fl_Input( 256+32+11, yyy+=24+4, 256, 24, "" ), &wInstFiles );
			setptr2( new Fl_Button( 256+32+11,     yyy+=24+8, 128, 24, "Open INI"), &wOpenIni );
			setptr2( new Fl_Button( 256+32+11+128, yyy,       128, 24, "Copy INI Path"), &wCpIniPath );
			aaa->end();

			wAutoInst->deactivate();

			wInstExe->readonly(1);
			wInstExe->color( FL_BACKGROUND_COLOR );
			wInstFiles->readonly(1);
			wInstFiles->color( FL_BACKGROUND_COLOR );

			wNameLbl->box(FL_FLAT_BOX);
			wNameLbl->labelcolor( FL_BACKGROUND2_COLOR );
			wNameLbl->color( FL_SELECTION_COLOR );
			//
			wInstAdd->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onButtonAdd();
			}, this );
			wInstMnu->deactivate();
			wInstMnu->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onButtonInstMenu();
			}, this );
			wInstBrsr->type( FL_HOLD_BROWSER );
			wInstBrsr->format_char( 0 );
			wInstBrsr->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->genericBrowserUpdate(-1);
			}, this );
			wInstIns->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onButtonInstall();
			}, this );
			wInstUnins->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onButtonUninstall();
			}, this );
			wOpenIni->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onActionInstOpenIni();
			}, this );
			wCpIniPath->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onActionInstCpIniPath();
			}, this );
			wInstIns->deactivate();
			wInstUnins->deactivate();
		}
		Fl_Group *bbb = new Fl_Group(10,35, whTabs[0], whTabs[1], "Hotkeys");
		bbb->end();
		Fl_Group *ccc = new Fl_Group(10,35, whTabs[0], whTabs[1], "Routines");
		ccc->end();
		Fl_Group *ddd = new Fl_Group(10,35, whTabs[0], whTabs[1], "Maintenance");
		{
			setptr2( new Fl_Button( 50,60+24*0+0,   128,24,"Save Settings"), &wSaveStn );
			setptr2( new Fl_Button( 50,60+24*1+8*1, 128,24,"Load Settings"), &wLoadStn );
			setptr2( new Fl_Button( 50,60+24*2+8*2, 128,24,"Exit, No Save"), &wExitNoSave );
			wSaveStn->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onButtonSaveSettings();
			}, this );
			wLoadStn->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->onButtonLoadSettings();
			}, this );
			wExitNoSave->callback( []( Fl_Widget*, void* thi ){
					((XiumMainWindow*)thi)->bExitNoSave = 1;
					((XiumMainWindow*)thi)->hide();
			}, this );
		}
	}
	begin();
	{
		setptr2( new Fl_Button( 10, whTabs[1]+24, 64, 24, "Exit"), &wExitBtn );
		wExitBtn->callback( []( Fl_Widget*, void* thi ){
				((XiumMainWindow*)thi)->hide();
		}, this );
	}
	tabs->end();
	onButtonLoadSettings();
}
int XiumMainWindow::handle( int evt )
{
	if( evt == FL_HIDE ){ // if window is closing|destroying.
		//printf("FL_HIDE %d.\n", (int)bExitNoSave );
		if( !bExitNoSave ){
			onButtonSaveSettings();
		}
	}
	return Fl_Window::handle( evt );
}
void XiumMainWindow::addInstallation( const std::string srExecPath )
{
	std::string str, bn2 = hxdw_SplitPath( srExecPath.c_str() ).second;
	std::vector<SInst>::iterator a;
	assert(wInstBrsr);
	a = std::find_if( Instls.begin(), Instls.end(), [&]( const SInst& a )->bool{
			if( !lstrcmpi( a.srExec.c_str(), srExecPath.c_str() ) )
				return 1;
			return 0;
	});
	if( a != Instls.end() ){
		fl_alert("ERROR: Installation for '%s' already exists.", bn2.c_str() );
		return;
	}
	SInst sii;
	sii.srExec = srExecPath;
	sii.ident2 = LastInstId++;
	sii.srName = bn2;
	addInstallation2( sii, 1 );
}
void XiumMainWindow::addInstallation2( const SInst& sii, bool bSelect )
{
	wInstBrsr->add( sii.srName.c_str(), reinterpret_cast<void*>( static_cast<size_t>( sii.ident2 )));
	Instls.push_back( sii );
	int ln2 = findBrowserLineById( sii.ident2 );
	if( ln2 != -1 && ln2 ){
		//if(bSelect)
		//	wInstBrsr->select( ln2 );
		genericBrowserUpdate( (bSelect ? ln2 : -1) );
	}
}
void XiumMainWindow::onButtonAdd()
{
	std::string str;
	HWND hwParent = GetForegroundWindow();
	if( !(str = hxdw_OpenFileNameWithUI( LastInstDir.c_str(), "Select", "*", hwParent )).empty() ){
		LastInstDir = hxdw_SplitPath( str.c_str() ).first;
		addInstallation( str );
	}
}
void XiumMainWindow::genericBrowserUpdate( int nLastLineSel )
{
	assert( wInstBrsr );
	if( nLastLineSel != -1 && nLastLineSel ){
		nLastLineSel = ( std::min<int>( wInstBrsr->size(), nLastLineSel ) );
		if( nLastLineSel != -1 && nLastLineSel )
			wInstBrsr->select( nLastLineSel );
	}
	int sel = wInstBrsr->value();
	if( sel ){
		int id2 = static_cast<int>( reinterpret_cast<size_t>( wInstBrsr->data( sel)));
		auto a = std::find_if( Instls.begin(), Instls.end(), [&]( const SInst& a )->bool{
				return a.ident2 == id2;
		});
		assert( a != Instls.end() );
		onBrowserSelChanged( *a );
	}else{
		onBrowserSelChanged( SInst() );
	}
}
void XiumMainWindow::onBrowserSelChanged( const SInst inp )
{
	assert( wInstExe && wInstIns );
	{
		std::string srFiles;
		for( auto a : inp.files2 )
			srFiles += ( !srFiles.empty() ? "; " + a : a );
		wInstExe->value( inp.srExec.c_str() );
		wInstFiles->value( srFiles.c_str() );
		wNameLbl->copy_label( inp.srName.c_str() );
	}
	bool bNoSel = !wInstBrsr->value();
	if( bNoSel ){
		wInstIns->deactivate();
		wInstUnins->deactivate();
		wInstMnu->deactivate();
	}else{
		if( inp.bInstalled ){
			wInstIns->deactivate();
			wInstUnins->activate();
		}else{
			wInstUnins->deactivate();
			wInstIns->activate();
		}
		wInstMnu->activate();
	}
}
/// Returns -1 if not found, or value greater than 0 on success.
int XiumMainWindow::findBrowserLineById( int id2 )const
{
	const int num = wInstBrsr->size();
	for( int i=0; i<num; i++ ){
		// line is 1-based in Fl_Browser::data(int line_).
		int id3 = static_cast<int>( reinterpret_cast<size_t>( wInstBrsr->data( i+1 ) ) );
		if( id2 == id3 )
			return i+1;
	}
	return -1;
}
XiumMainWindow::SInst*
XiumMainWindow::findBrowserItemById( int id2 )
{
	std::vector<SInst>::iterator a;
	a = std::find_if( Instls.begin(), Instls.end(), [&]( const SInst& a )->bool{
			return id2 == a.ident2;
	});
	if( a == Instls.end() )
		return 0;
	return &*a;
}
int XiumMainWindow::getCurrentInstallationId()const
{
	int id2 = static_cast<int>( reinterpret_cast<size_t>( wInstBrsr->data( wInstBrsr->value() ) ));
	return id2;
}
XiumMainWindow::SInst* XiumMainWindow::getCurrentInstallation()
{
	int id2; SInst* inst;
	if( (id2 = getCurrentInstallationId()) ){
		inst = findBrowserItemById( id2 );
		assert( inst );
		return inst;
	}
	return 0;
}
void XiumMainWindow::onButtonUninstall()
{
	assert(wAutoIniRmv);
	SInst* inst;
	if( (inst = getCurrentInstallation()) ){
		if( inst->bInstalled ){
			uint32_t hwParent = static_cast<uint32_t>(reinterpret_cast<size_t>(GetForegroundWindow()));
			bool bOk = 0;
			bOk = xium_UninstallDLLsForBinary( inst->srExec, ".\\assets_0cll75yg",
								hwParent, inst->files2, (wAutoIniRmv->value()?"i":"") );
			if( bOk ){
				inst->bInstalled = 0;
				inst->files2.clear();
				genericBrowserUpdate(-1);
			}
			return;
		}else{
			fl_alert("Not installed.");
		}
	}else{
		fl_alert("No selection.");
	}
}
void XiumMainWindow::onButtonSaveSettings()const
{
	std::string data2; int i=0;
	std::vector<std::pair<std::string,std::string> > lines2;
	std::vector<SInst>::const_iterator a;

	const SInst* inst2 = ((XiumMainWindow*)this)->getCurrentInstallation();
	assert( inst2 );
	int idCurr = ( inst2 ? inst2->ident2 : 0 );

	lines2.push_back( {"[s_global]","",} );
	lines2.push_back( {"bAutoInstall",(wAutoInst->value()?"1":"0"),} );
	lines2.push_back( {"bAutoIniRmv",(wAutoIniRmv->value()?"1":"0"),} );
	lines2.push_back( {"szLastInstDir", LastInstDir.c_str(),} );
	lines2.push_back( {"","",} );

	for( a = Instls.begin(); a != Instls.end(); ++a, i++ ){
		lines2.push_back( { hxdw_StrPrintf("[s_installation:%d]", {{i,},} ), "",} );
		lines2.push_back( {"szIName", a->srName.c_str(),} );
		lines2.push_back( {"szBinary", a->srExec.c_str(),} );
		lines2.push_back( {"bInstalled", (a->bInstalled ? "1" : "0"),} );
		if( a->ident2 == idCurr ){
			lines2.push_back( {"bISelected", "1",} );
		}
		lines2.push_back( {"szIFiles", hxdw_StrImplode( a->files2, "**", "\r\n\t\x20" ),} );
		lines2.push_back( {"","",} );
	}//*/
	size_t uVarnameMax = 0;
	for( const auto& a : lines2 ){
		if( !a.first.empty() && a.first[0] != '\x5B' ){  //0x5B = bracket open.
			uVarnameMax = std::max<size_t>( a.first.size(), uVarnameMax );
		}
	}
	for( const auto& a : lines2 ){
		if( !a.first.empty() && a.first[0] == '\x5B' ){  //0x5B = bracket open.
			data2 += a.first + "\r\n";
		}else if( a.first.empty() ){
			data2 += "\r\n";
		}else{
			assert( uVarnameMax >= a.first.size() );
			std::string varname = a.first, value2 = a.second;
			varname.resize( uVarnameMax, ' ' );
			if( strchr( value2.c_str(), ' ' ) )
				value2 = "\x22" + value2 + "\x22";
			data2 += hxdw_StrPrintf("%s = %s\r\n", { {varname.c_str(),0,}, {value2.c_str(),0,}, } );
		}
	}
	FILE* fp2 = fopen( CfgFileName, "wb");
	if(!fp2){
		fl_alert("File open failed. Settings not saved.");
		return;
	}
	fwrite( &data2[0], 1, data2.size(), fp2 );
	fclose(fp2);
	fp2 = 0;//*/
}
void XiumMainWindow::onButtonLoadSettings()
{
	assert( wInstBrsr && wAutoInst );
	Instls.clear();
	wInstBrsr->clear();
	//
	hxdw_IniData2 ini2 = hxdw_ParseINIFile( CfgFileName );
	std::string str;
	std::vector<std::string> secs;
	int idCurr2 = 0;
	secs = ini2.getSectionsByNamePrefix( "s_installation", "" );
	for( const auto& a : secs ){
		SInst si2;
		si2.ident2     = LastInstId++;
		si2.srName     = ini2.getValue( a.c_str(), "szIName" );
		si2.srExec     = ini2.getValue( a.c_str(), "szBinary" );
		si2.bInstalled = !!atoi( ini2.getValue( a.c_str(), "bInstalled").c_str() );
		bool bISelected = atoi( ini2.getValue( a.c_str(), "bISelected" ).c_str() );
		{
			str = ini2.getValue( a.c_str(), "szIFiles");
			std::vector<std::string> parts3;
			hxdw_StrExplode( str.c_str(), parts3, {'*',}, -1, "\r\n\t\x20" );
			parts3.erase( std::remove_if( parts3.begin(), parts3.end(), []( const std::string& b ){
					return b.empty();
			} ), parts3.end() );
			si2.files2 = parts3;
		}
		idCurr2 = ( bISelected ? si2.ident2 : idCurr2 );
		addInstallation2( si2, ( bISelected ? 1 : 0 ) );
	}
	bool bAutoInstall = !!atoi( ini2.getValue("s_global", "bAutoInstall").c_str() );
	wAutoInst->value( bAutoInstall );
	bool bAutoIniRmv = !!atoi( ini2.getValue("s_global", "bAutoIniRmv").c_str() );
	wAutoIniRmv->value( bAutoIniRmv );
}
void XiumMainWindow::onButtonInstMenu()
{
	Fl_Menu_Item rclick_menu[] = {
		//{"Duplicate",  0, []( Fl_Widget* this2, void* user3 )->void{
		//				((XiumMainWindow*)this2)->onActionInstDuplicate();
		//		}, (void*)0, },
		{"Remove",  0, []( Fl_Widget* this2, void* user3 )->void{
						((XiumMainWindow*)this2)->onActionInstRmv();
				}, (void*)0, },

		{"Rename",  0, []( Fl_Widget* this2, void* user3 )->void{
						((XiumMainWindow*)this2)->onActionInstRename();
				}, (void*)0, },
		{0,},
	};
	int xy2[] = { wInstMnu->x(), wInstMnu->y() + wInstMnu->h(), };
	const Fl_Menu_Item* m = rclick_menu->popup( xy2[0], xy2[1], 0, 0, 0 );
	if( m ){
		m->do_callback( this, m->user_data() );
	}
}
std::vector<XiumMainWindow::SInst>::iterator
XiumMainWindow::getCurrentInstallation2( int* nLineOu )
{
	SInst* inst = getCurrentInstallation();
	if( inst ){
		std::vector<SInst>::iterator a;
		a = std::find_if( Instls.begin(), Instls.end(), [&]( const SInst& a ){
				return inst->ident2 == a.ident2;
		});
		assert( a != Instls.end() );
		int nLine = findBrowserLineById( a->ident2 );
		assert( nLine && nLine != -1 );
		if(nLineOu)
			*nLineOu = nLine;
		return a;
	}
	return Instls.end();
}

void XiumMainWindow::onActionInstRmv()
{
	int nLine = -1;
	auto a = getCurrentInstallation2( &nLine );
	if( a != Instls.end() ){
		if( fl_ask("Remove '%s'?", a->srName.c_str() ) ){
			wInstBrsr->remove( nLine );
			Instls.erase(a);
			genericBrowserUpdate( nLine );
		}
	}
}
void XiumMainWindow::onActionInstDuplicate()
{
	auto a = getCurrentInstallation2( 0 );
	if( a == Instls.end() ){
		return;
	}
	std::string str, srConf2;
	if( !a->bInstalled ){
		fl_alert("This configuration is not installed.\n"
					"Only installed configurations can be duplicated.");
		return;
	}
	srConf2 = hxdw_StrPrintf("%s/xinput_dll_forwarder.ini",
				{{hxdw_SplitPath( a->srExec.c_str() ).first.c_str(),0,},} );
	if( !hxdw_FileExists( srConf2.c_str() ) ){
		fl_alert("Configuration INI file not found. Cannot continue.\n"
					"[%s]\n", srConf2.c_str() );
		return;
	}
	HWND hwParent = GetForegroundWindow();
	if( !(str = hxdw_OpenFileNameWithUI( LastInstDir.c_str(), "Select", "*", hwParent )).empty() ){
		LastInstDir = hxdw_SplitPath( str.c_str() ).first;
		;
		//SInst si2( *a );
		//si2.ident2 = LastInstId++;
		//si2.srExec = str;
		//si2.srName = hxdw_SplitPath( str.c_str() ).second;
		//si2.bInstalled = 0;
		//addInstallation2( si2, 1 );
	}
}
void XiumMainWindow::onButtonInstall()
{
	SInst* inst;
	if( !(inst = getCurrentInstallation()) || inst->bInstalled ){
		fl_alert("No selection or bad operation.");
		return;
	}
	assert( hxdw_FileExists(inst->srExec.c_str()) );
	assert( inst->files2.empty() );
	std::string srAssetsDir = ".\\assets_0cll75yg";
	HWND hwParent = GetForegroundWindow();
	std::vector<std::string> aDlls;
	uint32_t hwnd2 = static_cast<uint32_t>(reinterpret_cast<size_t>(hwParent));
	bool bOk = xium_InstallDLLsForBinary( inst->srExec.c_str(), srAssetsDir.c_str(), hwnd2, aDlls );
	if( !bOk )
		return;
	inst->bInstalled = 1;
	inst->files2     = aDlls;
	genericBrowserUpdate(-1);
}
void XiumMainWindow::onActionInstRename()
{
	SInst* inst2 = getCurrentInstallation();
	if( !inst2 )
		return;
	const char* sz2;
	if( ( sz2 = fl_input("%s", inst2->srName.c_str(), "Rename:") )){
		//std::vector<SInst> Instls
		auto a = std::find_if( Instls.begin(), Instls.end(), [&]( const SInst& a )->bool{
				return a.srName == sz2;
		});
		if( a != Instls.end() ){
			fl_alert("Same name already exists. Cannot rename.");
			return;
		}
		inst2->srName = sz2;
		int nLine;
		if( -1 != ( nLine = findBrowserLineById( inst2->ident2 ) ) ){
			wInstBrsr->text( nLine, inst2->srName.c_str() );
		}
		genericBrowserUpdate(-1);
	}
}
void XiumMainWindow::onActionInstOpenIni()
{
	SInst* inst3 = getCurrentInstallation();
	if( !inst3 ){
		fl_alert("Couldn't copy path.");
		return;
	}
	std::string str = hxdw_StrPrintf("%s\\xinput_modkey.ini",
				{{hxdw_SplitPath( inst3->srExec ).first,},} );
	if( hxdw_FileExists( str.c_str() ) ){
		ShellExecute( 0, "open", str.c_str(), "", "", SW_SHOWDEFAULT );
	}
}
void XiumMainWindow::onActionInstCpIniPath()
{
	SInst* inst3 = getCurrentInstallation();
	if( !inst3 ){
		fl_alert("Couldn't copy path.");
		return;
	}
	std::string str = hxdw_StrPrintf("%s\\xinput_modkey.ini",
				{{hxdw_SplitPath( inst3->srExec ).first,},} );
	Fl::copy( str.c_str(), str.size(), 1 );
}






