#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <string>
#include <vector>
#include <FL/fl_draw.H>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Slider.H>
#include <FL/Fl_Menu_Window.H>
#include <FL/Fl_Tooltip.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Browser.H>
#include <FL/Fl_Check_Button.H>
#include <FL/fl_ask.H>
#include <FL/Fl_Menu.H>
#include <FL/Fl_Box.H>

class XiumMainWindow : public Fl_Window
{
	struct SInst;
public:
	XiumMainWindow();
	virtual ~XiumMainWindow() {}
	virtual int handle( int evt );
private:
	void onBrowserSelChanged( const SInst inp );
	void onButtonAdd();
	void onButtonInstall();
	void onButtonUninstall();
	void onButtonInstMenu();
	void onActionInstRmv();
	void onActionInstDuplicate();
	void onButtonSaveSettings()const;
	void onButtonLoadSettings();
	void onActionInstRename();
	void onActionInstOpenIni();
	void onActionInstCpIniPath();
	void addInstallation( const std::string inp );
	void addInstallation2( const SInst& inp, bool bSelect );
	void genericBrowserUpdate( int nLineSelOrLast = -1 );
	int  findBrowserLineById( int id2 )const;
	auto findBrowserItemById( int id2 ) -> SInst*;
	int  getCurrentInstallationId()const;
	auto getCurrentInstallation() -> SInst*;
	auto getCurrentInstallation2( int* nLineOu = 0 ) -> std::vector<SInst>::iterator;
	template<class T> static void setptr2( T* inp, T** outp ){ *outp = inp; }
	struct SInst{
		int                      ident2 = 0;
		std::string              srExec, srName, srConf;
		bool                     bInstalled = 0;
		std::vector<std::string> files2;
	};
	static const char* AppName;
	static const char* CfgFileName;
	Fl_Browser*        wInstBrsr = 0;
	Fl_Input*          wInstExe = 0, *wInstFiles = 0;
	Fl_Button*         wInstAdd = 0, *wInstMnu = 0, *wInstIns = 0, *wInstUnins = 0;
	Fl_Button*         wSaveStn = 0, *wLoadStn = 0, *wExitNoSave = 0, *wExitBtn = 0;
	Fl_Button*         wOpenIni = 0, *wCpIniPath = 0;
	Fl_Check_Button*   wAutoInst = 0, *wAutoIniRmv = 0;
	Fl_Box*            wNameLbl = 0;
	std::vector<SInst> Instls;
	int                LastInstId = 1001;
	std::string        LastInstDir;
	bool               bExitNoSave = 0;
};
