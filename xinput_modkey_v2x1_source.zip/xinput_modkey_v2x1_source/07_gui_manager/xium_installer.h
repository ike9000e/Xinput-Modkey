#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <string>
#include <vector>

bool        xium_GetXinputDllNameForPEIfAny( const char* szPEPath, const char* szAssetsDir, std::string* srDllNameOu, std::string* err2 );
bool        xium_EexecProcess( const char* szCmd, const std::vector<std::string>& argv2, bool bWait, int* nExitCode );
bool        xium_GetPEExportsAnyArch( const char* pathname, const char* szAssetsDir2, std::vector<std::string>& exports3, bool* bX64Arch );
bool        xium_IsDLLXinputModkeyFilter2( const char* pathname, bool, const char* szAssetsDir2 );
bool        xium_IsDLLXinputModkeyForwarder2( const char* pathname, const char* szAssetsDir2 );
bool        xium_GetPEFileImportDLLNames( const char* szPEPath, const char* szAssetsDir3, std::vector<std::string>& imports2, std::string* err2 );
bool        xium_InstallDLLsForBinary( const char* szBinFname, const char* szAssetsDir, uint32_t hwnd, std::vector<std::string>& aDllNames );
bool        xium_UninstallDLLsForBinary( const std::string& srBinFname,
							const char* szAssetsDir, uint32_t hwnd2,
							const std::vector<std::string> aDllNames, const char* flags2 );
