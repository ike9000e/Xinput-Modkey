#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <windows.h>
#include "detours.h"
#include "hxdw/hxdw_utils.h"

bool        xiei_GetPEFileImports( const char* szFname, std::vector<std::string>& outp, std::string* err2 );
bool        xiei_GetPEExports( const char* pathname, std::vector<std::string>& outp );
bool        xiei_GeXinputDllNameForrPE( const char* szPEPath, std::string* srDllNameOu, std::string* err2 );

//xiei_StrPrintf -> hxdw_StrPrintf()
//std::string xiei_StrPrintf( const char* fmt, std::vector<std::pair<const char*,int64_t> > args3 );

bool        xiei_IsDLLXinputModkeyForwarder( const char* pathname );
bool        xiei_IsDLLXinputModkeyFilter( const char* pathname );
bool        xiei_CopyFilesToDir( const std::vector<std::string> inp, const char* szDstDir, std::string* err2 );
