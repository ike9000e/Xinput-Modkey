#include "xidf_shared_symbol.h"

/// This is only for the dummy symbol name exporting; to make it
/// available for when attaching to processes, editing imprt table
/// in PEs, etc.
int xidf_dll_dummy()
{
	return 49775;
}
