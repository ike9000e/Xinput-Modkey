#include "xidf_init.h"
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include "detours.h"
#include <process.h>   //_getpid()
#include <assert.h>
#include <algorithm>
#include <list>
#include <mmsystem.h>   //PlaySound()
#include "xidf_functions.h"
#include "xidf_resource.h"
DWORD (WINAPI*  ori_XInputGetState)( DWORD dwUserIndex,XINPUT_STATE *pState ) = XInputGetState;

/*
	typedef struct _XINPUT_STATE {
	  DWORD          dwPacketNumber;
	  XINPUT_GAMEPAD Gamepad;
	} XINPUT_STATE, *PXINPUT_STATE;
	typedef struct _XINPUT_GAMEPAD {
	  WORD  wButtons;
	  BYTE  bLeftTrigger;
	  BYTE  bRightTrigger;
	  SHORT sThumbLX;
	  SHORT sThumbLY;
	  SHORT sThumbRX;
	  SHORT sThumbRY;
	} XINPUT_GAMEPAD, *PXINPUT_GAMEPAD;
*/

bool xidf_InitGlobalData( void* hInstance )
{
	HINSTANCE hInstance2 = (HINSTANCE) hInstance;

	char bfr2[MAX_PATH] = ""; std::string str, err2;
	if( !XidfData->bNoLogFile ){
		const char* sz2; std::string srTmpDir;
		std::list<std::string> aTmps2 = {"%TEMP%","%TMP%",};
		*bfr2 = 0;
		GetSystemDirectory( bfr2, sizeof(bfr2) );
		if( bfr2[0] && bfr2[1] == ':' ){
			bfr2[1] = '\0';
			aTmps2.push_front( hxdw_StrPrintf("%s:\\temp", {{bfr2,},} ) ); // yields fe. "C:\\Temp".
		}
		for( const auto& a : aTmps2 ){
			if( a[0] == '%' ){
				str = hxdw_TrimStr( a, "%", "LR", -1 );
				if( (sz2 = getenv( str.c_str() )) ){
					if( hxdw_IsDir( sz2 ) ){
						srTmpDir = sz2;
						break;
					}
				}
			}else if( hxdw_IsDir( a.c_str() ) ){
				srTmpDir = a.c_str();
				break;
			}
		}
		if( !srTmpDir.empty() ){
			//sprintf_s( bfr2, sizeof(bfr2), "%s\\xinput_modkey.log", srTmpDir.c_str() );
			snprintf( bfr2, sizeof(bfr2), "%s\\xinput_modkey.log", srTmpDir.c_str() );
			XidfData->srLogFile = bfr2;
			printf("XIDF: Log file: [%s]\n", XidfData->srLogFile.c_str() );
			if( (128*1024) < hxdw_GetFileSize( XidfData->srLogFile.c_str() ) ){
				DeleteFile( XidfData->srLogFile.c_str() );
			}
		}
	}
	GetModuleFileName( hInstance2, bfr2, sizeof(bfr2) );
	XidfData->srDllPath = bfr2;

	if( !XidfData->srLogFile.empty() ){ //XidfData->bNoLogFile
		snprintf( bfr2, sizeof(bfr2), "%s Starting from [%s]",
				xidf_GetLocalTimeStr().c_str(), XidfData->srDllPath.c_str() );
		xidf_LogMessage( "", bfr2 );
		//
		GetModuleFileName( 0, bfr2, sizeof(bfr2)-1 );
		std::string srExec = bfr2;
		snprintf( bfr2, sizeof(bfr2), "Executable name [%s]", srExec.c_str() );
		xidf_LogMessage( "", bfr2 );
	}
	std::pair<std::string,std::string> dp2;
	dp2 = hxdw_SplitPath( XidfData->srDllPath.c_str() );
	XidfData->srCfgFname = dp2.first + "\\" + hxdw_SplitExt( dp2.second.c_str() ).first + ".ini";

	snprintf( bfr2, sizeof(bfr2), "XIDF: Config path: [%s]", XidfData->srCfgFname.c_str() );
	printf("%s\n", bfr2 );
	xidf_LogMessage("", bfr2 );

	if( !hxdw_FileExists( XidfData->srCfgFname.c_str() ) ){
		printf("XIDF: ERROR: configuration file not found.\n");
		return 0L;
	}
	hxdw_IniData2 ini2 = hxdw_ParseINIFile( XidfData->srCfgFname.c_str() );
	//MessageBox(0, ini2.getAsString().c_str(), "Cfg", 0);
	if( !xidf_ReinitConfiguration( ini2 ) ){
		return 0L;
	}
	return 1L;
}

/// Replacer for Xinput own XInputGetState() Winapi function.
DWORD WINAPI xidf_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pState )
{
	XINPUT_STATE& sta = *pState;
	XINPUT_GAMEPAD& gpd = sta.Gamepad;
	DWORD rs2 = ori_XInputGetState( dwUserIndex, &sta );
//	if( XidfData->bEnforceAPIDeadzones ){
//		xidf_EnforceAPIDeadZones( gpd, XidfData->bADZReinterpolate );
//	}
	//assert( XidfData );
	//MessageBox(0,"a","b",0);

	if( XidfData && XidfData->bInited ){

		Xidf_Perform prf( *pState, dwUserIndex );
		xidf_PerformModkeys( prf );

		//if( sta.dwPacketNumber ){
		//}
		static bool bOnce = 0;
		if( !bOnce ){
			bOnce = 1;
			if( !XidfData->bNoStartupSnd ){
				CreateThread( 0,0, []( void* )->DWORD{
						PlaySound( MAKEINTRESOURCE( XIDF_WAVE_DLL_STARTUP ),
										XidfData->hInst2, SND_RESOURCE );
						return 0;
				}, 0, 0, 0 );
			}
		}
	}
	return rs2;
}

/**
	Per-process initialization.
	F.e. called durning DllMain.
	Deinit is done via xidf_DeinitForProcess().
*/
bool xidf_InitForProcess( void* hInstance )
{
	assert( !XidfData );
	HINSTANCE hInstance2 = reinterpret_cast<HINSTANCE>( hInstance );
	if( !hInstance2 ){
		//hInstance2 = GetModuleHandle( 0 );
		GetModuleHandleExA( GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
					(LPCSTR)(&XidfData), &hInstance2 );
		assert(hInstance2);
	}
	char bfr2[256];
	XidfData = new XidfGlobals;
	printf("XIDF: Starting DLL\n");
	XidfData->hInst2 = hInstance2;

	//PlaySound( TEXT("SystemStart"), 0, SND_ALIAS );
	//PlaySound( (LPCTSTR)SND_ALIAS_SYSTEMSTART, NULL, SND_ALIAS_ID );
	// The following example plays a sound-file resource:
	// PlaySound( MAKEINTRESOURCE(IDR_WAVE1),
	//     GetModuleHandle(0),
	//     SND_RESOURCE);

	//printf("XIDF: dll path: [%s]\n", XidfData->srDllPath.c_str() );
	xidf_InitGlobalData( hInstance2 );

	DetourTransactionBegin();
	DetourUpdateThread( GetCurrentThread() );
	{
		if( XidfData->srXiDllFName.empty() ){
			assert(!"Empty configuration variable [s_main].szXinputDllName is unexpected.");
		}
		//MessageBox(0,"ERR", XidfData->srXiDllFName.c_str(), 0);
		if( XidfData->srXiDllFName == "eDAuto" ){
			//assert(!"eDAuto");
			XidfData->srXiDllFName = "";
			// Enumerate DLLs in the PE executable.
			for( HMODULE hDll3 = 0; (hDll3 = DetourEnumerateModules(hDll3)); ){
				std::string str;
				char szName[MAX_PATH] = {0,};
				GetModuleFileNameA(hDll3, szName, sizeof(szName) - 1);
				str = hxdw_SplitPath( szName ).second;
				// Below: matches successfully with: "XINPUT9_1_0.dll", "Xinput1_3.dll", etc.
				if( !hxdw_StrCmpOpt( "xinput", str.c_str(), 0x0006, "i" ) ){
					if( strchr( "19", str[0x0006] ) ){
						XidfData->srXiDllFName = str;
						//printf("DLL: [%s]\n", str.c_str() );
						break;
					}
				}
			}
		}
		snprintf( bfr2, sizeof(bfr2), "Using Xinput DLL [%s]", XidfData->srXiDllFName.c_str() );
		printf("XIDF: %s\n", bfr2 );
		xidf_LogMessage("", bfr2 );
		if( XidfData->srXiDllFName.empty() ){
			assert(!"XIDF: Couldn't find valid Xinput DLL module name.");
		}
		XidfData->hXiDll = LoadLibrary( XidfData->srXiDllFName.c_str() );
		assert( XidfData->hXiDll );
		ori_XInputGetState = (XInputGetState_t*) GetProcAddress(
					XidfData->hXiDll, "XInputGetState" );
		assert( ori_XInputGetState );
		DetourAttach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
	}
	DetourTransactionCommit();

	if( XidfData->sXiRd.bXiEnabled ){
		XidfXiReader::xireaderInit();
	}
	return 1;
}
void xidf_DeinitForProcess()
{
	assert( XidfData );
	xidf_LogMessage("", "DLL_PROCESS_DETACH");
	DetourTransactionBegin();
	DetourUpdateThread( GetCurrentThread() );
	DetourDetach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
	DetourTransactionCommit();
	//
	if( XidfData->sXiRd.bXiEnabled ){
		XidfXiReader::xireaderDeinit();
	}
	if( XidfData->hXiDll ){
		FreeLibrary( XidfData->hXiDll );
		XidfData->hXiDll = 0;
	}
	delete XidfData;
	XidfData = 0;
}
const char* xidf_GetCurrentConfigFileName()
{
	assert( XidfData );
	return XidfData->srCfgFname.c_str();
}
bool xidf_ReinitConfiguration( const hxdw_IniData2& ini2, std::string* err3 )
{
	std::string str;
	std::string dmy0, &err2 = ( err3 ? *err3 : dmy0 );
	assert(XidfData);
	XidfData->resetCfg();

	XidfData->bEnforceAPIDeadzones = !!atoi( ini2.getValue( "s_main", "bEnforceAPIDeadzones" ).c_str() );
	XidfData->bADZReinterpolate = !!atoi( ini2.getValue( "s_main", "bADZReinterpolate" ).c_str() );
	XidfData->nGamepadIndex = !!atoi( ini2.getValue( "s_main", "nGamepadIndex" ).c_str() );
	XidfData->bKeysUseWM = !!atoi( ini2.getValue( "s_main", "bKeysUseWM" ).c_str() );
	XidfData->bKeysUseSC = !!atoi( ini2.getValue( "s_main", "bKeysUseSC" ).c_str() );
	XidfData->bNoStartupSnd = !!atoi( ini2.getValue( "s_main", "bNoStartupSnd" ).c_str() );

	XidfData->bNoLogFile = !!atoi( ini2.getValue( "s_main", "bNoLogFile" ).c_str() );
	XidfData->srXiDllFName = ini2.getValue("s_main", "szXinputDllName" ).c_str();
	XidfData->srGlobalSuppress = ini2.getValue("s_main", "szGlobalSuppress" ).c_str();
	XidfData->sXiRd.bXiEnabled = !!atoi( ini2.getValue( "s_internal_xinput", "bXiEnabled" ).c_str() );
	XidfData->sXiRd.fSleepIntervalMs = atof( ini2.getValue( "s_internal_xinput", "fSleepIntervalMs" ).c_str() );

	XidfData->nInitDelayMs = atoi( ini2.getValue( "s_main", "nInitDelayMs" ).c_str() );
	XidfData->bShowStartupMBox = !!atoi( ini2.getValue( "s_main", "bShowStartupMBox" ).c_str() );

	//system("notepad.exe");
	//
	if( XidfData->bShowStartupMBox ){
		MessageBox( 0, "Initializing...\n""Press OK.", XIDF_NAME_XINPUT_MODK, 0 );
	}
	if( XidfData->nInitDelayMs ){
		Sleep( XidfData->nInitDelayMs );
	}
	//
	if( !(str = XidfData->srGlobalSuppress.c_str() ).empty() ){
		if( !xidf_ActionsToArray( str.c_str(), ',', XidfData->aGlobSuppr, &err2 ) ){
			printf("XIDF: ERROR: %s\n", err2.c_str() );
			xidf_LogMessage("ERROR", err2.c_str() );
			return 0;
		}
	}
	float fff = static_cast<float>( XidfData->sXiRd.fSleepIntervalMs );
	XidfData->sXiRd.fSleepIntervalMs = ( fff ? fff : XidfData->sXiRd.fSleepIntervalMs );
	//
	if( !xidf_ParseModkeys2( ini2, XidfData->modkeys3, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		xidf_LogMessage("ERROR", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfData->modkeys3 ){
		XidfData->aModsDown.push_back( Xidf_ModkeyDown( &a ) );
	}
	if( !xidf_ParseTrInputs( ini2, XidfData->trInputs, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		xidf_LogMessage("ERROR", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfData->trInputs ){
		XidfData->aTrInputLive.push_back( Xidf_TrInputLive( &a ) );
	}

	if( !xidf_ParseRoutines( ini2, XidfData->routines2, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		xidf_LogMessage("ERROR", err2.c_str() );
		//MessageBox(0, err2.c_str(), "XIDF", 0);
		return 0;
	}
	for( const auto& a : XidfData->routines2 ){
		XidfData->aRoutinesLive.push_back( Xidf_RoutineLive( &a ) );
	}
	XidfData->bInited = 1;
	return 1;
}

