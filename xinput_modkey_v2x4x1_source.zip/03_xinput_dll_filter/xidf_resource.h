
#define XIDF_WAVE_DLL_STARTUP 1001

#define XIDF_NAME_XINPUT_MODK "Xinput Modkey - Filter DLL"

