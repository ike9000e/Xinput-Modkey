#include "xidf_dll_main.h"
#include <assert.h>
#include "xidf_init.h"

BOOL WINAPI DllMain( HINSTANCE hInst, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:
		//_set_error_mode( _OUT_TO_MSGBOX );
		//assert(000);
		//MessageBox(0,"a","b",0);

		hxdw_CreateThreadSimple( [=]()->uint32_t{
			xidf_InitForProcess( hInst );
			return 0;
		}, 0 );//5000
		break;
	case DLL_PROCESS_DETACH:
		xidf_DeinitForProcess();
		break;
	}
	return 1L;
}

