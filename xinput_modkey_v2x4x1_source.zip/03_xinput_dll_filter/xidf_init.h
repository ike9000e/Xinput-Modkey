#pragma once
#include <string>
#include <windows.h>
#include <xinput.h>

struct hxdw_IniData2;
using XInputGetState_t = DWORD __stdcall( DWORD dwUserIndex,XINPUT_STATE *pState );

bool xidf_InitForProcess( void* hInstance ); //HINSTANCE
void xidf_DeinitForProcess();
bool xidf_InitGlobalData( void* hInstance ); //HINSTANCE
bool xidf_ReinitConfiguration( const hxdw_IniData2& ini3, std::string* err2 = 0 );
auto xidf_GetCurrentConfigFileName() -> const char*;
DWORD WINAPI xidf_XInputGetState( DWORD dwUserIndex,XINPUT_STATE *pState );
