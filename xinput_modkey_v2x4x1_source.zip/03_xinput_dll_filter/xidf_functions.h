#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <string>
#include <windows.h>
#include <commdlg.h>
#include <xinput.h>
#include "hxdw/hxdw_utils.h"

enum{
	Xidf_TI_MouseMove = 3001, //"eMouseMotion"
	Xidf_TI_KbdArrows,
	//
	Xidf_IP_Linear = 4001, //interpolation linear.
	Xidf_IP_Exp,
};

enum{
	Xidf_Act_START = 1001, Xidf_Act_BACK,
	Xidf_Act_A, Xidf_Act_B, Xidf_Act_X, Xidf_Act_Y,
	Xidf_Act_LT, Xidf_Act_RT,
	Xidf_Act_UP, Xidf_Act_DOWN, Xidf_Act_LEFT, Xidf_Act_RIGHT,
	Xidf_Act_LS, Xidf_Act_RS,
	Xidf_Act_LSXAdd,
	Xidf_Act_LSXSub,
	Xidf_Act_LSYAdd,
	Xidf_Act_LSYSub,
	Xidf_Act_RSXAdd,
	Xidf_Act_RSXSub,
	Xidf_Act_RSYAdd,
	Xidf_Act_RSYSub,
	Xidf_Act_LTr, Xidf_Act_RTr,
};
struct Xidf_Trigger{
	int ident4;
	std::vector<int> modkeyIds;   // modkey identifiers of Xidf_Modkey.
	std::vector<int> buttons2;    // eg. Xidf_Act_START
	std::vector<std::pair<size_t,bool> > order2;   // <index,bModkey>
};
const int Xidf_MaxStickPos = 32767;
const int Xidf_MaxTriggerPos = 255;

struct Xidf_Modkey{
	int               ident3 = 0;
	int               btnActivator = 0;  //eg. Xidf_Act_START
	int               btnBitIfAny = 0;   //eg. XINPUT_GAMEPAD_A
	int               threshold2 = 0;    //max=32767; eg. 7001. only for analog inputs (eg. Xidf_Act_LSXAdd).
	int               limit2 = -1;
	int               timeout2 = 0;
	std::string       rename2;
	bool              bMDisabled = 0, bSuppress = 0;
};
struct Xidf_ModkeyDown{
	const Xidf_Modkey*  mod2;
	bool                bDown2 = 0;
	Xidf_ModkeyDown( const Xidf_Modkey* mod2_ ) : mod2(mod2_) {}
	static Xidf_ModkeyDown* findModkey( int ident, Xidf_ModkeyDown* inp, size_t num );
};
enum{
	Xidf_IT_Gamepad = 201,
	Xidf_IT_Key,
	Xidf_IT_MouseButton,
};
enum{
	Xidf_SM_Hold = 1,
	Xidf_SM_Autorepeat,
};
struct Xidf_Input{
	int type2  = 0;  // eg. Xidf_IT_Gamepad
	int input2 = 0;  // eg. Xidf_Act_START, virtual-key-code, or mouse-button.
	Xidf_Input( int type2_, int input2_ ) : type2(type2_), input2(input2_) {}
};
struct Xidf_SendKey{
	int ident6 = 0;
	int nVk = 0, nIntrvl = 16, nMouseBtn = 0;
	Xidf_SendKey( int nVk_, int ident_ ) : nVk(nVk_), ident6(ident_) {}
};
struct Xidf_AutoRepeat{
	uint64_t uTmDown, uTmUp;
	//std::vector<Xidf_SimStep> aSimStepIntrvls;
	Xidf_AutoRepeat( uint64_t uTmDown_=0, uint64_t uTmUp_=0 ) : uTmDown(uTmDown_), uTmUp(uTmUp_) {}
};
struct Xidf_ScaleActions {
	float            fScale = 0.0f;
	char             cType = '=';  // eg. '*', '=' or '+'.
	std::vector<int> aActions;
};

struct Xidf_Routine{
	int                       eSimMode = Xidf_SM_Hold;
	Xidf_Trigger              trigger2;
	std::vector<int>          aSuppress;   //eg. Xidf_Act_START
	std::vector<Xidf_Input>   aHold2;
	bool                      bRDisabled = 0, bHExclusive = 0;
	std::vector<Xidf_SendKey> aSendVk;
	Xidf_AutoRepeat           turbo2;  //szAutoRepeat = 32,32
//	std::pair<float,std::vector<int>> fRRescale = { 0.0f, {0,},};
	Xidf_ScaleActions         fRescaleThese = { 0.0f, '=', {}, }; // eg. {Xidf_Act_START,}.
	//
	float getRescaleAtIfAny( int nIndex )const;
	bool isGamepadButtonLiveSimulated( int eAction )const;
};
struct Xidf_RoutineLive{
	const Xidf_Routine*                   routine2 = 0;
	bool                                  bLive = 0;
	std::vector<std::pair<int,uint64_t> > aSendksLive;  //<id,start-at>
	std::pair<uint64_t,bool>              aTurboBtnLive;  //<init-at,not-used>
	Xidf_RoutineLive( const Xidf_Routine* action2_ ) : routine2(action2_) {}
};
/// The Translate input structure.
struct Xidf_TrInput{
	int               ident5 = 0;
	int               eOutputTy = 0;  // output type, eg. Xidf_TI_MouseMove
//	int               eIntrplTy = 0;  // interpolation type, eg. Xidf_IP_Linear.
//	float             fInterpolateFac = 1.0f;
	int               nMovementPerSec = 512;
//	float             fAccelFac = 1.f;
	Xidf_Trigger      trigger4;
	std::vector<int>  inputs2;        //eg. Xidf_Act_START
//	std::vector<int>  accelerators2;  //eg. Xidf_Act_START
};
struct Xidf_TrInputLive{
	const Xidf_TrInput*       trInput2 = 0;
	std::pair<bool,uint64_t>  bLive3 = {0,0,};  // <is-live,timestamp>
	std::vector<double>       aDeltaAccum = { 0.0, 0.0,};
	Xidf_TrInputLive( const Xidf_TrInput* tr2_ ) : trInput2(tr2_) {}
};
struct Xidf_Perform{
	DWORD            dwUserIndex2;  //Index of the user's controller. Can be a value from 0 to 3.
	XINPUT_STATE&    xistate;
	Xidf_Perform( XINPUT_STATE& xistate_, DWORD dwUserIndex2_ ) : xistate(xistate_), dwUserIndex2(dwUserIndex2_) {}
};
/// Used by XidfInternalXi::eScrapMode.
enum{
	Xidf_P2_Thread = 1,
	Xidf_P2_TranslateMsgApi,
};
/// Structure for internally enabled Xinput.
/// I.e. if application does not use Xinput, this can be used to generate
/// keyboard keys or simulate mouse. Note that this cannot be used to simulate
/// gamepad if the application is using, for example, DInput.
/// Do not use this if application is already using Xinput.
/// \sa XidfXiReader
struct XidfInternalXi{  // [s_internal_xinput]
	bool    bXiEnabled = 0, bRunThr = 1;
	int     eScrapMode = Xidf_P2_Thread;//0;   //eg. Xidf_P2_Thread
	double  fSleepIntervalMs = 16.666;
	HANDLE  hScrapThr = 0;
};

/// Configuration part of the XidfGlobals structure, DTO intended.
struct XidfCfg {
	virtual          ~XidfCfg() {}
	virtual void     resetCfg() final;
	//
	bool                          bEnforceAPIDeadzones = 0, bADZReinterpolate = 0;
	bool                          bKeysUseWM = 0, bKeysUseSC = 0;
	std::vector<Xidf_Modkey>      modkeys3;
	std::vector<Xidf_Routine>     routines2;
	std::vector<Xidf_TrInput>     trInputs;
	int                           nLastModkId = 2001, nLastTriggerId = 3001;
	int                           nLastTr2Id = 4001, nLastSendkId = 5001;
	std::vector<Xidf_ModkeyDown>  aModsDown;
	std::vector<Xidf_RoutineLive> aRoutinesLive;
	std::vector<Xidf_TrInputLive> aTrInputLive;
	int                           nGamepadIndex = 0;
	std::vector<int>              aGlobSuppr;
	std::string                   srGlobalSuppress;
	uint32_t                      nInitDelayMs = 0;
	bool                          bShowStartupMBox = 0L;
};

struct XidfGlobals : XidfCfg {
	std::string                   srDllPath, srCfgFname, srLogFile;
	std::string                   srXiDllFName = "eDAuto"; // eg. "eDAuto","Xinput1_3.dll"
	bool                          bInited = 0, bCLIOnly = 0, bNoLogFile = 0;
	bool                          bNoStartupSnd = 0;
	HINSTANCE                     hInst2 = 0, hXiDll = 0;
	XidfInternalXi                sXiRd;
};
extern XidfGlobals* XidfData;

void xidf_MsgBoxIf( HWND hwnd, const char* msg, const char* flags2 = "" );
auto xidf_EnforceAPIDeadZones( const XINPUT_GAMEPAD& gp2, bool bReinterpolate ) -> XINPUT_GAMEPAD;
bool xidf_ParseModkeys2( const hxdw_IniData2& ini3, std::vector<Xidf_Modkey>& modkeysOu, std::string* err2 );
//bool xidf_ParseOneModkey( const char* inp, Xidf_Modkey& outp, int nNr, std::string* err2 );
bool xidf_ParseRoutines( const hxdw_IniData2& ini3, std::vector<Xidf_Routine>& actionsOu, std::string* err2 );
bool xidf_ParseTrInputs( const hxdw_IniData2& ini3, std::vector<Xidf_TrInput>& actionsOu, std::string* err2 );
bool xidf_ParseTriggerSequence( const char* inp, Xidf_Trigger& outp, std::string* err2, const char* flags2 );
auto xidf_FindModkeyById( int ident_ ) -> Xidf_Modkey*;
bool xidf_ActionsToArray( const char* szBtnNames, char glue2, std::vector<int>& outp, std::string* err2 );
bool xidf_IsGamepadStickAction( int eAction );
bool xidf_IsGamepadTriggerAction( int eAction );
int  xidf_ActionToBitIfAny( int eBtn );
bool xidf_TestActionDown( int eBtn2, int threshold3, const XINPUT_GAMEPAD& gpd );
auto xidf_GetInputValueForAction( int eBtn2, const XINPUT_GAMEPAD& gpd ) -> std::pair<int,float>;
bool xidf_IsActionDown( int eBtn, const XINPUT_GAMEPAD& gpd, const std::pair<int,int> aRangeFloorCeil );
int  xidf_GetThresholdForActionIfAny( int eBtn );
bool xidf_PerformModkeys( Xidf_Perform& inp );
bool xidf_PerformTrInputLive( Xidf_TrInputLive& trInpLv, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_PerformCleanup();
void xidf_RoutineLivePerform( Xidf_RoutineLive& actn2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_RoutineLivePerformAutorepeat( Xidf_RoutineLive& rtne5, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_RoutineLiveOnDown( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_RoutineLiveOnUp( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 );
void xidf_SetGamepadValueInt( int eAction, int nNewValue, XINPUT_GAMEPAD& gpd2 );
void xidf_SetGamepadValueFl( int eAction, float fNewValue, XINPUT_GAMEPAD& gpd2 );
int  xidf_FindModkeyByName( const char* modkname, const std::vector<Xidf_Modkey>& modkeys_ );
bool xidf_IsRtneTriggerDown( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd, std::vector<int>* aPerTrgrDn2 );
int  xidf_Reinterpolate( int val, int deadzone2, int nMaxPosition );
int  xidf_ApplyDeadZoneIfNeeded( int val, int deadzone2, int nMaxPosition );
void xidf_FgsSquareToDisc( double x, double y, double& xo, double& yo );
int  xidf_GetMouseFlags( int nMButton, const char* flags2 );
int  xidf_StrToTrInputMode( const char* inp );
bool xidf_StrToInputList( const char* szBtnNames, char glue2, std::vector<Xidf_Input>& outp, std::string* err2 );
int  xidf_StrToLimit( const char* inp, int eAct );
int  xidf_StrToGamepadAction( const char* inp );
int  xidf_StrToKeyAction( const char* inp );
auto xidf_GetValuesForRtneTrigger( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd2 ) -> std::vector<std::pair<int,float> >;
auto xidf_GetFirstValueForRtneTrigger( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd ) -> std::pair<int,float>;
auto xidf_GetLocalTimeStr() -> std::string;
void xidf_LogMessage( const char* szLabel, const char* szMsg );
auto xidf_GetButtonActionNames( char delim2 = ',' ) -> std::string;
auto xidf_GetKeyboardKeyNames( char delim2, int flags3 ) -> std::string;
auto xidf_GetModkeyNames( char delim2 = ',' ) -> std::string;

int  xidf_ClampInt( int inp, int loww, int highh );

/**
	Xinput Reader homogenous class for functionality
	in a game/program that do not use Xinput at all.
	I.e. extra thread is created that periodically reads
	Xinput state and, in turn, if Xinput Modkey is configured, generates keyboard input.
	This cannot be used to generate gamepad input, only keys or mouse.
*/
class XidfXiReader {
public:
	static bool xireaderInit();
	static bool xireaderPerform();
	static bool xireaderDeinit();
};
enum{
	/// Flags used by xidf_GetKeyboardKeyNames().
	Xidf_KT_KeyNamesLong = 0x2,
	Xidf_KT_KeyNamesAZ = 0x4,
	Xidf_KT_KeyNames0To9 = 0x8,
	Xidf_KT_KeyNames09Numpad = 0x10,
	Xidf_KT_KeyNamesF1F2Etc = 0x20,
	Xidf_KT_MouseButtonNames = 0x40,
};





