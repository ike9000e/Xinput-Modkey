#define DETOURS_ARM_OFFLINE_LIBRARY
#include "disasm.cpp"
