// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <windows.h>
#include <stdio.h>
#include <string>
#include <vector>
#include "xidf_shared_symbol.h"

/*
	XInput1_4.dll exports
	--------------------------
	00000001	00001220	0000	000094D6	DllMain
	00000002	000016B0	0001	00009548	XInputGetState
	00000003	00001950	0002	00009557	XInputSetState
	00000004	00001C10	0003	0000951F	XInputGetCapabilities
	00000005	00001D50	0004	000094DE	XInputEnable
	00000007	00002010	0006	00009503	XInputGetBatteryInformation
	00000008	000027C0	0007	00009535	XInputGetKeystroke
	0000000A	00002490	0009	000094EB	XInputGetAudioDeviceIds
	00000064	00001820	N/A	N/A	N/A
	00000065	00002240	N/A	N/A	N/A
	00000066	00002390	N/A	N/A	N/A
	00000067	00001E00	N/A	N/A	N/A
	00000068	00001EF0	N/A	N/A	N/A
	0000006C	00001A80	N/A	N/A	N/A
//*/
//#pragma comment(linker, "/export:SomeFunc=DllWork.SomeFunc")

/*
usage: DUMPBIN [options] [files]
   options:
      /ALL
      /ARCHIVEMEMBERS
      /CLRHEADER
      /DEPENDENTS
      /DIRECTIVES
      /DISASM[:{BYTES|NOBYTES}]
      /ERRORREPORT:{NONE|PROMPT|QUEUE|SEND}
      /EXPORTS
      /FPO
      /HEADERS
      /IMPORTS[:filename]
      /LINENUMBERS
      /LINKERMEMBER[:{1|2}]
      /LOADCONFIG
      /NOLOGO
      /OUT:filename
      /PDATA
      /PDBPATH[:VERBOSE]
      /RANGE:vaMin[,vaMax]
      /RAWDATA[:{NONE|1|2|4|8}[,#]]
      /RELOCATIONS
      /SECTION:name
      /SUMMARY
      /SYMBOLS
      /TLS
      /UNWINDINFO
*/
/*
Dump of file .\XInput9_1_0_win7.dll
  Section contains the following exports for XINPUT9_1_0.dll
    ordinal hint RVA      name
          1    0 00001790 DllMain
          2    1 00001F50 XInputGetCapabilities
          3    2 000021E0 XInputGetDSoundAudioDeviceGuids
          4    3 00001B30 XInputGetState
          5    4 00001D40 XInputSetState
//*/
/*
Dump of file .\xinput1_3_win7.dll
  Section contains the following exports for XINPUT1_3.dll
    ordinal hint RVA      name

          1    0 00002780 DllMain
          5    1 00003190 XInputEnable
          7    2 00003380 XInputGetBatteryInformation
          4    3 00002F60 XInputGetCapabilities
          6    4 00003AD0 XInputGetDSoundAudioDeviceGuids
          8    5 00003E30 XInputGetKeystroke
          2    6 00002980 XInputGetState
          3    7 00002DB0 XInputSetState
        100      00002C00 [NONAME]
        101      00003730 [NONAME]
        102      000039A0 [NONAME]
        103      00003250 [NONAME]
//*/
enum{
	XIFW_XV_Unknown = 0,
	XIFW_XV_v1x0 = 1,   // corresponds to file name: "xinput9_1_0.dll".
	XIFW_XV_v1x1,
	XIFW_XV_v1x2,
	XIFW_XV_v1x3,
	XIFW_XV_v1x4,
};

std::string xifw_GetTargetDllNameFromSelf( HINSTANCE hInst );
auto        xifw_SplitPath( std::string inp ) -> std::pair<std::string,std::string>;
int         xifw_GetXinputVersionFromSelf( const char* szDllName );
bool        xifw_InitOnDllInit( HINSTANCE hInst );

// Dummy structures only to pass for dummy function signatures.
struct XINPUT_STATE {};
struct XINPUT_VIBRATION {};
struct XINPUT_CAPABILITIES {};
struct XINPUT_BATTERY_INFORMATION {};
using PXINPUT_KEYSTROKE = void*;

// XInputGetState()
using XInputGetState_t = DWORD __stdcall( DWORD dwUserIndex,XINPUT_STATE *pState );
DWORD (WINAPI*  ori_XInputGetState)( DWORD dwUserIndex,XINPUT_STATE *pState ) = 0;
DWORD WINAPI    XInputGetState( DWORD dwUserIndex,XINPUT_STATE *pState );
//XInputSetState()
using XInputSetState_t = DWORD __stdcall( DWORD dwUserIndex, XINPUT_VIBRATION *pVibration );
DWORD (WINAPI*  ori_XInputSetState)( DWORD dwUserIndex, XINPUT_VIBRATION *pVibration ) = 0;
DWORD WINAPI    XInputSetState( DWORD dwUserIndex, XINPUT_VIBRATION *pVibration );
//XInputGetCapabilities()
using XInputGetCapabilities_t = DWORD __stdcall( DWORD dwUserIndex, DWORD dwFlags, XINPUT_CAPABILITIES *pCapabilities );
DWORD (WINAPI*  ori_XInputGetCapabilities)( DWORD dwUserIndex, DWORD dwFlags, XINPUT_CAPABILITIES *pCapabilities ) = 0;
DWORD WINAPI    XInputGetCapabilities( DWORD dwUserIndex, DWORD dwFlags, XINPUT_CAPABILITIES *pCapabilities );
//XInputGetDSoundAudioDeviceGuids()
using XInputGetDSoundAudioDeviceGuids_t = DWORD __stdcall( DWORD dwUserIndex, GUID *pDSoundRenderGuid, GUID *pDSoundCaptureGuid );
DWORD (WINAPI*  ori_XInputGetDSoundAudioDeviceGuids)( DWORD dwUserIndex, GUID *pDSoundRenderGuid, GUID *pDSoundCaptureGuid ) = 0;
DWORD WINAPI    XInputGetDSoundAudioDeviceGuids( DWORD dwUserIndex, GUID *pDSoundRenderGuid, GUID *pDSoundCaptureGuid );

//XInputEnable()
using XInputEnable_t = void __stdcall( BOOL enable );
void (WINAPI*  ori_XInputEnable)( BOOL enable ) = 0;
void WINAPI    XInputEnable( BOOL enable );
//XInputGetBatteryInformation()
using XInputGetBatteryInformation_t = DWORD __stdcall( DWORD dwUserIndex, BYTE devType, XINPUT_BATTERY_INFORMATION* pBatteryInformation );
DWORD (WINAPI*  ori_XInputGetBatteryInformation)( DWORD dwUserIndex, BYTE devType, XINPUT_BATTERY_INFORMATION* pBatteryInformation ) = 0;
DWORD WINAPI    XInputGetBatteryInformation( DWORD dwUserIndex, BYTE devType, XINPUT_BATTERY_INFORMATION* pBatteryInformation );
//XInputGetKeystroke()
using XInputGetKeystroke_t = DWORD __stdcall( DWORD dwUserIndex, DWORD dwReserved, PXINPUT_KEYSTROKE pKeystroke );
DWORD (WINAPI*  ori_XInputGetKeystroke)( DWORD dwUserIndex, DWORD dwReserved, PXINPUT_KEYSTROKE pKeystroke ) = 0;
DWORD WINAPI    XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, PXINPUT_KEYSTROKE pKeystroke );
//XInputGetAudioDeviceIds()
using XInputGetAudioDeviceIds_t = DWORD __stdcall( DWORD dwUserIndex, LPWSTR pRenderDeviceId, UINT* pRenderCount, LPWSTR pCaptureDeviceId, UINT* pCaptureCount );
DWORD (WINAPI*  ori_XInputGetAudioDeviceIds)( DWORD dwUserIndex, LPWSTR pRenderDeviceId, UINT* pRenderCount, LPWSTR pCaptureDeviceId, UINT* pCaptureCount ) = 0;
DWORD WINAPI    XInputGetAudioDeviceIds( DWORD dwUserIndex, LPWSTR pRenderDeviceId, UINT* pRenderCount, LPWSTR pCaptureDeviceId, UINT* pCaptureCount );
