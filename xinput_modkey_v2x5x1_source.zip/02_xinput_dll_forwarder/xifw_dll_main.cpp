#include "xifw_dll_main.h"
#include <assert.h>
#include <process.h>   //_getpid()
#include <algorithm>
#include "hxdw_utils.h"

static bool bDummyGlobal = 0;
HINSTANCE hDll2 = 0;

bool xifw_InitOnDllInit( HINSTANCE hInst )
{
	char bfr[256];
	snprintf( bfr, sizeof(bfr), "XIFW: New process (pid:%d)", _getpid() );
	printf("%s\n", bfr );
	//
	std::string srDllFnm = xifw_GetTargetDllNameFromSelf( hInst );
	hDll2 = LoadLibrary( srDllFnm.c_str() );
	assert( hDll2 );

	int eMdlVer = xifw_GetXinputVersionFromSelf( srDllFnm.c_str() );
	assert( eMdlVer != XIFW_XV_Unknown );

	ori_XInputGetState = (XInputGetState_t*) GetProcAddress( hDll2, "XInputGetState" );
	assert( ori_XInputGetState );

	ori_XInputSetState = (XInputSetState_t*) GetProcAddress( hDll2, "XInputSetState" );
	assert( ori_XInputSetState );

	ori_XInputGetCapabilities = (XInputGetCapabilities_t*) GetProcAddress( hDll2, "XInputGetCapabilities" );
	assert( ori_XInputGetCapabilities );

	ori_XInputGetDSoundAudioDeviceGuids = (XInputGetDSoundAudioDeviceGuids_t*) GetProcAddress( hDll2, "XInputGetDSoundAudioDeviceGuids" );
	assert( ori_XInputGetDSoundAudioDeviceGuids );

	if( eMdlVer >= XIFW_XV_v1x1 ){ // also XIFW_XV_v1x2
		ori_XInputEnable = (XInputEnable_t*) GetProcAddress( hDll2, "XInputEnable" );
		assert( ori_XInputEnable );
	}
	if( eMdlVer >= XIFW_XV_v1x3 ){
		ori_XInputGetBatteryInformation = (XInputGetBatteryInformation_t*) GetProcAddress( hDll2, "XInputGetBatteryInformation" );
		assert( ori_XInputGetBatteryInformation );

		ori_XInputGetKeystroke = (XInputGetKeystroke_t*) GetProcAddress( hDll2, "XInputGetKeystroke" );
		assert( ori_XInputGetKeystroke );
	}
	if( eMdlVer >= XIFW_XV_v1x4 ){
		ori_XInputGetAudioDeviceIds = (XInputGetAudioDeviceIds_t*) GetProcAddress( hDll2, "XInputGetAudioDeviceIds" );
		assert( ori_XInputGetAudioDeviceIds );
	}

	return 1L;
}
BOOL WINAPI DllMain( HINSTANCE hInst, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			if( bDummyGlobal ){ // this condition is meant to be always false.
				xidf_dll_dummy(); // just a call that ensures symbol and its module gets compiled in.
			}
			xifw_InitOnDllInit( hInst );
		/*	hxdw_CreateThreadSimple(
				[=]()->uint32_t{
					xifw_InitOnDllInit( hInst );
					return 0;
			}, 0 );//*/
		}
		break;
	case DLL_PROCESS_DETACH:
		if( hDll2 ){
			FreeLibrary(hDll2);
			hDll2 = 0;
		}
		break;
	}
	return 1;
}
std::vector<std::pair<std::string,int> > Xifw_XiVerNames = {
	{"xinput9_1_0.dll", XIFW_XV_v1x0, },
	{"xinput1_1.dll",   XIFW_XV_v1x1, },
	{"xinput1_2.dll",   XIFW_XV_v1x2, },
	{"xinput1_3.dll",   XIFW_XV_v1x3, },
	{"xinput1_4.dll",   XIFW_XV_v1x4, },
};

/// This is only for the dummy symbol name exporting; to make it
/// available for when patching some executables.
int xifw_dll_dummy()
{
	return 49775;
}
DWORD WINAPI XInputGetState( DWORD dwUserIndex,XINPUT_STATE *pState )
{
	return ori_XInputGetState( dwUserIndex, pState );
}
DWORD WINAPI XInputSetState( DWORD dwUserIndex, XINPUT_VIBRATION *pVibration )
{
	return ori_XInputSetState( dwUserIndex, pVibration );
}
DWORD WINAPI XInputGetCapabilities( DWORD dwUserIndex, DWORD dwFlags, XINPUT_CAPABILITIES *pCapabilities )
{
	return ori_XInputGetCapabilities( dwUserIndex, dwFlags, pCapabilities );
}
DWORD WINAPI XInputGetDSoundAudioDeviceGuids( DWORD dwUserIndex, GUID *pDSoundRenderGuid, GUID *pDSoundCaptureGuid )
{
	return ori_XInputGetDSoundAudioDeviceGuids( dwUserIndex, pDSoundRenderGuid, pDSoundCaptureGuid );
}
/// Given input path name splits it into dirname and basename pair.
/// Eg. "c:/temp/a.txt" ---> "c:/temp" and "a.txt".
/// Eg. "./data/x.txt"  ---> "./data"  and "x.txt".
/// Eg. "b.txt"         ---> ""        and "b.txt".
std::pair<std::string,std::string> xifw_SplitPath( std::string inp2 )
{
	const char* inp = inp2.c_str();
	const char* sz2 = strrchr( inp, '/' );
	const char* sz3 = strrchr( inp, '\\' );
	if( (sz2 = std::max<const char*>( sz2, sz3 )) ){
		std::string dirname2( inp, sz2-inp );
		return { dirname2, &sz2[1] };
	}
	return {"", inp,};//*/
}
/// Uses GetSystemDirectory() and returns path to the DLL file with same name as
/// the module specified by 'hInst' in the system directory.
/// Returns for example: "c:\\windows\\system32\\xinput1_3.dll"
std::string xifw_GetTargetDllNameFromSelf( HINSTANCE hInst )
{
	char bfrSd[MAX_PATH], bfrDllFnm[MAX_PATH], bfrSelfFnm[MAX_PATH];
	bool rs2 = !!GetSystemDirectory( bfrSd, sizeof(bfrSd) );
	assert( rs2 && *bfrSd );
	rs2 = GetModuleFileName( hInst, bfrSelfFnm, sizeof(bfrSelfFnm) );
	assert( rs2 && *bfrSelfFnm );
	std::string srSelfBasename = xifw_SplitPath( bfrSelfFnm ).second;
	snprintf( bfrDllFnm, sizeof(bfrDllFnm), "%s/%s", bfrSd, srSelfBasename.c_str() );
	return bfrDllFnm;
}
/// Returns fe. XIFW_XV_v1x3 given "xinput1_3.dll" as input.
int xifw_GetXinputVersionFromSelf( const char* szDllName )
{
	std::string basename2 = xifw_SplitPath( szDllName ).second;
	for( const auto& a : Xifw_XiVerNames ){
		if( !lstrcmpi( basename2.c_str(), a.first.c_str() ) ){
			return a.second;
		}
	}
	if( basename2.size() >= 6 ){
		if( !lstrcmpi("xinput", basename2.substr(0,6).c_str() ) ){
			return XIFW_XV_v1x0;
		}
	}
	return XIFW_XV_Unknown;
}
void WINAPI XInputEnable( BOOL enable_ )
{
	return ori_XInputEnable( enable_ );
}
DWORD WINAPI XInputGetBatteryInformation( DWORD dwUserIndex, BYTE devType, XINPUT_BATTERY_INFORMATION* pBatteryInformation )
{
	return ori_XInputGetBatteryInformation( dwUserIndex, devType, pBatteryInformation );
}
DWORD WINAPI XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, PXINPUT_KEYSTROKE pKeystroke )
{
	return ori_XInputGetKeystroke( dwUserIndex, dwReserved, pKeystroke );
}
DWORD WINAPI XInputGetAudioDeviceIds( DWORD dwUserIndex, LPWSTR pRenderDeviceId, UINT* pRenderCount, LPWSTR pCaptureDeviceId, UINT* pCaptureCount )
{
	return ori_XInputGetAudioDeviceIds( dwUserIndex, pRenderDeviceId, pRenderCount, pCaptureDeviceId, pCaptureCount );
}
