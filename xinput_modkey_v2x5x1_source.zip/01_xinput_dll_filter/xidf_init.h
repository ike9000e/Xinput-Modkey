#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <string>
#include <windows.h>
#include <xinput.h>

struct hxdw_IniData2;
using XInputGetState_t = DWORD __stdcall( DWORD dwUserIndex,XINPUT_STATE *pState );

bool xidf_InitForProcess( void* hInstance ); //HINSTANCE
void xidf_DeinitForProcess();
bool xidf_InitGlobalDataForProcess( void* hInstance ); //HINSTANCE
bool xidf_ReinitConfiguration( const hxdw_IniData2& ini3, std::string* err2, bool bOnBtnReinit );
auto xidf_GetCurrentConfigFileName() -> const char*;
DWORD WINAPI xidf_XInputGetState( DWORD dwUserIndex,XINPUT_STATE *pState );
