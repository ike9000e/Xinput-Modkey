#pragma once

#ifdef XIDF_USER
	#define XIDF_API __declspec(dllimport)
	//#error "a"
#else
	#define XIDF_API __declspec(dllexport)
	//#error "a"
#endif //XIDF_USER

extern "C" XIDF_API int xidf_dll_dummy();
